#########Polizas############
INSERT INTO `admin_tugruero`.`PolizasBCK` 
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`, 
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('SDDDDDD','V-18020594','KDJSLJDLASJDK','JLAKJSDLAJSDLK','Daihatsu','FSDFSDF','Automóvil','N/A','FSDFSD','2009','N/A','TU GRUERO GOLD','TGG-CCCT-0001','Distrito Capital','DIRECCION DE DOMICILIO','', 
	'2017-08-21','2017-08-21 09:24:47','2017-08-21 09:24:47','1','1','','','','2017-08-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK` 
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`, 
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('SSSSSSS','V-18020594','ASDASAAAA','ASDASDAS','Acura','DFSFSDF','Automóvil','N/A','SSSSS','2017','N/A','TU GRUERO GOLD','TGG-CCCT-0002','Distrito Capital','SDASDASDASD ASDADADASDAS DASDADAD','', 
	'2017-08-21','2017-08-21 09:26:07','2017-08-21 09:26:07','1','1','','','','2017-08-21 00:00:00','Activo','0');
#########SolicitudPlan############
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('1','KDJSLJDLASJDK','JLAKJSDLAJSDLK', 'DFDFSDFSD@GMAIL.COM', 'V-18020594','Casado(a)',	'2017-08-21','Masculino' ,'V-18020594', 
	'Distrito Capital',	'CARACAS', 'DIRECCION DE DOMICILIO', '02128601223','04143802164','2017-08-21','TDC', '0', 
	'Automóvil', 'Daihatsu', 'FSDFSDF','2009','FSDFSD','SDDDDDD','Cross Over','5','ssssssssssssssss', 'ssssssssssssssssssssssssssssssssss','ACT', 
	'125932.90', '125932.90', 'S', '', '3', 'MAX 300 KM', 'ILIMITADO URBANO (*) Y UNO (01) EXTRAURBANO (*)','0',null);
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('2','ASDASAAAA','ASDASDAS', 'DSDSD@GMAIL.COM', 'V-18020594','Casado(a)',	'2017-08-21','Masculino' ,'V-191222014', 
	'Distrito Capital',	'CARACAS', 'SDASDASDASD ASDADADASDAS DASDADAD', '02128601223','04143802164','2017-08-21','TDC', '0', 
	'Automóvil', 'Acura', 'DFSFSDF','2017','SSSSS','SSSSSSS','Coupé','5','ssssssssssss', 'sssssssssssssssssssssssssssssss','ACT', 
	'120000.00', '120000.00', 'S', '', '3', 'MAX 300 KM', 'ILIMITADO URBANO (*) Y UNO (01) EXTRAURBANO (*)','0',null);
#########SolicitudPagoDetalle############
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('1','ghfghfgh','Pago de plan mediante la herramienta administrativa','approved','', '','','2017-08-21 09:22:13', 
	'débito','credit_card','', '','guest', 'dfdfsdfsd@gmail.com','', 
	'v-18020594','','','','125932.9', 
	'', '','', '');
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('2','ssssssssssssssssssss','Pago de plan mediante la herramienta administrativa','approved','', '','','2017-08-21 09:25:57', 
	'débito','credit_card','', '','guest', 'dsdsd@gmail.com','', 
	'sssssssssssssssss','','','','120000', 
	'', '','', '');
#########SolicitudPlanSeleccion############
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('1','2', '120000.00','120000.00', '2017-08-21');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('1','3', '5932.90','5932.90', '2017-08-21');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('2','2', '120000.00','120000.00', '2017-08-21');
#########SolicitudDocumentos############
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('1','Cedula','Cedula_CCCT_1.pdf','2017-08-21 09:24:35','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('2','Cedula','Cedula_CCCT_2.pdf','2017-08-21 09:25:57','ACT');
#########SolicitudAprobada############
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('1','TGG-CCCT-0001','2017-08-21','2017-08-21','02-5-CCCT-0001','02-5-CCCT-0001-1','2017-08-21');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('2','TGG-CCCT-0002','2017-08-21','2017-08-21','','','2017-08-21');
