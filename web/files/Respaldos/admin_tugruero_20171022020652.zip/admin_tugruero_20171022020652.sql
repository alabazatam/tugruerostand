#########Polizas############
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','MARCOS','DE ANDRADE','Acura','ADASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0002','Distrito Capital','DIRECCION DE DOMICILIO','',
	'2017-10-21','2017-10-21 17:22:18','2017-10-21 17:22:18','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','MARCOS','DE ANDRDADE','Acura','ASDASD','Automóvil','N/A','ASDASDAS','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0003','Apure','ASDASDASDJHASGDJHASGDJAGHS','',
	'2017-10-21','2017-10-21 17:25:39','2017-10-21 17:25:39','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 17:29:56','2017-10-21 17:29:56','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 17:30:27','2017-10-21 17:30:27','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 17:30:27','2017-10-21 17:30:27','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('','','','','','','Automóvil','N/A','','','N/A','','','','','',
	'','2017-10-21 17:31:46','2017-10-21 17:31:46','1','1','','','','','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 17:31:55','2017-10-21 17:31:55','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 17:32:16','2017-10-21 17:32:16','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 17:32:24','2017-10-21 17:32:24','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 17:32:32','2017-10-21 17:32:32','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 17:32:43','2017-10-21 17:32:43','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 17:32:58','2017-10-21 17:32:58','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 17:33:28','2017-10-21 17:33:28','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 17:33:50','2017-10-21 17:33:50','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 17:34:20','2017-10-21 17:34:20','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 17:34:52','2017-10-21 17:34:52','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 17:35:07','2017-10-21 17:35:07','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 17:35:25','2017-10-21 17:35:25','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 17:35:34','2017-10-21 17:35:34','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 17:38:57','2017-10-21 17:38:57','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 17:40:23','2017-10-21 17:40:23','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 17:57:27','2017-10-21 17:57:27','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 18:40:41','2017-10-21 18:40:41','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 18:43:09','2017-10-21 18:43:09','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 18:43:38','2017-10-21 18:43:38','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('','','','','','','Automóvil','N/A','','','N/A','','','','','',
	'','2017-10-21 19:16:48','2017-10-21 19:16:48','1','1','','','','','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('','','','','','','Automóvil','N/A','','','N/A','','','','','',
	'','2017-10-21 19:17:39','2017-10-21 19:17:39','1','1','','','','','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 19:17:49','2017-10-21 19:17:49','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 19:18:39','2017-10-21 19:18:39','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 19:20:40','2017-10-21 19:20:40','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 19:22:09','2017-10-21 19:22:09','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 19:23:41','2017-10-21 19:23:41','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 19:24:12','2017-10-21 19:24:12','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 19:25:05','2017-10-21 19:25:05','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 19:25:53','2017-10-21 19:25:53','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 19:26:31','2017-10-21 19:26:31','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 19:26:44','2017-10-21 19:26:44','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 19:27:16','2017-10-21 19:27:16','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 19:27:54','2017-10-21 19:27:54','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 19:28:25','2017-10-21 19:28:25','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 19:29:23','2017-10-21 19:29:23','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 19:29:43','2017-10-21 19:29:43','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 19:30:06','2017-10-21 19:30:06','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 19:32:43','2017-10-21 19:32:43','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 19:33:21','2017-10-21 19:33:21','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 19:33:59','2017-10-21 19:33:59','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 19:34:14','2017-10-21 19:34:14','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 19:35:19','2017-10-21 19:35:19','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 19:35:36','2017-10-21 19:35:36','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 19:36:31','2017-10-21 19:36:31','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 19:37:08','2017-10-21 19:37:08','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 19:49:36','2017-10-21 19:49:36','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 19:51:05','2017-10-21 19:51:05','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 19:58:26','2017-10-21 19:58:26','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 19:59:23','2017-10-21 19:59:23','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 20:00:37','2017-10-21 20:00:37','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','ASLKDJLASJDLK','JLASJLDKJASLKDJL','Acura','ASDASD','Automóvil','N/A','ASDASD','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Anzoátegui','ALSDLJKASDJLKASJD','',
	'2017-10-21','2017-10-21 20:02:12','2017-10-21 20:02:12','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','AKSDHKASJDH','KJHADSKJHDKJA','Acura','ASDASDASD','Automóvil','N/A','ASDASD','1981','N/A','TU GRUERO GOLD','TGG-CCCT-0005','Amazonas','ALSHDKAJSHDKJAHD AKSHDKASHDKJAHS','',
	'2017-10-21','2017-10-21 20:04:50','2017-10-21 20:04:50','1','1','','','','2017-10-21 00:00:00','Activo','0');
#########SolicitudPlan############
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK`
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`,
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`,
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`,
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('3','MARCOS','DE ANDRADE', 'DEANDRADEMARCOS@GMAIL.COM', 'V-18020594','Casado(a)',	'2017-10-21','Masculino' ,'V-18020594',
	'Distrito Capital',	'CARACAS', 'DIRECCION DE DOMICILIO', '02128601223','04268141850','2017-10-21','DEP', '0',
	'Automóvil', 'Acura', 'ADASDASD','1980','ASDASD','ASDASDA','Coupé','5','asdasda', 'sdasdasd','ACT',
	'261600.00', '261600.00', 'S', '', '3', '', '','0',null);
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK`
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`,
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`,
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`,
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('4','MARCOS','DE ANDRDADE', 'DEANDRADEMARCOS@GMAIL.COM', 'V-18020594','Soltero(a)',	'2017-10-21','Masculino' ,'V-18020594',
	'Apure',	'DSADSDASD', 'ASDASDASDJHASGDJHASGDJAGHS', '02128601223','04268141850','2017-10-21','DEP', '0',
	'Camioneta', 'Acura', 'ASDASD','1980','ASDASDAS','ASDASDA','Coupé','7','asdasdsad', '','ACT',
	'268132.90', '268132.90', 'S', '', '3', '', '','0',null);
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK`
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`,
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`,
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`,
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('5','ASLKDJLASJDLK','JLASJLDKJASLKDJL', 'DESARROLLO@TUGRUERO.COM', 'V-18020594','Casado(a)',	'2017-10-21','Masculino' ,'V-18020594',
	'Anzoátegui',	'ASLKDLASDJ', 'ALSDLJKASDJLKASJD', '02128601223','04141455454','2017-10-21','DEP', '0',
	'Automóvil', 'Acura', 'ASDASD','1980','ASDASD','ASDASDA','Coupé','5','', '','ACT',
	'267532.90', '267532.90', 'S', '', '3', '', '','0',null);
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK`
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`,
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`,
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`,
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('6','AKSDHKASJDH','KJHADSKJHDKJA', 'DEANDRADEMARCOS@GMAIL.COM', 'V-18020594','Casado(a)',	'2017-10-21','Masculino' ,'V-18020594',
	'Amazonas',	'AHSKJDGJHASG', 'ALSHDKAJSHDKJAHD AKSHDKASHDKJAHS', '02128601223','04268141850','2017-10-22','DEP', '0',
	'Automóvil', 'Acura', 'ASDASDASD','1981','ASDASD','ASDASDA','Coupé','5','asdasdas', 'dasdasdsad','ACT',
	'267532.90', '267532.90', 'S', '', '3', '', '','0',null);
#########SolicitudPagoDetalle############
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK`
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`,
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`,
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`,
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`,
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('6','','Pago de plan mediante la herramienta administrativa','approved','', '','','2017-10-22 02:04:42',
	'débito','credit_card','', '','guest', 'deandrademarcos@gmail.com','',
	'','','','','267532.9',
	'', '','', '');
#########SolicitudPlanSeleccion############
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('3','2', '261600.00','261600.00', '2017-10-21');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('4','2', '261600.00','261600.00', '2017-10-21');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('4','5', '6532.90','6532.90', '2017-10-21');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('5','2', '261600.00','261600.00', '2017-10-21');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('5','3', '5932.90','5932.90', '2017-10-21');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('6','2', '261600.00','261600.00', '2017-10-22');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('6','3', '5932.90','5932.90', '2017-10-22');
#########SolicitudDocumentos############
#########SolicitudAprobada############
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK`
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('3','TGG-CCCT-0002','2017-10-21','2017-10-21','','','2017-10-21');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK`
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('4','TGG-CCCT-0003','2017-10-21','2017-10-21','02-5-CCCT-0003','02-5-CCCT-0003-1','2017-10-21');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK`
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('5','TGG-CCCT-0004','2017-10-21','2017-10-21','02-5-CCCT-0004','02-5-CCCT-0004-1','2017-10-21');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK`
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('6','TGG-CCCT-0005','2017-10-21','2017-10-21','02-5-CCCT-0005','02-5-CCCT-0005-1','2017-10-22');
