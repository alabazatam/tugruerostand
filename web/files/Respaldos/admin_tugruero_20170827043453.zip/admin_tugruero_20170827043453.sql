#########Polizas############
INSERT INTO `admin_tugruero`.`PolizasBCK` 
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`, 
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('DFGDFGD','V-18020594','RRRRRRRRRRRRRRRRRRRRR','RRRRRRRRRRRRRRRRRRRRRRRRRRRRR','Daihatsu','FGDFGDFG','Automóvil','N/A','DFGDFG','2005','N/A','TU GRUERO GOLD','TGG-CCCT-0001','Anzoátegui','DASDASDASDAS','', 
	'2017-08-27','2017-08-27 16:34:03','2017-08-27 16:34:03','1','1','','','','2017-08-27 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK` 
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`, 
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','E-18020594','JHGJHGJHG','JHJHJH','Dongfeng','ADSASDASDAS','Automóvil','N/A','ASDASD','2007','N/A','TU GRUERO PLUS','TGP-CCCT-0001','Anzoátegui','AHDAKJSDHKASHDKAJSHD ASHDAKJSHDKJASHKDJAS','', 
	'2017-08-27','2017-08-27 16:34:23','2017-08-27 16:34:23','1','1','','','','2017-08-27 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK` 
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`, 
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('GGGGGG','V-18020594','MARCOS','DE ANDRAE','Daihatsu','GGGGG','Automóvil','N/A','GGGGG','2008','N/A','TU GRUERO GOLD','TGG-CCCT-0002','Apure','LAKSJDLKASJDLKAS','', 
	'2017-08-27','2017-08-27 16:34:43','2017-08-27 16:34:43','1','1','','','','2017-08-27 00:00:00','Activo','0');
#########SolicitudPlan############
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('1','MARCOS','DE ANDRAE', 'DEANDRADEMARCOS@GMAIL.COM', 'V-18020594','Divorciado(a)',	'2017-08-27','Masculino' ,'V-18020594', 
	'Apure',	'CARACAS', 'LAKSJDLKASJDLKAS', '02128601223','04145454545','2017-08-27','TDC', '0', 
	'Automóvil', 'Daihatsu', 'GGGGG','2008','GGGGG','GGGGGG','Coupé','5','', '','ACT', 
	'125932.90', '125932.90', 'S', '', '3', 'MAX 300 KM', 'ILIMITADO URBANO (*) Y UNO (01) EXTRAURBANO (*)','0',null);
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('2','JHGJHGJHG','JHJHJH', 'DEANDRADEMARCOS@GMAIL.COM', 'E-18020594','Divorciado(a)',	'2017-08-27','Masculino' ,'V-123465987', 
	'Anzoátegui',	'CARACAS', 'AHDAKJSDHKASHDKAJSHD ASHDAKJSHDKJASHKDJAS', '02128601223','04141111111','2017-08-27','TDC', '0', 
	'Automóvil', 'Dongfeng', 'ADSASDASDAS','2007','ASDASD','ASDASDA','Coupé','7','', '','ACT', 
	'46532.90', '46532.90', 'S', '', '3', 'MAX 50 KM', 'ILIMITADO','0',null);
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('3','RRRRRRRRRRRRRRRRRRRRR','RRRRRRRRRRRRRRRRRRRRRRRRRRRRR', 'ASDASDAS@GMAIL.COM', 'V-18020594','Soltero(a)',	'2017-08-27','Masculino' ,'E-121212121', 
	'Anzoátegui',	'ASDASDAS', 'DASDASDASDAS', '02128601223','04141212121','2017-08-27','TDC', '0', 
	'Automóvil', 'Daihatsu', 'FGDFGDFG','2005','DFGDFG','DFGDFGD','Coupé','7','', '','ACT', 
	'126532.90', '126532.90', 'S', '', '3', 'MAX 300 KM', 'ILIMITADO URBANO (*) Y UNO (01) EXTRAURBANO (*)','0',null);
#########SolicitudPagoDetalle############
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('3','','Pago de plan mediante la herramienta administrativa','approved','', '','','2017-08-27 04:33:53', 
	'débito','credit_card','', '','guest', 'ASDASDAS@GMAIL.COM','', 
	'','','','','126532.90', 
	'', '','', '');
#########SolicitudPlanSeleccion############
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('1','2', '120000.00','120000.00', '2017-08-27');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('1','3', '5932.90','5932.90', '2017-08-27');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('2','1', '40000.00','40000.00', '2017-08-27');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('2','5', '6532.90','6532.90', '2017-08-27');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('3','2', '120000.00','120000.00', '2017-08-27');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('3','5', '6532.90','6532.90', '2017-08-27');
#########SolicitudDocumentos############
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('1','Cedula','Cedula_CCCT_1.pdf','2017-08-27 04:34:37','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('2','Cedula','Cedula_CCCT_2.jpg','2017-08-27 04:34:18','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('3','Cedula','Cedula_CCCT_3.pdf','2017-08-27 04:33:53','ACT');
#########SolicitudAprobada############
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('1','TGG-CCCT-0002','2017-08-27','2017-08-27','02-5-CCCT-0003','02-5-CCCT-0003-1','2017-08-27');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('2','TGP-CCCT-0001','2017-08-27','2017-08-27','02-5-CCCT-0002','02-5-CCCT-0002-1','2017-08-27');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('3','TGG-CCCT-0001','2017-08-27','2017-08-27','02-5-CCCT-0001','02-5-CCCT-0001-1','2017-08-27');
