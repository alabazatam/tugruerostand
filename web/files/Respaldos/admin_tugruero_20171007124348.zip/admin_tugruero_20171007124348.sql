#########Polizas############
INSERT INTO `admin_tugruero`.`PolizasBCK` 
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`, 
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('44EESDD','V-18020594','MARCOS','DE ANDRADE','Daewoo','AVEO','Automóvil','N/A','ASDASDASDAS','1980','N/A','TU GRUERO PLUS','TGP-CCCT-0003','Distrito Capital','DIRECCION DE DOCMIICHHUDSHGSDGHJSDGHJSD','', 
	'2017-09-13','2017-09-13 11:25:27','2017-09-13 11:25:27','1','1','','','','2017-09-13 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK` 
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`, 
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('SSSSS','V-18020594','MARCOS','DE ANDSREADE','Acura','AVEO','Automóvil','N/A','ASSS','1982','N/A','TU GRUERO PLUS','TGP-CCCT-0004','Distrito Capital','ALKSJDLASJD AKLSJDKLASJDLKAJSLDKJASD','', 
	'2017-09-13','2017-09-13 19:25:45','2017-09-13 19:25:45','1','1','','','','2017-09-13 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK` 
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`, 
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDA','V-18020594','MARCOS','DE ANDRADE','Chevrolet','ASDASD','Automóvil','N/A','AAAASDASD','1996','N/A','TU GRUERO GOLD','TGG-CCCT-0007','Amazonas','KASHDKJASHDKJHSAAAAAAAAAA','', 
	'2017-09-26','2017-09-26 20:14:31','2017-09-26 20:14:31','1','1','','','','2017-09-26 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK` 
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`, 
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('SDASDAS','V-15802121','MARCOS','DE ANDRADE','Chery','ASDASDSA','Automóvil','N/A','ASDASDA','1995','N/A','TU GRUERO PLUS','TGP-CCCT-0005','Apure','ALSDJLKASJDLKAJSDLKAJSLDJALKSDJ','', 
	'2017-09-26','2017-09-26 20:27:16','2017-09-26 20:27:16','1','1','','','','2017-09-26 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK` 
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`, 
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('AC137SK','V-18020594','MARCOS','DE ANDRADE','Ford','KA','Automóvil','N/A','BLANCO','2006','N/A','TU GRUERO GOLD','TGG-CCCT-0008','Distrito Capital','SAJDLKASJDAKSDJ ASDJKLASJDLKASJDLKASJ','', 
	'2017-10-01','2017-10-01 12:58:21','2017-10-01 12:58:21','1','1','','','','2017-10-01 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK` 
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`, 
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDS','V-18020594','MARCOS','DE ANDRADE','Changhe','SADASDASDSA','Automóvil','N/A','ASDSADASD','1988','N/A','TU GRUERO GOLD','TGG-CCCT-0009','Delta Amacuro','DIRECCION DE ORUEBA KDHKASJDHKAJSHD','', 
	'2017-10-01','2017-10-01 13:13:03','2017-10-01 13:13:03','1','1','','','','2017-10-01 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK` 
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`, 
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('AAABBBB','V-18020594','MARCOS','DE ANDRTADE','Chery','AVEO','Automóvil','N/A','BLANCO','1980','N/A','TU GRUERO PLUS','TGP-CCCT-0006','Distrito Capital','DIRECCION DE DOMICILIO','', 
	'2017-10-07','2017-10-07 12:42:03','2017-10-07 12:42:03','1','1','','','','2017-10-07 00:00:00','Activo','0');
#########SolicitudPlan############
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('9','MARCOS','DE ANDRADE', 'DEANDRADEMARCOS@GMAIL.COM', 'V-18020594','Casado(a)',	'2017-09-13','Masculino' ,'', 
	'Distrito Capital',	'CARACAS', 'DIRECCION DE DOCMIICHHUDSHGSDGHJSDGHJSD', '','04268141850','2017-09-13','TDC', '0', 
	'Automóvil', 'Daewoo', 'AVEO','1980','ASDASDASDAS','44EESDD','Coupé','7','', '','ACT', 
	'246532.90', '246532.90', 'S', '', '3', 'MAX 50 KM', '3 SERVICIOS URBANOS (*)','0',null);
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('10','MARCOS','DE ANDSREADE', 'DE@G.COM', 'V-18020594','Soltero(a)',	'2017-09-13','Masculino' ,'V-18020594', 
	'Distrito Capital',	'CSASJDAKLSDJ', 'ALKSJDLASJD AKLSJDKLASJDLKAJSLDKJASD', '','04268141850','2017-09-13','TDC', '0', 
	'Camioneta', 'Acura', 'AVEO','1982','ASSS','SSSSS','Cross Over','5','asdasd', 'asdasdasdas','ACT', 
	'85932.90', '85932.90', 'S', '', '3', 'MAX 50 KM', '3 SERVICIOS URBANOS (*)','0',null);
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('11','MARCOS','DE ANDRADE', 'DEN@GMAIL.COM', 'V-18020594','Soltero(a)',	'2017-09-26','Masculino' ,'V-18020594', 
	'Amazonas',	'SKJDHSHDKJ', 'KASHDKJASHDKJHSAAAAAAAAAA', '02128601223','04268141850','2017-09-26','TDC', '0', 
	'Automóvil', 'Chevrolet', 'ASDASD','1996','AAAASDASD','ASDASDA','Coupé','5','asdasdasdas', 'dasdasdasdasdasdasdsadasdasd','ACT', 
	'149932.90', '149932.90', 'S', '', '3', '', '','0',null);
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('12','MARCOS','DE ANDRADE', 'DEANDRADEMARCOS@GMAIL.COM', 'V-15802121','Soltero(a)',	'2017-09-26','Masculino' ,'V-123456478', 
	'Apure',	'ASDJASD', 'ALSDJLKASJDLKAJSDLKAJSLDJALKSDJ', '02128601223','04261212121','2017-09-26','TDC', '0', 
	'Camioneta', 'Chery', 'ASDASDSA','1995','ASDASDA','SDASDAS','Coupé','7','asdasdasd', 'asdasdasdasdasdasds','ACT', 
	'54532.90', '54532.90', 'S', '', '3', 'MAX 50 KM', '3 SERVICIOS URBANOS (*)','0',null);
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('13','MARCOS','DE ANDRADE', 'DESARROLLO@TUGRUERO.COM', 'V-18020594','Casado(a)',	'2017-10-04','Masculino' ,'', 
	'Distrito Capital',	'CARACAS', 'SAJDLKASJDAKSDJ ASDJKLASJDLKASJDLKASJ', '','04268141850','2017-10-01','TDC', '0', 
	'Automóvil', 'Ford', 'KA','2006','BLANCO','AC137SK','Coupé','5','', '','ACT', 
	'125932.90', '125932.90', 'S', '', '3', 'MAX 300 KM', 'ILIMITADO URBANO (*) Y UNO (01) EXTRAURBANO (*)','0',null);
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('14','MARCOS','DE ANDRADE', 'DESARROLLO@TUGRUERO.COM', 'V-18020594','Casado(a)',	'2017-10-13','Masculino' ,'', 
	'Delta Amacuro',	'CARACAS', 'DIRECCION DE ORUEBA KDHKASJDHKAJSHD', '02128601223','04144545454','2017-10-01','DEP', '0', 
	'Automóvil', 'Changhe', 'SADASDASDSA','1988','ASDSADASD','ASDASDS','Coupé','7','asdsadsad', 'sadasdasdasdsadsadsads','ACT', 
	'246532.90', '246532.90', 'S', '', '3', '', '','0',null);
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('15','MARCOS','DE ANDRTADE', 'DEANDRADEMARCOS@GMAIL.COM', 'V-18020594','Casado(a)',	'2017-10-07','Masculino' ,'', 
	'Distrito Capital',	'CARACAS', 'DIRECCION DE DOMICILIO', '','04268141850','2017-10-07','TDC', '0', 
	'Camioneta', 'Chery', 'AVEO','1980','BLANCO','AAABBBB','Coupé','5','', '','ACT', 
	'85932.90', '85932.90', 'S', '', '3', 'MAX 50 KM', '3 SERVICIOS URBANOS (*)','0',null);
#########SolicitudPagoDetalle############
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('15','','Pago de plan mediante la herramienta administrativa','approved','', '','','2017-10-07 12:41:53', 
	'débito','credit_card','', '','guest', 'DEANDRADEMARCOS@GMAIL.COM','', 
	'','','','','85932.9', 
	'', '','', '');
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('12','asdasdasdas','Pago de plan mediante la herramienta administrativa','approved','', '','','2017-09-26 08:27:06', 
	'débito','credit_card','', '','guest', 'DEANDRADEMARCOS@GMAIL.COM','', 
	'dasdas','','','','54532.9', 
	'', '','', '');
#########SolicitudPlanSeleccion############
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('9','1', '80000.00','80000.00', '2017-09-13');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('9','5', '6532.90','6532.90', '2017-09-13');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('10','1', '80000.00','80000.00', '2017-09-13');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('10','3', '5932.90','5932.90', '2017-09-13');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('11','2', '144000.00','144000.00', '2017-09-26');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('11','3', '5932.90','5932.90', '2017-09-26');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('12','1', '48000.00','48000.00', '2017-09-26');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('12','5', '6532.90','6532.90', '2017-09-26');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('13','2', '120000.00','120000.00', '2017-10-01');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('13','3', '5932.90','5932.90', '2017-10-01');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('14','2', '240000.00','240000.00', '2017-10-01');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('14','5', '6532.90','6532.90', '2017-10-01');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('15','1', '80000.00','80000.00', '2017-10-07');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('15','3', '5932.90','5932.90', '2017-10-07');
#########SolicitudDocumentos############
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('9','Cedula','Cedula_CCCT_9.pdf','2017-09-13 11:25:46','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('10','Cedula','Cedula_CCCT_10.pdf','2017-09-13 07:25:37','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('11','Cedula','Cedula_CCCT_11.png','2017-09-26 08:14:19','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('12','Cedula','Cedula_CCCT_12.pdf','2017-09-26 08:27:07','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('13','Cedula','Cedula_CCCT_13.jpg','2017-10-01 12:54:50','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('14','Cedula','Cedula_CCCT_14.jpg','2017-10-01 01:12:51','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('15','Cedula','Cedula_CCCT_15.jpg','2017-10-07 12:41:53','ACT');
#########SolicitudAprobada############
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('9','TGP-CCCT-0003','2017-09-13','2017-09-13','02-5-CCCT-0008','02-5-CCCT-0008-1','2017-09-13');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('10','TGP-CCCT-0004','2017-09-13','2017-09-13','02-5-CCCT-0009','02-5-CCCT-0009-1','2017-09-13');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('11','TGG-CCCT-0007','2017-09-26','2017-09-26','02-5-CCCT-0010','02-5-CCCT-0010-1','2017-09-26');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('12','TGP-CCCT-0005','2017-09-26','2017-09-26','02-5-CCCT-0011','02-5-CCCT-0011-1','2017-09-26');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('13','TGG-CCCT-0008','2017-10-01','2017-10-01','02-5-CCCT-0012','02-5-CCCT-0012-1','2017-10-01');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('14','TGG-CCCT-0009','2017-10-01','2017-10-01','02-5-CCCT-0013','02-5-CCCT-0013-1','2017-10-01');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('15','TGP-CCCT-0006','2017-10-07','2017-10-07','02-5-CCCT-0014','02-5-CCCT-0014-1','2017-10-07');
