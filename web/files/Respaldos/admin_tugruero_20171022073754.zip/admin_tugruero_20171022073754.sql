#########Polizas############
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('SDFSDFS','V-18020594','MARCFOS','DE ANDRADE','Daihatsu','SDFSDFSD','Automóvil','N/A','FSDFSDF','1997','N/A','TU GRUERO GOLD','TGG-CCCT-0006','Distrito Capital','SDHASJKDHAKJS','',
	'2017-10-22','2017-10-22 13:27:30','2017-10-22 13:27:30','1','1','','','','2017-10-22 00:00:00','Activo','0');
#########SolicitudPlan############
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK`
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`,
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`,
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`,
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('7','MARCFOS','DE ANDRADE', 'DEANDRADEMARCOS@GMAIL.COM', 'V-18020594','Casado(a)',	'2017-10-22','Masculino' ,'',
	'Distrito Capital',	'CARACAS', 'SDHASJKDHAKJS', '','04268141850','2017-10-22','TDC', '0',
	'Automóvil', 'Daihatsu', 'SDFSDFSD','1997','FSDFSDF','SDFSDFS','Coupé','5','', '','ACT',
	'162892.90', '162892.90', 'S', '', '3', '', '','0',null);
#########SolicitudPagoDetalle############
#########SolicitudPlanSeleccion############
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('7','2', '156960.00','156960.00', '2017-10-22');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('7','3', '5932.90','5932.90', '2017-10-22');
#########SolicitudDocumentos############
#########SolicitudAprobada############
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK`
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('7','TGG-CCCT-0006','2017-10-22','2017-10-22','02-5-CCCT-0006','02-5-CCCT-0006-1','2017-10-22');
