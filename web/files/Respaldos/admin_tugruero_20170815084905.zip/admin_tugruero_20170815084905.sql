#########Polizas############
INSERT INTO `admin_tugruero`.`PolizasBCK` 
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`, 
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('MERCAN1','V-7654321','Demo','Mercantil','Demo','Demo','','Carro','Blanco','2016','Demo','TU GRUERO PLUS','7654321','Distrito Capital','Demo','', 
	'2017-08-30','2017-08-15 08:49:05','2016-10-22 09:32:29','1','1','V','4268141850','prueba@gmail.com','2016-08-30 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK` 
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`, 
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('AC137SK','V-18020595','MARCOS','DE ANDRADE','FORD','KA','','Carro','Blanco','2007','45556667','Asistir Cooperativa','112224','Distrito Capital','GAHSGJAHGS ASHGAGSHAGS','', 
	'2017-08-30','2017-08-15 08:49:05','2017-03-12 17:25:16','1','1','V','4268141851','prueba@gmail.com','2016-08-30 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK` 
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`, 
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('AC137SK','V-18020596','MARCOS','DE ANDRADE','FORD','KA','','Carro','Blanco','2008','45556668','Universal de Seguros','112225','Distrito Capital','GAHSGJAHGS ASHGAGSHAGS','', 
	'2016-12-31','2017-08-15 08:49:05','2017-08-15 08:49:05','1','1','V','4268141852','prueba@gmail.com','2016-08-30 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK` 
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`, 
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('AC137SK','V-18020597','MARCOS','DE ANDRADE','FORD','KA','','Carro','Blanco','2009','45556669','Universal de Seguros','112226','Distrito Capital','GAHSGJAHGS ASHGAGSHAGS','', 
	'2016-12-31','2017-08-15 08:49:05','2017-08-15 08:49:05','1','1','V','4268141853','prueba@gmail.com','2016-08-30 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK` 
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`, 
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('AC137SK','V-18020598','MARCOS','DE ANDRADE','FORD','KA','','Carro','Blanco','2010','45556670','Universal de Seguros','112227','Distrito Capital','GAHSGJAHGS ASHGAGSHAGS','', 
	'2016-12-31','2017-08-15 08:49:05','2017-08-15 08:49:05','1','1','V','4268141854','prueba@gmail.com','2016-08-30 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK` 
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`, 
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('AC137SK','V-18020599','MARCOS','DE ANDRADE','FORD','KA','','Carro','Blanco','2011','45556671','Universal de Seguros','112228','Distrito Capital','GAHSGJAHGS ASHGAGSHAGS','', 
	'2016-12-31','2017-08-15 08:49:05','2017-08-15 08:49:05','1','1','V','4268141855','prueba@gmail.com','2016-08-30 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK` 
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`, 
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('AC137SK','V-18020600','MARCOS','DE ANDRADE','FORD','KA','','Carro','Blanco','2012','45556672','Universal de Seguros','112229','Distrito Capital','GAHSGJAHGS ASHGAGSHAGS','', 
	'2016-12-31','2017-08-15 08:49:05','2017-08-15 08:49:05','1','1','V','4268141856','prueba@gmail.com','2016-08-30 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK` 
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`, 
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('AC137SK','V-18020601','MARCOS','DE ANDRADE','FORD','KA','','Carro','Blanco','2013','45556673','Universal de Seguros','112230','Distrito Capital','GAHSGJAHGS ASHGAGSHAGS','', 
	'2016-12-31','2017-08-15 08:49:05','2017-08-15 08:49:05','1','1','V','4268141857','prueba@gmail.com','2016-08-30 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK` 
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`, 
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('AC137SK','V-18020602','MARCOS','DE ANDRADE','FORD','KA','','Carro','Blanco','2014','45556674','Universal de Seguros','112231','Distrito Capital','GAHSGJAHGS ASHGAGSHAGS','', 
	'2016-12-31','2017-08-15 08:49:05','2017-08-15 08:49:05','1','1','V','4268141858','prueba@gmail.com','2016-08-30 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK` 
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`, 
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('AC137SK','V-18020603','MARCOS','DE ANDRADE','FORD','KA','','Carro','Blanco','2015','45556675','Universal de Seguros','112232','Distrito Capital','GAHSGJAHGS ASHGAGSHAGS','', 
	'2016-12-31','2017-08-15 08:49:05','2017-08-15 08:49:05','1','1','V','4268141859','prueba@gmail.com','2016-08-30 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK` 
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`, 
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('AC137SK','V-18020604','MARCOS','DE ANDRADE','FORD','KA','','Carro','Blanco','2016','45556676','Universal de Seguros','112233','Distrito Capital','GAHSGJAHGS ASHGAGSHAGS','', 
	'2016-12-31','2017-08-15 08:49:05','2017-08-15 08:49:05','1','1','V','4268141860','prueba@gmail.com','2016-08-30 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK` 
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`, 
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('AC137SK','V-18020605','MARCOS','DE ANDRADE','FORD','KA','','Carro','Blanco','2017','45556677','Universal de Seguros','112234','Distrito Capital','GAHSGJAHGS ASHGAGSHAGS','', 
	'2016-12-31','2017-08-15 08:49:05','2017-08-15 08:49:05','1','1','V','4268141861','prueba@gmail.com','2016-08-30 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK` 
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`, 
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('AC137SK','V-18020606','MARCOS','DE ANDRADE','FORD','KA','','Carro','Blanco','2018','45556678','Universal de Seguros','112235','Distrito Capital','GAHSGJAHGS ASHGAGSHAGS','', 
	'2016-12-31','2017-08-15 08:49:05','2017-08-15 08:49:05','1','1','V','4268141862','prueba@gmail.com','2016-08-30 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK` 
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`, 
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('AC137SK','V-18020607','MARCOS','DE ANDRADE','FORD','KA','','Carro','Blanco','2019','45556679','Universal de Seguros','112236','Distrito Capital','GAHSGJAHGS ASHGAGSHAGS','', 
	'2016-12-31','2017-08-15 08:49:05','2017-08-15 08:49:05','1','1','V','4268141863','prueba@gmail.com','2016-08-30 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK` 
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`, 
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('AC137SK','V-18020608','MARCOS','DE ANDRADE','FORD','KA','','Carro','Blanco','2020','45556680','Universal de Seguros','112237','Distrito Capital','GAHSGJAHGS ASHGAGSHAGS','', 
	'2016-12-31','2017-08-15 08:49:05','2017-08-15 08:49:05','1','1','V','4268141864','prueba@gmail.com','2016-08-30 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK` 
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`, 
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('AC137SK','V-18020609','MARCOS','DE ANDRADE','FORD','KA','','Carro','Blanco','2021','45556681','Universal de Seguros','112238','Distrito Capital','GAHSGJAHGS ASHGAGSHAGS','', 
	'2016-12-31','2017-08-15 08:49:05','2017-08-15 08:49:05','1','1','V','4268141865','prueba@gmail.com','2016-08-30 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK` 
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`, 
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('AC137SK','V-18020610','MARCOS','DE ANDRADE','FORD','KA','','Carro','Blanco','2022','45556682','Universal de Seguros','112239','Distrito Capital','GAHSGJAHGS ASHGAGSHAGS','', 
	'2016-12-31','2017-08-15 08:49:05','2017-08-15 08:49:05','1','1','V','4268141866','prueba@gmail.com','2016-08-30 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK` 
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`, 
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('AC137SK','V-18020611','MARCOS','DE ANDRADE','FORD','KA','','Carro','Blanco','2023','45556683','Universal de Seguros','112240','Distrito Capital','GAHSGJAHGS ASHGAGSHAGS','', 
	'2016-12-31','2017-08-15 08:49:05','2017-08-15 08:49:05','1','1','V','4268141867','prueba@gmail.com','2016-08-30 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK` 
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`, 
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('AC137SK','V-18020612','MARCOS','DE ANDRADE','FORD','KA','','Carro','Blanco','2024','45556684','Universal de Seguros','112241','Distrito Capital','GAHSGJAHGS ASHGAGSHAGS','', 
	'2016-12-31','2017-08-15 08:49:05','2017-08-15 08:49:05','1','1','V','4268141868','prueba@gmail.com','2016-08-30 00:00:00','Activo','0');
#########SolicitudPlan############
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('1','ALESSANDRO','COSTANTINI TATASCIORE', 'ALEXCOSTANTINI18@GMAIL.COM', 'V-21411814','Soltero(a)',	'1991-09-18','Masculino' ,'V-214118145', 
	'Miranda',	'CARACAS', 'AV. PRINCIPAL DE LA URBINA, EDIF. EL JARDIN, PISO 11, APTO 114, MUNICIPIO SUCRE.', '02122411214','04264112673','2017-04-27','TDC', '0', 
	'Automóvil', 'Hyundai', 'ACCENT','2002','DORADO','MDF77P','Sedán','5','', '','ACT', 
	'30.00', '33.00', 'S', '', '1', '', '','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('2','GUILLERMO','RIOS', 'GUILEHR2008@GMAIL.COM', 'V-18010029','Soltero(a)',	'1987-02-24','Masculino' ,'V-180100292', 
	'Distrito Capital',	'GUARENAS', 'GUARENAS, CLORIS TERRAZAS DEL ESTE', '02124429883','04148183254','2017-05-03','TDC', '0', 
	'Automóvil', 'Nissan', 'SENTRA B13','2007','GRIS','NAV99E','Sedán','5','', '','ENV', 
	'30000.00', '33000.00', 'N', '', '1', '', '','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('3','ENRIQUE JOSE','RANGEL LOBO', 'ENJO1274@GMAIL.COM', 'V-12352502','Casado(a)',	'1974-12-11','Masculino' ,'V-12352502', 
	'Miranda',	'MIRANDA', 'URBANIZACIÓN LOMAS DEL AVILA, PALO VERDE TERCERA ETAPA, EDIFICIO AVILA PLAZA, APATAMENTO 11-A. MIRANDA. ', '02122517416','04168051940','2017-05-08','TDC', '0', 
	'Automóvil', 'Chevrolet', 'SPARK','2013','AZUL','AB929EP','Sedán','5','-----', '8Z1MD6A00DG317268','ACT', 
	'30000.00', '33000.00', 'S', '', '1', '', '','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('4','MORELBA JOSEFINA ','MONTILLA PEREZ', 'MORELBAMONTILLA11@GMAIL.COM', 'V-5978510','Soltero(a)',	'1961-01-14','Femenino' ,'V-059785105', 
	'Miranda',	'CARACAS', 'AV ANDRES BELLO C/C 5TA TRANSVERSAL QUINTA DELGO LOS PALOS GRANDES CHACAO EDO MIRANDA', '02122835512','04242030712','2017-05-11','TDC', '0', 
	'Automóvil', 'Chevrolet', 'CORSA','2002','BEIGE','AG541OK','Coupé','5','52V319270', '8Z1SC21Z52V319270','ACT', 
	'35932.90', '38932.90', 'S', '', '1', '', '','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('5','RAFAEL RAMON','RODRIGUEZ ARRIOJAS', 'RAFAEL1978@GMAIL.COM', 'V-13458880','Casado(a)',	'1978-03-08','Masculino' ,'V-134588809', 
	'Distrito Capital',	'CARACAS', 'AV. LAS AMERICAS RES SAN FRANCISCO PISO 3 APTO 11 LAS ACACIAS. SAN PEDRO CARACAS.', '02126333905','04142177424','2017-05-11','TDC', '0', 
	'Automóvil', 'Ford', 'FIESTA','2010','GRIS','AD783GM','Sedán','5','-', '8YPZF16N9A8A44043','ACT', 
	'35932.90', '38932.90', 'S', '', '1', '', '','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('6','LINDA YUBIRI','GUTIERREZ RIVAS', 'LYGUTIERREZ@GMAIL.COM', 'V-10109648','Casado(a)',	'1970-11-15','Femenino' ,'V-101096480', 
	'Miranda',	'CARACAS', 'CALLE PRINCIPAL COLINA DE LA TAHONA, EDIF. TORRE C, PISO 4, APTO 42, URB. COLINAS DE LA TAHONA.', '02129423282','04142134344','2017-05-13','DEP', '0', 
	'Automóvil', 'Chevrolet', 'SPARK','2007','VERDE','VCL39D','Sedán','5','47V327344', '8Z1MJ60047V327344','ACT', 
	'35932.90', '38932.90', 'S', '', '1', '', '','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('7','JULIO CESAR','NIEVES LOPEZ', 'JULIOCNIEVES70@GMAIL.COM', 'V-11410423','Divorciado(a)',	'1970-11-03','Masculino' ,'V-114104236', 
	'Miranda',	'GUARENAS', 'URB. TERRAZAS DEL ESTE ED. 17 PISO 3 - 3 ZONA INDUSTRIAL CLORIS,  ', '02123628360','04128161824','2017-05-15','DEP', '0', 
	'Automóvil', 'Ford', 'FIESTA','2001','VERDE','AB694PW','Sedán','5','-1 A26169-', '8YPBP01C918A26169','ACT', 
	'35932.90', '38932.90', 'S', '', '1', '', '','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('8','MAIRA JOSEFINA','MARTINEZ DE MUNOZ', 'RJMUNOZR@HOTMAIL.COM', 'V-6819051','Casado(a)',	'1994-06-14','Femenino' ,'V-068190513', 
	'Miranda',	'CARACAS', 'CALLE COMERCIO EDIF. LE MONT DORE PISO 3 APT 31 URB. SAN LUIS.', '02128377911','04129225429','2017-05-16','TDC', '0', 
	'Camioneta', 'Chevrolet', 'GRAND VITARA','2001','BLANCO','AA552IO','Sport Wagon','5','-', '8LDFTD62V10000931','ACT', 
	'35000.00', '35000.00', 'S', '', '1', '', '','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('11','NICOLE ANDREA ','TOBON HARMANS', 'PTOBONG@GMAIL.COM', 'V-20910736','Soltero(a)',	'1993-10-30','Femenino' ,'V-209107364', 
	'Miranda',	'CARACAS', 'CASA 746A AV.  PRINCIPAL , CUMBRES DE CURUMO, BARUTA,, CARACAS 1080', '02129784647','04142638554','2017-05-18','TDC', '0', 
	'Automóvil', 'Peugeot', '207 COMPACT','2012','GRIS','AA192DA','Sedán','5','10DBUY0030030', '-----','ACT', 
	'35000.00', '35000.00', 'S', '', '1', '', '','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('12','MEURYS ORANYELA','PERNIA ARAUJO', 'MEURYSPERNIA@GMAIL.COM', 'V-19598345','Soltero(a)',	'1988-02-01','Masculino' ,'V-195983450', 
	'Distrito Capital',	'CARACAS', 'CTRA VIEJA LOS TEQUES  CASA NRO  72 URB MAMERA CARACAS DISTRITO CAPITAL ZONA POSTAL 1100 ', '','04266751756','2017-05-24','TDC', '0', 
	'Automóvil', 'Ford', 'KA','2005','PLATA','GCI57F','Coupé','5','---------', '---------','ACT', 
	'35000.00', '35000.00', 'S', '', '1', '', '','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('13','ZOBEIDA AURISTELA','ALVARADO MOTA', 'ZOBEALVA@GMAIL.COM', 'V-11923602','Soltero(a)',	'1975-12-20','Femenino' ,'V-119236025', 
	'Distrito Capital',	'CARACAS', 'AVDA INTERCOMUNAL DE LOS JARDINES DEL VALLE,CALLE 17;  EDIF FENADE 13-03 EL VALLE CARACAS ', '02126824581','04142911041','2017-05-25','TDC', '0', 
	'Automóvil', 'Otra', 'TURPIAL ','2013','GRIS GRAFITO ','AJ771VA','Sedán','5','------', '8Y5420227DD001737','ACT', 
	'40932.90', '40932.90', 'S', '', '1', '', '','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('14','VICTOR MANUEL ','HERNANDEZ MACHISTE', '2017VICTORHERNANDEZ@GMAIL.COM', 'V-6890479','Soltero(a)',	'1963-04-18','Masculino' ,'V-68904796', 
	'Distrito Capital',	'CARACAS', 'AV ESTE 2 CON SUR 23. ESQUINA EL PATRONATO. EDF ESTE 2-152 PISO 3  OFICINA 31. LA CANDELARIA', '02125711649','04242572122','2017-05-25','DEP', '0', 
	'Automóvil', 'Chery', 'ARAUCA','2012','AZUL','AE665PG','Coupé','5','-----', '8X7F1B113CD005271','ACT', 
	'35000.00', '35000.00', 'S', '', '1', '', '','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('15','JUAN CARLOS','MARQUEZ RAMIREZ', 'MARQUEZ_JUANCARLO@YAHOO.COM', 'V-6910338','Soltero(a)',	'1963-06-04','Masculino' ,'V-105520922', 
	'Miranda',	'CARACAS', 'CALLE UNO EDIF RESID. LOS JARDINES TORRE A PISO 14 APTO 14-A URB. EL CIGARRAL', '02129632997','04164036371','2017-05-27','DEP', '0', 
	'Automóvil', 'Volkswagen', 'BORA COMFORTLIN','2008','BLANCO','BCI26V','Sedán','5','-------', '--------','ACT', 
	'40932.90', '40932.90', 'S', '', '1', '', '','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('16','JOHNNY RUFINO','DIAZ VIANA', 'JOHNNYZTE1948@GMAIL.COM', 'V-3364677','Casado(a)',	'1948-08-11','Masculino' ,'V-3364677', 
	'Distrito Capital',	'CARACAS', 'CALLE CHILE CON EUTEMIO RIVAS Nº56, LAS ACACIAS. MUNICIPIO LIBERTADOR CARACAS- VENEZUELA.', '02122508111','04142508111','2017-05-30','DEP', '0', 
	'Camioneta', 'Chevrolet', 'CAPTIVA ','2008','PLATA','AA335DO','Sport Wagon','5','-----', 'KL1DC63G18B195991','ACT', 
	'125932.90', '125932.90', 'S', '', '1', '', '','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('17','AMBAR ALEXANDRA DE JESUS','FAGUNDEZ POVEDA', 'AMBARFAGUN89@GMAIL.COM', 'V-21134647','Soltero(a)',	'1989-12-12','Femenino' ,'V-211346479', 
	'Miranda',	'CÚA', 'URB. JARDINES DE SANTA ROSA, CALLE 8, CASA 128', '02392122445','04120982244','2017-06-06','TDC', '0', 
	'Automóvil', 'Chery', 'ORINOCO','2014','PLATA','AH481PM','Sedán','5','----', '8X7T1C125ED008533','ACT', 
	'40932.90', '40932.90', 'S', '', '1', '', '','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('18','IVAN ELIECER','MOJICA SILVA', 'IVANMOJICA41@GMAIL.COM', 'V-14527009','Casado(a)',	'1981-08-08','Masculino' ,'V-145270096', 
	'Distrito Capital',	'CARACAS', 'MACARACUAY', '','04242126709','2017-06-07','TDC', '0', 
	'Automóvil', 'Kia', 'CERATO','2007','BEIGE','MEU39N','Sedán','5','----', 'KNAFE243275363988','ACT', 
	'40932.90', '40932.90', 'S', '', '1', '', '','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('19','CARLOS ALEXANDER DE JESUS','FAGUNDEZ POVEDA', 'CARL.FAG85@GMAIL.COM', 'V-17426036','Soltero(a)',	'1985-06-20','Masculino' ,'V-174260369', 
	'Miranda',	'CÚA ', 'URB. JARDINES DE SANTA ROSA, CALLE 8, CASA 128', '02392122445','04125678625','2017-06-08','TDC', '0', 
	'Automóvil', 'Chery', 'ORINOCO','2013','ROJO','AF390FG','Sedán','5','----', '8X7T1C125DD004447','ACT', 
	'40932.90', '40932.90', 'S', '', '1', '', '','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('26','GUILLERMO','RIOS', 'GUILEHR2008@GMAIL.COM', 'V-18010029','Soltero(a)',	'1987-02-24','Masculino' ,'V-18010029', 
	'Miranda',	'GUARENAS', 'URBANIZACIÓN TERRAZAS DEL ESTE', '02124429883','04148183254','2017-06-11','DEP', '0', 
	'Automóvil', 'Nissan', 'SENTRA B 13','2007','GRIS','NAV99E','Sedán','5','', '','ACT', 
	'35000.00', '35000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('27','MONICA DEL CARMEN','IBARRA ARRIA', 'MIBARRA@IMCP.GOB.VE', 'V-9483321','Soltero(a)',	'1969-06-23','Femenino' ,'V-9483321', 
	'Distrito Capital',	'CARACAS', 'SORDO A PELAEZ RED PUNTA DE PIEDAR TORRE B PS 3 APTO 39 SANTA ROSALIA', '02125456992','04166231264','2017-06-12','TDC', '0', 
	'Automóvil', 'Hyundai', 'ACCENT','2001','DORADO','MDM86A','Sedán','5','-------', '8X1VF21LP1YM03249','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('28','YORLENI EMILSE','CATALAN VALERA', 'LENIECV@HOTMAIL.COM', 'V-14017555','Soltero(a)',	'1979-12-20','Femenino' ,'V-14017555', 
	'Distrito Capital',	'CARACAS', 'CASA OLEANDER. URBANIZACIÓN ASOCODAZZI. MONTALBAN I.', '02124612850','04265169367','2017-06-13','DEP', '0', 
	'Automóvil', 'Chevrolet', 'SPARK','2007','GRIS','AE775AD','Sedán','5','----------------', '','ACT', 
	'28000.00', '28000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('29','CARLOS FERNANDO','BORGES VASQUEZ', 'SANDIEGOBORGES@HOTMAIL.COM', 'V-7057172','Casado(a)',	'1963-05-22','Masculino' ,'V-70571729', 
	'Carabobo',	'VALENCIA', 'VILLA VALENCIA TRANSVERSAL 7 #08-8 PARQUE VALENCIA', '02416353124','04143590995','2017-06-13','DEP', '0', 
	'Camioneta', 'Chevrolet', 'LUV D-MAX','2008','ALUMINIO','A31AB8A','Pick Up','5','-----', '8GGTFSJ798A164684','ACT', 
	'125932.90', '125932.90', 'S', '', '1', 'MAX 300 KM', 'ILIMITADO URBANO (*) Y UNO (01) EXTRAURBANO (*)','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('30','FIDEL ALEXANDER','CASTILLO MARQUEZ', 'FCBROADCAST@GMAIL.COM', 'V-12096264','Casado(a)',	'1974-10-02','Masculino' ,'V-12096264', 
	'Miranda',	'GUARENAS', 'AV SAN NICOLAS DE BARI, SEC EL ALAMBIQUE EDF 15 B APTO 13 URB NUEVA CASARAPA', '02123638592','04141395663','2017-06-14','DEP', '0', 
	'Automóvil', 'Toyota', 'COROLLA','2000','MARRON','AB215MA','Sedán','5','', '','ENV', 
	'35000.00', '35000.00', 'N', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('31','MARIA ALEJANDRA','CRUZ CASTILLO', 'MACDCT@GMAIL.COM', 'V-7226811','Soltero(a)',	'1965-02-17','Femenino' ,'V-072268110', 
	'Miranda',	'CARACAS', 'AV. PPAL. LOMAS DE CHUAO, QTA. ZELFA. URB. LOMAS DE CHUAO. BARUTA, MIRANDA', '02129936247','04241595236','2017-06-14','TDC', '0', 
	'Automóvil', 'Chery', 'ARAUCA','2012','GRIS','AE660PG','Hatchback','5','', '','ACT', 
	'35000.00', '35000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('32','FELIMAR DEL MILAGRO','IZAGUIRRE MONRROY', 'FELIMAR8220@GMAIL.COM', 'V-16264393','Soltero(a)',	'1982-09-20','Femenino' ,'V-16264393', 
	'Miranda',	'GUATIRE', 'EL INGENIO, MUNICIPIO ZAMORA, RES. LAS LOMAS APT. B6-34', '','04125847684','2017-06-14','DEP', '0', 
	'Automóvil', 'Chevrolet', 'SPARK','2012','BEIGE','AC425KD','Sedán','5','-------', '8Z1MD6A02CG313284','ACT', 
	'5932.90', '5932.90', 'S', '', '1', '', '','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('33','JOHANA DEL CARMEN','GUTIERREZ SANDOVAL', 'JOHANITA_BF@HOTMAIL.COM', 'V-21504301','Soltero(a)',	'1990-10-17','Femenino' ,'V-215043017', 
	'Lara',	'CABUDARE', 'URB LA MORA CONJUNTO 403 APTO C23 CABUDARE', '02512635225','04143505972','2017-06-15','TDC', '0', 
	'Automóvil', 'Ford', 'FIESTA','2007','AZUL','KBM52S','Hatchback','5','', '','ACT', 
	'35000.00', '35000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('34','AURA ARMINDA','TREJO MARIN', 'AURATREJO@GMAIL.COM', 'V-5017936','Soltero(a)',	'1956-10-22','Femenino' ,'V-5017936', 
	'Distrito Capital',	'CARACAS', 'AV. PAEZ, EDIF. PARAISO PLAZA, TORRE B, APTO 15-B4, EL PARAISO.', '02124628604','04146102876','2017-06-15','DEP', '0', 
	'Automóvil', 'Renault', 'LOGAN','2007','GRIS','MEX92J','Sedán','5','--------------', '9FBLSRAHB7M507271','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('35','ANAIS SOFIA','RIVAS FUENTES', 'ANAISRIVAS.26@GMAIL.COM', 'V-17514320','Soltero(a)',	'1986-08-26','Femenino' ,'V-175143200', 
	'Distrito Capital',	'CARACAS', 'AV. TEHERÁN C/CALLE 13, EDIF. RESIDENCIAS PARQUE 2, P-5, APTO 2B21, JUAN PABLO II, MONTALBAN. CCS', '02122092441','04141018888','2017-06-20','DEP', '0', 
	'Automóvil', 'Volkswagen', 'FOX','2008','GRIS','AF988IK','Sedán','5','', '','ACT', 
	'35000.00', '35000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('36','JAVIER MARIO','LORENZO PERSELLO', 'JAVLOR2000@YAHOO.COM', 'V-11567836','Soltero(a)',	'1975-09-03','Masculino' ,'V-11567836', 
	'Miranda',	'CARACAS', 'AV. SANZ, CALLE MOSENSOL CON PARIATA, EDIF. FRIULI, PISO 4 . APT. 12, EL MARQUES.', '02122385357','04269852937','2017-06-20','DEP', '0', 
	'Automóvil', 'Ford', 'KA','2006','BLANCO','TAL48J','Sedán','5','----------------', '8YPBGDAN668A11175','ACT', 
	'5932.90', '5932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('37','OMAR JESUS','SANCHEZ SANCHEZ', 'OJSS2612@GMAIL.COM', 'V-15606954','Soltero(a)',	'1981-12-26','Masculino' ,'V-156069546', 
	'Carabobo',	'VALENCIA', 'URB LOMAS DE LA HACIENDA PINAR 4 CASA 23 SAN DIEGO', '02418577988','04261332284','2017-06-21','TDC', '0', 
	'Automóvil', 'Dodge', 'BRISA','2005','AZUL','GCH59T','Sedán','5','-----', '8X1VF21LP5Y700489','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('38','VICTOR MANUEL FELIPE DE JESUS','HERRERA REQUENA', 'VMHERRER@SENIAT.GOB.VE', 'V-13686374','Soltero(a)',	'1978-05-07','Masculino' ,'V-13686374', 
	'Distrito Capital',	'CARACAS', 'AV. JOSE ANTONIO PAEZ, QTA. GRANADA, NRO 119, URB. EL PARAISO.', '','04166321101','2017-06-22','DEP', '0', 
	'Automóvil', 'Chevrolet', 'OPTRA','2008','PLATA','AA999VV','Sedán','5','', '','ACT', 
	'28000.00', '28000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('39','ALEXANDER','GARCIA', 'AGARCIA@ENAVAR.COM', 'V-12689892','Soltero(a)',	'1975-04-07','Masculino' ,'V-12689892', 
	'Miranda',	'CARACAS', 'CALLE LAS FLORES, EDIFICIO CAVALIER, PISO 7, APT 7-3 SABANA GRANDE.', '02127614097','04142059302','2017-06-22','DEP', '0', 
	'Automóvil', 'Chrysler', 'PT CRUISER','2004','ROJO','MDW51V','Sedán','5','', '','ACT', 
	'28000.00', '28000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('40','JUAN LUIS','FERNANDEZ MORENO', 'JFERNANDEZ.UCV@GMAIL.COM', 'V-17970565','Soltero(a)',	'1986-11-28','Masculino' ,'V-17970565', 
	'Distrito Capital',	'CARACAS', '......', '','04142288152','2017-06-22','DEP', '0', 
	'Automóvil', 'Ford', 'FIESTA','2004','AZUL','AI692RA','Sedán','5','', '','ACT', 
	'28000.00', '28000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('41','GUSTAVO ANTONIO','SARMIENTO VALERA GUTIERREZ', 'GSTVS7@GMAIL.COM', 'V-19205269','Soltero(a)',	'1986-10-20','Masculino' ,'V-19205269', 
	'Miranda',	'CARACAS', 'CALLE SORBONA, EDIFICIO SATURNO, PISO 2 APTO 2D, URBANIZACIÓN COLINAS DE BELLO MONTE', '02127513862','04168376486','2017-06-22','DEP', '0', 
	'Automóvil', 'Ford', 'FIESTA','2005','AZUL','SAZ76J','Sedán','5','', '','ACT', 
	'28000.00', '28000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('42','ADRIANA DEL CARMEN','CASARES CASTRO', 'ADRIANA_CASARES_CASTRO@HOTMAIL.COM', 'V-14203096','Soltero(a)',	'1980-06-18','Femenino' ,'V-142030965', 
	'Miranda',	'CARACAS', 'AV. NAIGUATA, RES. LA TINAJA, PISO 2, APTO. 21, MACARACUAY', '02122560458','04122560458','2017-06-26','DEP', '0', 
	'Automóvil', 'Chevrolet', 'OPTRA','2006','BLANCO DOS TONOS','AA984KW','Sedán','5','------', '9GAJM52316B055268','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('43','PEDRO VICENTE','PEREZ MARQUEZ', 'GENTEURBANA1@GMAIL.COM', 'V-6455924','Soltero(a)',	'1960-11-19','Masculino' ,'V-6455924', 
	'Miranda',	'LOS TEQUES', 'CALLE SUCRE, N° 19', '02123217770','04141571739','2017-06-26','DEP', '0', 
	'Camioneta', 'Ford', 'F-150','2005','GRIS','50NKAM','Pick Up','5','-------', '8YTRF172X58A46069','ACT', 
	'5932.90', '5932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('44','LILIANA DEL VALLE','GONZALEZ CARDOZO', 'LILIANA.GONZALEZ.CARDOZO@GMAIL.COM', 'V-18587602','Soltero(a)',	'1985-10-15','Femenino' ,'V-185876027', 
	'Miranda',	'CARACAS', 'AV. SUAPURE CON CALLE GUANIPA, RES. SIERRA DORADA, APTO 12-A, URB. COLINAS DE BELLO MONTE, MUNICIPIO BARUTA', '02127533688','04144051928','2017-06-29','TDC', '0', 
	'Automóvil', 'Chevrolet', 'AVEO LT','2011','BLANCO','AA813OK','Sedán','5','-----------', '8Z1TM5C67BV345245','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('45','BEBERLY TIBISAY','GARCIA CARRIZALES', 'BEVERLYGARCIA2003@HOTMAIL.COM', 'V-5279952','Soltero(a)',	'1961-07-15','Femenino' ,'V-5279952', 
	'Miranda',	'CARACAS', 'CALLE B, RESIDENCIAS EL BARON , PISO 1, APTO 11, SECTOR LOS PINOS, LA BOYERA', '02129632635','04164016016','2017-06-29','DEP', '0', 
	'Automóvil', 'Toyota', 'COROLLA','1997','ROJO','MAP46X','Sedán','5','----------', 'AE1019826708','ACT', 
	'5932.90', '5932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('46','DANIEL','SPADAFORA', 'DANIELSPA73@GMAIL.COM', 'V-17438135','Soltero(a)',	'1986-08-30','Masculino' ,'V-174381352', 
	'Distrito Capital',	'CARACAS', 'CALLE 1ERO  DE MAYO EDF SANTA ANA ALTAVISTA CATIA', '02128641565','04242727913','2017-06-30','TDC', '0', 
	'Automóvil', 'Renault', 'CLIO','2008','ROJO','AE606LA','Sedán','5','-----', '9FBBB1R0D8M004767','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('47','ENEYDA ISABEL','MARTINEZ LABARCA', 'DAVIDALFONZO940@HOTMAIL.COM', 'V-4938938','Soltero(a)',	'1957-09-28','Femenino' ,'V-049389380', 
	'Aragua',	'PALO NEGRO', 'RESIDENCIAS PALO NEGRO MANZANA H NUMERO 84 PRIMERA ETAPA SEGUNDA CALLE DETRAS DE LA PANADERIA PALO NEGRO', '02436351651','04126733338','2017-06-30','TDC', '0', 
	'Automóvil', 'Hyundai', 'GETZ','2008','GRIS','AA682RG','Sedán','5','', '','ENV', 
	'40932.90', '40932.90', 'N', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('48','ENEYDA ISABEL','MARTINEZ LABARCA', 'DAVIDALFONZO940@HOTMAIL.COM', 'V-4938938','Soltero(a)',	'1957-09-28','Femenino' ,'V-049389380', 
	'Aragua',	'PALO NEGRO', 'RESIDENCIAS PALO NEGRO MANZANA H NUMERO 84 PRIMERA ETAPA PALO NEGRO', '02436351651','04126733338','2017-06-30','TDC', '0', 
	'Automóvil', 'Hyundai', 'GETZ','2008','GRIS','AA692RG','Sedán','5','-----', '8X2BU51BP8B601747','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('49','GERMAN XAVIER','BRICENO RODRIGUEZ', 'BRICENOGERMAN@GMAIL.COM', 'V-2072757','Casado(a)',	'1944-10-17','Masculino' ,'V-2072757', 
	'Miranda',	'CARACAS', 'URB. VISTAEL VALLE, NRO 8, EL HATILLO-LA UNION', '02129638853','04142398378','2017-06-30','TDC', '0', 
	'Automóvil', 'Peugeot', '206','2008','GRIS','AHG71P','Sedán','5','10DBUG0011166', '8AD2AN6AD8G038098','ENV', 
	'5932.90', '5932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('50','GERMAN XAVIER','BRICENO RODRIGUEZ', 'BRICENOGERMAN@GMAIL.COM', 'V-2072757','Casado(a)',	'1944-10-17','Masculino' ,'V-2072757', 
	'Miranda',	'CARACAS', 'URB. VISTAEL VALLE, NRO 8, EL HATILLO-LA UNION', '02129638853','04142398378','2017-06-30','TDC', '0', 
	'Automóvil', 'Peugeot', '206','2008','GRIS','AHG71P','Sedán','5','10DBUG0011166', '8AD2AN6AD8G038098','ENV', 
	'5932.90', '5932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('51','ALEXANDER JOSE','DIOGO ', 'ALEXANDERDIOGO@HOTMAIL.COM', 'V-6479906','Casado(a)',	'1963-05-28','Masculino' ,'V-64799068', 
	'Miranda',	'CARACAS', 'URB. LAS ESMERALDAS EDIF. VISTA ESMERALDA', '02125761320','04140275738','2017-06-30','TDC', '0', 
	'Automóvil', 'Chery', 'ORINOCO','2013','ROJO','AH021NM','Sedán','5','', '','ENV', 
	'35000.00', '35000.00', 'N', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('52','ALEXANDER JOSE','DIOGO', 'ALEXANDERDIOGO@HOTMAIL.COM', 'V-6479906','Casado(a)',	'1963-05-28','Masculino' ,'V-64799068', 
	'Miranda',	'CARACAS', 'URB. LA ESMERALDA EDIF. VISTA ESMERALDA', '02125761320','04140275738','2017-06-30','DEP', '0', 
	'Automóvil', 'Chery', 'ORINOCO','2013','ROJO','AH021NM','Sedán','5','-------', '-------','ACT', 
	'35000.00', '35000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('53','ANTONIO ','MARTINEZ PREGO', 'AMARTINEZPREGO@GMAIL.COM', 'V-9967497','Casado(a)',	'1951-02-04','Masculino' ,'V-99674977', 
	'Miranda',	'CARACAS', 'CALLE SANTA LUISA, QUINTA RAY, NRO 125, URB. COLINAS DE LA CALIFORNIA. 1071', '02122570585','04142101068','2017-07-03','TDC', '0', 
	'Automóvil', 'Renault', 'SCENIC','2006','BEIGE','AF384OG','Sedán','5','-------', '93YJA1D326J626641','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('54','RICARDO AARON','NEGRON RIVAS', 'NEGRONRICARDO@HOTMAIL.COM', 'V-6322353','Soltero(a)',	'1969-02-02','Masculino' ,'V-063223537', 
	'Miranda',	'SAN ANTONIO DE LOS ALTOS', 'URB. LA ROSALEDA SUR, CALLE PRINCIPAL, EDIF. AROA, APT. 12-C, MUNICIPIO LOS SALIAS, SAN ANTONIO DE LOS ALTOS, ESTADO MIRANDA.', '02124356558','04241738040','2017-07-03','DEP', '0', 
	'Automóvil', 'Chevrolet', 'OPTRA','2007','ROJO','AGH93F','Sedán','5','------', 'KL1JM52B47K570898','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('55','MIGUEL ANGEL','TORTELLO', 'MIGUEL.TORTELLO@GMAIL.COM', 'V-8318405','Casado(a)',	'1962-11-04','Masculino' ,'V-083184058', 
	'Miranda',	'CARACAS', 'AV. RIO DE JANEIRO, EDIF EL PORTETE, PISO 2, APTO 2 A, URB. CHUAO', '02129912927','04248671223','2017-07-04','TDC', '0', 
	'Camioneta', 'Chevrolet', 'GRAN VITARA','2004','AZUL','TAK67L','Sport Wagon','5','-------', '8ZNCJ13C64V333497','ACT', 
	'35000.00', '35000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('56','FEDERICO JOSE','VELEIRO SENTIS', 'VELEIROFE@YAHOO.ES', 'V-5536268','Casado(a)',	'1958-02-08','Masculino' ,'V-5536268', 
	'Miranda',	'CARRIZAL', 'CARRETERA PANAMERICANA, KM 21, RESD. LAS MARGARITAS, TORRE B, APTO 12-A, SECTOR CORRALITO, MUNICIPIO CARRIZAL, ', '02127935073','04122158547','2017-07-05','DEP', '0', 
	'Rústico', 'Kia', 'SPORTAGE','2001','PLATA','AC142ZD','Sport Wagon','5','-------', '-------','ACT', 
	'28000.00', '28000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('57','MAYRA ALEJANDRA ','HERRERA PENALOZA', 'OKMAYRIS@GMAIL.COM', 'V-16071309','Soltero(a)',	'1983-08-08','Femenino' ,'V-160713093', 
	'Barinas',	'SOCOPO', 'BARRIO LAS FLORES  CARRETERA NACIONAL 0-664 ', '02739282174','04160322950','2017-07-06','TDC', '0', 
	'Automóvil', 'Chery', 'ARAUCA','2012','PLATA','AC379PD','Hatchback','5','', '','ENV', 
	'40932.90', '40932.90', 'N', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('58','MAYRA ALEJANDRA','HERRERA PENALOZA', 'OKMAYRIS@GMAIL.COM', 'V-16071309','Soltero(a)',	'1983-08-08','Femenino' ,'V-160713093', 
	'Barinas',	'SOCOPO', 'BARRIO LAS FLORES  CARRETERA NACIONAL 0-664', '02739282174','04160322950','2017-07-06','TDC', '0', 
	'Automóvil', 'Chery', 'ARAUCA','2012','PLATA','AC379PD','Hatchback','5','------------', '8X7F1B112CD006346','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('59','EDGAR ANTONIO','GONZALEZ CARRENO', 'EDGAR.GONZI@GMAIL.COM', 'V-4975541','Casado(a)',	'1961-01-16','Masculino' ,'V-49755410', 
	'Carabobo',	'VALENCIA', 'CALLE SAN DIEGO, NRO 85-140, EL TRIGAL CENTRO, PARROQIUIA SAN JOSÉ, MUNICIPIO VALENCIA', '02412410672','04166374674','2017-07-10','TDC', '0', 
	'Camioneta', 'Jeep', 'GRAND CHEROKEE','2006','BEIGE','OAL92B','Sport Wagon','5','-------', '8Y4G458N761104431','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('60','GUSTAVO HERVIS','MORALES LOIZ', 'GUSTAVOMORALESLOIZ@GMAIL.COM', 'V-12417462','Soltero(a)',	'1974-02-07','Masculino' ,'V-12417462', 
	'Miranda',	'CARACAS', 'URB. LOMAS DEL SOL, RES. VISTA AL PARQUE, TORRE A, APTO A31, LOS NARANJOS.', '02125168434','04127012410','2017-07-11','DEP', '0', 
	'Automóvil', 'Hyundai', 'ELANTRA','2009','PLATA','AA069JO','Sedán','5','-------', '-------','ACT', 
	'28000.00', '28000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('61','FIDES','MENDOZA CARRERO', 'FABY831@GMAIL.COM', 'V-1715274','Casado(a)',	'1935-10-07','Masculino' ,'V-1715274', 
	'Miranda',	'CARACAS', 'CALLE 8, QTA. ARICAGUA, #61, LOS SAMANES.', '02124358826','04122395996','2017-07-11','DEP', '0', 
	'Rústico', 'Daihatsu', 'TERIOS','2007','BEIGE','KBP76J','Sport Wagon','5','-------', '-------','ACT', 
	'28000.00', '28000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('62','TAHIRY SUSANGEL','LUQUES SILVEIRA', 'LUQUES.11S@GMAIL.COM', 'V-20911027','Soltero(a)',	'1991-04-10','Femenino' ,'V-20911027', 
	'Miranda',	'CARACAS', 'URBANIZACIÓN MACARACUAY, SECTOR EL ENCANTADO, CONJUNTO RESIDENCIAL EL ENCATADO, PRIMERA ETAPA, MUNICIPIO HATILLO', '02121170716','04241170716','2017-07-12','DEP', '0', 
	'Automóvil', 'Chevrolet', 'AVEO','2008','AZUL','AA257WV','Coupé','5','-----', '-------','ACT', 
	'28000.00', '28000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('63','MARLON RAMON','MARIN TOLEDO', 'MARLONMARIN19@HOTMAIL.COM', 'V-597473','Casado(a)',	'1962-07-27','Masculino' ,'V-597473', 
	'Anzoátegui',	'LECHERIAS', 'AV. R-8, EDIF 1, PISO 2, APTO 1-22, CONJUNTO RESIDENCIAL SIETE MARES.
', '02123815793','04143815793','2017-07-12','DEP', '0', 
	'Camioneta', 'Honda', 'CRV','2006','GRIS','AFT02J','Sport Wagon','5','--------', 'JHLRD78406C210673','ACT', 
	'5932.90', '5932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('64','CLODOMIRO DEL JESUS','ZACARIAS OCHEA', 'JZACK77@GMAIL.COM', 'V-13379760','Soltero(a)',	'1977-11-26','Masculino' ,'V-133797609', 
	'Distrito Capital',	'CARACAS', 'AV. SAN MARTIN URB LA QUEBRADITA 1 RES. LOS MOLINOS PISO 7 APTO 0701', '02124427461','04143159766','2017-07-13','DEP', '0', 
	'Automóvil', 'Chevrolet', 'OPTRA','2007','ROJO','AGR16T','Sedán','5','--------', 'KL1JM52BX7K694898','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('65','FERNANDO','SUAREZ GONZALEZ', 'TLOVENDOVZLA@GMAIL.COM', 'V-6974542','Soltero(a)',	'1966-10-14','Masculino' ,'V-6974542', 
	'Distrito Capital',	'CARACAS', 'AVENIDA PRINCIPAL DE MARIPEREZ, RESIDENCIAS MARIPEREZ, PISO 3, APARTAMENTO 31', '02127180753','04128232683','2017-07-13','DEP', '0', 
	'Automóvil', 'Renault', 'SCENIC','2008','VERDE','MFO37T','Sedán','5','------------', '---------------','ACT', 
	'28000.00', '28000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('66','PEDRO JOSE','LOUIS RODRIGUEZ', 'GRANPEDRO76@GMAIL.COM', 'V-12951584','Soltero(a)',	'1976-09-22','Masculino' ,'V-129515844', 
	'Distrito Capital',	'CARACAS', 'CARACAS, LA CANDELARIA, ESQ. VENUS, EDIF. INA.', '02125731947','04242527921','2017-07-14','TDC', '0', 
	'Automóvil', 'Chevrolet', 'CHEVY C2','2008','PLATA','AG111GM','Sedán','5','---------', '3G1SE51XX8S102857','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('67','CLAUDIO VICENTE','CAMEROTA ACOSTA', 'CLAUDIOCAMEROTA.93@GMAIL.COM', 'V-6558471','Casado(a)',	'1964-03-23','Masculino' ,'V-65584715', 
	'Miranda',	'CARACAS', 'CARACAS LA BOYERA URB EL CIGARRAL', '02129610554','04241232243','2017-07-14','TDC', '0', 
	'Camioneta', 'Jeep', 'GRAND CHEROKEE','2003','BEIGE','GCC53G','Cross Over','5','--------', '8Y4G248S531502989','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('68','THAIRIS YANINA','PEREZ MARQUEZ', 'SINAPIS2521@GMAIL.COM', 'V-16557400','Soltero(a)',	'1984-07-25','Femenino' ,'V-165574004', 
	'Distrito Capital',	'CARACAS', 'ESQUINA DE ALTAGRACIA A PUENTE MIRAFLORES, EDIF. AV. PISO 12, APTO 12E, LA PASTORA', '02128606349','04166213101','2017-07-17','DEP', '0', 
	'Camioneta', 'Jeep', 'GRAND CHEROKEE','1999','NEGRA','MBP41U','Sport Wagon','5','--------', '8Y4GW68FFX1904765','ACT', 
	'5932.90', '5932.90', 'S', '', '1', 'MAX 50 KM', 'TRES (03)','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('69','MARCOS','DE ANDRADE', 'DEANDRADEMARCOS@GMAIL.COM', 'V-18020594','Casado(a)',	'1986-03-24','Masculino' ,'V-18020594', 
	'Delta Amacuro',	'CARACAS', 'SFDFSDFSDF SFDFSDFSDFSDFSDFS', '02128601223','04268141850','2017-07-17','TDC', '0', 
	'Automóvil', 'Ford', 'KA','2006','BLANCO','AC137SK','Coupé','5','lfskjdflsjdfjsdfksjdlk', 'slfsfjlksdjfksdjflksjlfksjdlfjksldjfsd','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('70','MARCOS','DE ANDRADE', 'DEANDRADEMARCOS@GMAIL.COM', 'V-18020594','Divorciado(a)',	'2000-02-02','Masculino' ,'V-18020594', 
	'Distrito Capital',	'CARACAS', 'LDLFSDHFKJHSDKJFHSDKJFH SDFJHSJDFHKSJDHFKSDHFKSDHFS DFHSJDFHSJKDFHKSDFHKSJD', '02128601223','04268141850','2017-07-17','TDC', '0', 
	'Automóvil', 'Chevrolet', 'AVEO','2006','AZUL','AAABBB','Sedán','5','adas8d7a89d79a8s79d8a79s8d798a', 'asda9s87d8sa7d8s78d78s7ds54ds51s245fg45','ACT', 
	'5932.90', '5932.90', 'S', '', '1', '', '','0','');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('260','ALESSANDRO','COSTANTINI TATASCIORE', 'ALEXCOSTANTINI18@GMAIL.COM', 'V-21411814','Soltero(a)',	'1991-09-18','Masculino' ,'V-214118145', 
	'Miranda',	'CARACAS', 'AV. PRINCIPAL DE LA URBINA, EDIF. EL JARDIN, PISO 11, APTO 114, MUNICIPIO SUCRE.', '02122411214','04264112673','2017-04-27','TDC', '0', 
	'Automóvil', 'Hyundai', 'ACCENT','2002','DORADO','MDF77P','Sedán','5','', '','ACT', 
	'30.00', '33.00', 'S', '', '1', '', '','0','1');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('261','GUILLERMO','RIOS', 'GUILEHR2008@GMAIL.COM', 'V-18010029','Soltero(a)',	'1987-02-24','Masculino' ,'V-180100292', 
	'Distrito Capital',	'GUARENAS', 'GUARENAS, CLORIS TERRAZAS DEL ESTE', '02124429883','04148183254','2017-05-03','TDC', '0', 
	'Automóvil', 'Nissan', 'SENTRA B13','2007','GRIS','NAV99E','Sedán','5','', '','ENV', 
	'30000.00', '33000.00', 'N', '', '1', '', '','0','2');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('262','ENRIQUE JOSE','RANGEL LOBO', 'ENJO1274@GMAIL.COM', 'V-12352502','Casado(a)',	'1974-12-11','Masculino' ,'V-12352502', 
	'Miranda',	'MIRANDA', 'URBANIZACIÓN LOMAS DEL AVILA, PALO VERDE TERCERA ETAPA, EDIFICIO AVILA PLAZA, APATAMENTO 11-A. MIRANDA. ', '02122517416','04168051940','2017-05-08','TDC', '0', 
	'Automóvil', 'Chevrolet', 'SPARK','2013','AZUL','AB929EP','Sedán','5','-----', '8Z1MD6A00DG317268','ACT', 
	'30000.00', '33000.00', 'S', '', '1', '', '','0','3');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('263','MORELBA JOSEFINA ','MONTILLA PEREZ', 'MORELBAMONTILLA11@GMAIL.COM', 'V-5978510','Soltero(a)',	'1961-01-14','Femenino' ,'V-059785105', 
	'Miranda',	'CARACAS', 'AV ANDRES BELLO C/C 5TA TRANSVERSAL QUINTA DELGO LOS PALOS GRANDES CHACAO EDO MIRANDA', '02122835512','04242030712','2017-05-11','TDC', '0', 
	'Automóvil', 'Chevrolet', 'CORSA','2002','BEIGE','AG541OK','Coupé','5','52V319270', '8Z1SC21Z52V319270','ACT', 
	'35932.90', '38932.90', 'S', '', '1', '', '','0','4');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('264','RAFAEL RAMON','RODRIGUEZ ARRIOJAS', 'RAFAEL1978@GMAIL.COM', 'V-13458880','Casado(a)',	'1978-03-08','Masculino' ,'V-134588809', 
	'Distrito Capital',	'CARACAS', 'AV. LAS AMERICAS RES SAN FRANCISCO PISO 3 APTO 11 LAS ACACIAS. SAN PEDRO CARACAS.', '02126333905','04142177424','2017-05-11','TDC', '0', 
	'Automóvil', 'Ford', 'FIESTA','2010','GRIS','AD783GM','Sedán','5','-', '8YPZF16N9A8A44043','ACT', 
	'35932.90', '38932.90', 'S', '', '1', '', '','0','5');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('265','LINDA YUBIRI','GUTIERREZ RIVAS', 'LYGUTIERREZ@GMAIL.COM', 'V-10109648','Casado(a)',	'1970-11-15','Femenino' ,'V-101096480', 
	'Miranda',	'CARACAS', 'CALLE PRINCIPAL COLINA DE LA TAHONA, EDIF. TORRE C, PISO 4, APTO 42, URB. COLINAS DE LA TAHONA.', '02129423282','04142134344','2017-05-13','DEP', '0', 
	'Automóvil', 'Chevrolet', 'SPARK','2007','VERDE','VCL39D','Sedán','5','47V327344', '8Z1MJ60047V327344','ACT', 
	'35932.90', '38932.90', 'S', '', '1', '', '','0','6');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('266','JULIO CESAR','NIEVES LOPEZ', 'JULIOCNIEVES70@GMAIL.COM', 'V-11410423','Divorciado(a)',	'1970-11-03','Masculino' ,'V-114104236', 
	'Miranda',	'GUARENAS', 'URB. TERRAZAS DEL ESTE ED. 17 PISO 3 - 3 ZONA INDUSTRIAL CLORIS,  ', '02123628360','04128161824','2017-05-15','DEP', '0', 
	'Automóvil', 'Ford', 'FIESTA','2001','VERDE','AB694PW','Sedán','5','-1 A26169-', '8YPBP01C918A26169','ACT', 
	'35932.90', '38932.90', 'S', '', '1', '', '','0','7');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('267','MAIRA JOSEFINA','MARTINEZ DE MUNOZ', 'RJMUNOZR@HOTMAIL.COM', 'V-6819051','Casado(a)',	'1994-06-14','Femenino' ,'V-068190513', 
	'Miranda',	'CARACAS', 'CALLE COMERCIO EDIF. LE MONT DORE PISO 3 APT 31 URB. SAN LUIS.', '02128377911','04129225429','2017-05-16','TDC', '0', 
	'Camioneta', 'Chevrolet', 'GRAND VITARA','2001','BLANCO','AA552IO','Sport Wagon','5','-', '8LDFTD62V10000931','ACT', 
	'35000.00', '35000.00', 'S', '', '1', '', '','0','8');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('268','NICOLE ANDREA ','TOBON HARMANS', 'PTOBONG@GMAIL.COM', 'V-20910736','Soltero(a)',	'1993-10-30','Femenino' ,'V-209107364', 
	'Miranda',	'CARACAS', 'CASA 746A AV.  PRINCIPAL , CUMBRES DE CURUMO, BARUTA,, CARACAS 1080', '02129784647','04142638554','2017-05-18','TDC', '0', 
	'Automóvil', 'Peugeot', '207 COMPACT','2012','GRIS','AA192DA','Sedán','5','10DBUY0030030', '-----','ACT', 
	'35000.00', '35000.00', 'S', '', '1', '', '','0','11');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('269','MEURYS ORANYELA','PERNIA ARAUJO', 'MEURYSPERNIA@GMAIL.COM', 'V-19598345','Soltero(a)',	'1988-02-01','Masculino' ,'V-195983450', 
	'Distrito Capital',	'CARACAS', 'CTRA VIEJA LOS TEQUES  CASA NRO  72 URB MAMERA CARACAS DISTRITO CAPITAL ZONA POSTAL 1100 ', '','04266751756','2017-05-24','TDC', '0', 
	'Automóvil', 'Ford', 'KA','2005','PLATA','GCI57F','Coupé','5','---------', '---------','ACT', 
	'35000.00', '35000.00', 'S', '', '1', '', '','0','12');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('270','ZOBEIDA AURISTELA','ALVARADO MOTA', 'ZOBEALVA@GMAIL.COM', 'V-11923602','Soltero(a)',	'1975-12-20','Femenino' ,'V-119236025', 
	'Distrito Capital',	'CARACAS', 'AVDA INTERCOMUNAL DE LOS JARDINES DEL VALLE,CALLE 17;  EDIF FENADE 13-03 EL VALLE CARACAS ', '02126824581','04142911041','2017-05-25','TDC', '0', 
	'Automóvil', 'Otra', 'TURPIAL ','2013','GRIS GRAFITO ','AJ771VA','Sedán','5','------', '8Y5420227DD001737','ACT', 
	'40932.90', '40932.90', 'S', '', '1', '', '','0','13');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('271','VICTOR MANUEL ','HERNANDEZ MACHISTE', '2017VICTORHERNANDEZ@GMAIL.COM', 'V-6890479','Soltero(a)',	'1963-04-18','Masculino' ,'V-68904796', 
	'Distrito Capital',	'CARACAS', 'AV ESTE 2 CON SUR 23. ESQUINA EL PATRONATO. EDF ESTE 2-152 PISO 3  OFICINA 31. LA CANDELARIA', '02125711649','04242572122','2017-05-25','DEP', '0', 
	'Automóvil', 'Chery', 'ARAUCA','2012','AZUL','AE665PG','Coupé','5','-----', '8X7F1B113CD005271','ACT', 
	'35000.00', '35000.00', 'S', '', '1', '', '','0','14');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('272','JUAN CARLOS','MARQUEZ RAMIREZ', 'MARQUEZ_JUANCARLO@YAHOO.COM', 'V-6910338','Soltero(a)',	'1963-06-04','Masculino' ,'V-105520922', 
	'Miranda',	'CARACAS', 'CALLE UNO EDIF RESID. LOS JARDINES TORRE A PISO 14 APTO 14-A URB. EL CIGARRAL', '02129632997','04164036371','2017-05-27','DEP', '0', 
	'Automóvil', 'Volkswagen', 'BORA COMFORTLIN','2008','BLANCO','BCI26V','Sedán','5','-------', '--------','ACT', 
	'40932.90', '40932.90', 'S', '', '1', '', '','0','15');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('273','JOHNNY RUFINO','DIAZ VIANA', 'JOHNNYZTE1948@GMAIL.COM', 'V-3364677','Casado(a)',	'1948-08-11','Masculino' ,'V-3364677', 
	'Distrito Capital',	'CARACAS', 'CALLE CHILE CON EUTEMIO RIVAS Nº56, LAS ACACIAS. MUNICIPIO LIBERTADOR CARACAS- VENEZUELA.', '02122508111','04142508111','2017-05-30','DEP', '0', 
	'Camioneta', 'Chevrolet', 'CAPTIVA ','2008','PLATA','AA335DO','Sport Wagon','5','-----', 'KL1DC63G18B195991','ACT', 
	'125932.90', '125932.90', 'S', '', '1', '', '','0','16');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('274','AMBAR ALEXANDRA DE JESUS','FAGUNDEZ POVEDA', 'AMBARFAGUN89@GMAIL.COM', 'V-21134647','Soltero(a)',	'1989-12-12','Femenino' ,'V-211346479', 
	'Miranda',	'CÚA', 'URB. JARDINES DE SANTA ROSA, CALLE 8, CASA 128', '02392122445','04120982244','2017-06-06','TDC', '0', 
	'Automóvil', 'Chery', 'ORINOCO','2014','PLATA','AH481PM','Sedán','5','----', '8X7T1C125ED008533','ACT', 
	'40932.90', '40932.90', 'S', '', '1', '', '','0','17');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('275','IVAN ELIECER','MOJICA SILVA', 'IVANMOJICA41@GMAIL.COM', 'V-14527009','Casado(a)',	'1981-08-08','Masculino' ,'V-145270096', 
	'Distrito Capital',	'CARACAS', 'MACARACUAY', '','04242126709','2017-06-07','TDC', '0', 
	'Automóvil', 'Kia', 'CERATO','2007','BEIGE','MEU39N','Sedán','5','----', 'KNAFE243275363988','ACT', 
	'40932.90', '40932.90', 'S', '', '1', '', '','0','18');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('276','CARLOS ALEXANDER DE JESUS','FAGUNDEZ POVEDA', 'CARL.FAG85@GMAIL.COM', 'V-17426036','Soltero(a)',	'1985-06-20','Masculino' ,'V-174260369', 
	'Miranda',	'CÚA ', 'URB. JARDINES DE SANTA ROSA, CALLE 8, CASA 128', '02392122445','04125678625','2017-06-08','TDC', '0', 
	'Automóvil', 'Chery', 'ORINOCO','2013','ROJO','AF390FG','Sedán','5','----', '8X7T1C125DD004447','ACT', 
	'40932.90', '40932.90', 'S', '', '1', '', '','0','19');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('277','GUILLERMO','RIOS', 'GUILEHR2008@GMAIL.COM', 'V-18010029','Soltero(a)',	'1987-02-24','Masculino' ,'V-18010029', 
	'Miranda',	'GUARENAS', 'URBANIZACIÓN TERRAZAS DEL ESTE', '02124429883','04148183254','2017-06-11','DEP', '0', 
	'Automóvil', 'Nissan', 'SENTRA B 13','2007','GRIS','NAV99E','Sedán','5','', '','ACT', 
	'35000.00', '35000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','26');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('278','MONICA DEL CARMEN','IBARRA ARRIA', 'MIBARRA@IMCP.GOB.VE', 'V-9483321','Soltero(a)',	'1969-06-23','Femenino' ,'V-9483321', 
	'Distrito Capital',	'CARACAS', 'SORDO A PELAEZ RED PUNTA DE PIEDAR TORRE B PS 3 APTO 39 SANTA ROSALIA', '02125456992','04166231264','2017-06-12','TDC', '0', 
	'Automóvil', 'Hyundai', 'ACCENT','2001','DORADO','MDM86A','Sedán','5','-------', '8X1VF21LP1YM03249','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','27');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('279','YORLENI EMILSE','CATALAN VALERA', 'LENIECV@HOTMAIL.COM', 'V-14017555','Soltero(a)',	'1979-12-20','Femenino' ,'V-14017555', 
	'Distrito Capital',	'CARACAS', 'CASA OLEANDER. URBANIZACIÓN ASOCODAZZI. MONTALBAN I.', '02124612850','04265169367','2017-06-13','DEP', '0', 
	'Automóvil', 'Chevrolet', 'SPARK','2007','GRIS','AE775AD','Sedán','5','----------------', '','ACT', 
	'28000.00', '28000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','28');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('280','CARLOS FERNANDO','BORGES VASQUEZ', 'SANDIEGOBORGES@HOTMAIL.COM', 'V-7057172','Casado(a)',	'1963-05-22','Masculino' ,'V-70571729', 
	'Carabobo',	'VALENCIA', 'VILLA VALENCIA TRANSVERSAL 7 #08-8 PARQUE VALENCIA', '02416353124','04143590995','2017-06-13','DEP', '0', 
	'Camioneta', 'Chevrolet', 'LUV D-MAX','2008','ALUMINIO','A31AB8A','Pick Up','5','-----', '8GGTFSJ798A164684','ACT', 
	'125932.90', '125932.90', 'S', '', '1', 'MAX 300 KM', 'ILIMITADO URBANO (*) Y UNO (01) EXTRAURBANO (*)','0','29');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('281','FIDEL ALEXANDER','CASTILLO MARQUEZ', 'FCBROADCAST@GMAIL.COM', 'V-12096264','Casado(a)',	'1974-10-02','Masculino' ,'V-12096264', 
	'Miranda',	'GUARENAS', 'AV SAN NICOLAS DE BARI, SEC EL ALAMBIQUE EDF 15 B APTO 13 URB NUEVA CASARAPA', '02123638592','04141395663','2017-06-14','DEP', '0', 
	'Automóvil', 'Toyota', 'COROLLA','2000','MARRON','AB215MA','Sedán','5','', '','ENV', 
	'35000.00', '35000.00', 'N', '', '1', 'MAX 50 KM', 'ILIMITADO','0','30');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('282','MARIA ALEJANDRA','CRUZ CASTILLO', 'MACDCT@GMAIL.COM', 'V-7226811','Soltero(a)',	'1965-02-17','Femenino' ,'V-072268110', 
	'Miranda',	'CARACAS', 'AV. PPAL. LOMAS DE CHUAO, QTA. ZELFA. URB. LOMAS DE CHUAO. BARUTA, MIRANDA', '02129936247','04241595236','2017-06-14','TDC', '0', 
	'Automóvil', 'Chery', 'ARAUCA','2012','GRIS','AE660PG','Hatchback','5','', '','ACT', 
	'35000.00', '35000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','31');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('283','FELIMAR DEL MILAGRO','IZAGUIRRE MONRROY', 'FELIMAR8220@GMAIL.COM', 'V-16264393','Soltero(a)',	'1982-09-20','Femenino' ,'V-16264393', 
	'Miranda',	'GUATIRE', 'EL INGENIO, MUNICIPIO ZAMORA, RES. LAS LOMAS APT. B6-34', '','04125847684','2017-06-14','DEP', '0', 
	'Automóvil', 'Chevrolet', 'SPARK','2012','BEIGE','AC425KD','Sedán','5','-------', '8Z1MD6A02CG313284','ACT', 
	'5932.90', '5932.90', 'S', '', '1', '', '','0','32');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('284','JOHANA DEL CARMEN','GUTIERREZ SANDOVAL', 'JOHANITA_BF@HOTMAIL.COM', 'V-21504301','Soltero(a)',	'1990-10-17','Femenino' ,'V-215043017', 
	'Lara',	'CABUDARE', 'URB LA MORA CONJUNTO 403 APTO C23 CABUDARE', '02512635225','04143505972','2017-06-15','TDC', '0', 
	'Automóvil', 'Ford', 'FIESTA','2007','AZUL','KBM52S','Hatchback','5','', '','ACT', 
	'35000.00', '35000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','33');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('285','AURA ARMINDA','TREJO MARIN', 'AURATREJO@GMAIL.COM', 'V-5017936','Soltero(a)',	'1956-10-22','Femenino' ,'V-5017936', 
	'Distrito Capital',	'CARACAS', 'AV. PAEZ, EDIF. PARAISO PLAZA, TORRE B, APTO 15-B4, EL PARAISO.', '02124628604','04146102876','2017-06-15','DEP', '0', 
	'Automóvil', 'Renault', 'LOGAN','2007','GRIS','MEX92J','Sedán','5','--------------', '9FBLSRAHB7M507271','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','34');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('286','ANAIS SOFIA','RIVAS FUENTES', 'ANAISRIVAS.26@GMAIL.COM', 'V-17514320','Soltero(a)',	'1986-08-26','Femenino' ,'V-175143200', 
	'Distrito Capital',	'CARACAS', 'AV. TEHERÁN C/CALLE 13, EDIF. RESIDENCIAS PARQUE 2, P-5, APTO 2B21, JUAN PABLO II, MONTALBAN. CCS', '02122092441','04141018888','2017-06-20','DEP', '0', 
	'Automóvil', 'Volkswagen', 'FOX','2008','GRIS','AF988IK','Sedán','5','', '','ACT', 
	'35000.00', '35000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','35');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('287','JAVIER MARIO','LORENZO PERSELLO', 'JAVLOR2000@YAHOO.COM', 'V-11567836','Soltero(a)',	'1975-09-03','Masculino' ,'V-11567836', 
	'Miranda',	'CARACAS', 'AV. SANZ, CALLE MOSENSOL CON PARIATA, EDIF. FRIULI, PISO 4 . APT. 12, EL MARQUES.', '02122385357','04269852937','2017-06-20','DEP', '0', 
	'Automóvil', 'Ford', 'KA','2006','BLANCO','TAL48J','Sedán','5','----------------', '8YPBGDAN668A11175','ACT', 
	'5932.90', '5932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','36');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('288','OMAR JESUS','SANCHEZ SANCHEZ', 'OJSS2612@GMAIL.COM', 'V-15606954','Soltero(a)',	'1981-12-26','Masculino' ,'V-156069546', 
	'Carabobo',	'VALENCIA', 'URB LOMAS DE LA HACIENDA PINAR 4 CASA 23 SAN DIEGO', '02418577988','04261332284','2017-06-21','TDC', '0', 
	'Automóvil', 'Dodge', 'BRISA','2005','AZUL','GCH59T','Sedán','5','-----', '8X1VF21LP5Y700489','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','37');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('289','VICTOR MANUEL FELIPE DE JESUS','HERRERA REQUENA', 'VMHERRER@SENIAT.GOB.VE', 'V-13686374','Soltero(a)',	'1978-05-07','Masculino' ,'V-13686374', 
	'Distrito Capital',	'CARACAS', 'AV. JOSE ANTONIO PAEZ, QTA. GRANADA, NRO 119, URB. EL PARAISO.', '','04166321101','2017-06-22','DEP', '0', 
	'Automóvil', 'Chevrolet', 'OPTRA','2008','PLATA','AA999VV','Sedán','5','', '','ACT', 
	'28000.00', '28000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','38');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('290','ALEXANDER','GARCIA', 'AGARCIA@ENAVAR.COM', 'V-12689892','Soltero(a)',	'1975-04-07','Masculino' ,'V-12689892', 
	'Miranda',	'CARACAS', 'CALLE LAS FLORES, EDIFICIO CAVALIER, PISO 7, APT 7-3 SABANA GRANDE.', '02127614097','04142059302','2017-06-22','DEP', '0', 
	'Automóvil', 'Chrysler', 'PT CRUISER','2004','ROJO','MDW51V','Sedán','5','', '','ACT', 
	'28000.00', '28000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','39');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('291','JUAN LUIS','FERNANDEZ MORENO', 'JFERNANDEZ.UCV@GMAIL.COM', 'V-17970565','Soltero(a)',	'1986-11-28','Masculino' ,'V-17970565', 
	'Distrito Capital',	'CARACAS', '......', '','04142288152','2017-06-22','DEP', '0', 
	'Automóvil', 'Ford', 'FIESTA','2004','AZUL','AI692RA','Sedán','5','', '','ACT', 
	'28000.00', '28000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','40');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('292','GUSTAVO ANTONIO','SARMIENTO VALERA GUTIERREZ', 'GSTVS7@GMAIL.COM', 'V-19205269','Soltero(a)',	'1986-10-20','Masculino' ,'V-19205269', 
	'Miranda',	'CARACAS', 'CALLE SORBONA, EDIFICIO SATURNO, PISO 2 APTO 2D, URBANIZACIÓN COLINAS DE BELLO MONTE', '02127513862','04168376486','2017-06-22','DEP', '0', 
	'Automóvil', 'Ford', 'FIESTA','2005','AZUL','SAZ76J','Sedán','5','', '','ACT', 
	'28000.00', '28000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','41');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('293','ADRIANA DEL CARMEN','CASARES CASTRO', 'ADRIANA_CASARES_CASTRO@HOTMAIL.COM', 'V-14203096','Soltero(a)',	'1980-06-18','Femenino' ,'V-142030965', 
	'Miranda',	'CARACAS', 'AV. NAIGUATA, RES. LA TINAJA, PISO 2, APTO. 21, MACARACUAY', '02122560458','04122560458','2017-06-26','DEP', '0', 
	'Automóvil', 'Chevrolet', 'OPTRA','2006','BLANCO DOS TONOS','AA984KW','Sedán','5','------', '9GAJM52316B055268','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','42');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('294','PEDRO VICENTE','PEREZ MARQUEZ', 'GENTEURBANA1@GMAIL.COM', 'V-6455924','Soltero(a)',	'1960-11-19','Masculino' ,'V-6455924', 
	'Miranda',	'LOS TEQUES', 'CALLE SUCRE, N° 19', '02123217770','04141571739','2017-06-26','DEP', '0', 
	'Camioneta', 'Ford', 'F-150','2005','GRIS','50NKAM','Pick Up','5','-------', '8YTRF172X58A46069','ACT', 
	'5932.90', '5932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','43');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('295','LILIANA DEL VALLE','GONZALEZ CARDOZO', 'LILIANA.GONZALEZ.CARDOZO@GMAIL.COM', 'V-18587602','Soltero(a)',	'1985-10-15','Femenino' ,'V-185876027', 
	'Miranda',	'CARACAS', 'AV. SUAPURE CON CALLE GUANIPA, RES. SIERRA DORADA, APTO 12-A, URB. COLINAS DE BELLO MONTE, MUNICIPIO BARUTA', '02127533688','04144051928','2017-06-29','TDC', '0', 
	'Automóvil', 'Chevrolet', 'AVEO LT','2011','BLANCO','AA813OK','Sedán','5','-----------', '8Z1TM5C67BV345245','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','44');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('296','BEBERLY TIBISAY','GARCIA CARRIZALES', 'BEVERLYGARCIA2003@HOTMAIL.COM', 'V-5279952','Soltero(a)',	'1961-07-15','Femenino' ,'V-5279952', 
	'Miranda',	'CARACAS', 'CALLE B, RESIDENCIAS EL BARON , PISO 1, APTO 11, SECTOR LOS PINOS, LA BOYERA', '02129632635','04164016016','2017-06-29','DEP', '0', 
	'Automóvil', 'Toyota', 'COROLLA','1997','ROJO','MAP46X','Sedán','5','----------', 'AE1019826708','ACT', 
	'5932.90', '5932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','45');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('297','DANIEL','SPADAFORA', 'DANIELSPA73@GMAIL.COM', 'V-17438135','Soltero(a)',	'1986-08-30','Masculino' ,'V-174381352', 
	'Distrito Capital',	'CARACAS', 'CALLE 1ERO  DE MAYO EDF SANTA ANA ALTAVISTA CATIA', '02128641565','04242727913','2017-06-30','TDC', '0', 
	'Automóvil', 'Renault', 'CLIO','2008','ROJO','AE606LA','Sedán','5','-----', '9FBBB1R0D8M004767','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','46');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('298','ENEYDA ISABEL','MARTINEZ LABARCA', 'DAVIDALFONZO940@HOTMAIL.COM', 'V-4938938','Soltero(a)',	'1957-09-28','Femenino' ,'V-049389380', 
	'Aragua',	'PALO NEGRO', 'RESIDENCIAS PALO NEGRO MANZANA H NUMERO 84 PRIMERA ETAPA SEGUNDA CALLE DETRAS DE LA PANADERIA PALO NEGRO', '02436351651','04126733338','2017-06-30','TDC', '0', 
	'Automóvil', 'Hyundai', 'GETZ','2008','GRIS','AA682RG','Sedán','5','', '','ENV', 
	'40932.90', '40932.90', 'N', '', '1', 'MAX 50 KM', 'ILIMITADO','0','47');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('299','ENEYDA ISABEL','MARTINEZ LABARCA', 'DAVIDALFONZO940@HOTMAIL.COM', 'V-4938938','Soltero(a)',	'1957-09-28','Femenino' ,'V-049389380', 
	'Aragua',	'PALO NEGRO', 'RESIDENCIAS PALO NEGRO MANZANA H NUMERO 84 PRIMERA ETAPA PALO NEGRO', '02436351651','04126733338','2017-06-30','TDC', '0', 
	'Automóvil', 'Hyundai', 'GETZ','2008','GRIS','AA692RG','Sedán','5','-----', '8X2BU51BP8B601747','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','48');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('300','GERMAN XAVIER','BRICENO RODRIGUEZ', 'BRICENOGERMAN@GMAIL.COM', 'V-2072757','Casado(a)',	'1944-10-17','Masculino' ,'V-2072757', 
	'Miranda',	'CARACAS', 'URB. VISTAEL VALLE, NRO 8, EL HATILLO-LA UNION', '02129638853','04142398378','2017-06-30','TDC', '0', 
	'Automóvil', 'Peugeot', '206','2008','GRIS','AHG71P','Sedán','5','10DBUG0011166', '8AD2AN6AD8G038098','ENV', 
	'5932.90', '5932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','49');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('301','GERMAN XAVIER','BRICENO RODRIGUEZ', 'BRICENOGERMAN@GMAIL.COM', 'V-2072757','Casado(a)',	'1944-10-17','Masculino' ,'V-2072757', 
	'Miranda',	'CARACAS', 'URB. VISTAEL VALLE, NRO 8, EL HATILLO-LA UNION', '02129638853','04142398378','2017-06-30','TDC', '0', 
	'Automóvil', 'Peugeot', '206','2008','GRIS','AHG71P','Sedán','5','10DBUG0011166', '8AD2AN6AD8G038098','ENV', 
	'5932.90', '5932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','50');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('302','ALEXANDER JOSE','DIOGO ', 'ALEXANDERDIOGO@HOTMAIL.COM', 'V-6479906','Casado(a)',	'1963-05-28','Masculino' ,'V-64799068', 
	'Miranda',	'CARACAS', 'URB. LAS ESMERALDAS EDIF. VISTA ESMERALDA', '02125761320','04140275738','2017-06-30','TDC', '0', 
	'Automóvil', 'Chery', 'ORINOCO','2013','ROJO','AH021NM','Sedán','5','', '','ENV', 
	'35000.00', '35000.00', 'N', '', '1', 'MAX 50 KM', 'ILIMITADO','0','51');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('303','ALEXANDER JOSE','DIOGO', 'ALEXANDERDIOGO@HOTMAIL.COM', 'V-6479906','Casado(a)',	'1963-05-28','Masculino' ,'V-64799068', 
	'Miranda',	'CARACAS', 'URB. LA ESMERALDA EDIF. VISTA ESMERALDA', '02125761320','04140275738','2017-06-30','DEP', '0', 
	'Automóvil', 'Chery', 'ORINOCO','2013','ROJO','AH021NM','Sedán','5','-------', '-------','ACT', 
	'35000.00', '35000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','52');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('304','ANTONIO ','MARTINEZ PREGO', 'AMARTINEZPREGO@GMAIL.COM', 'V-9967497','Casado(a)',	'1951-02-04','Masculino' ,'V-99674977', 
	'Miranda',	'CARACAS', 'CALLE SANTA LUISA, QUINTA RAY, NRO 125, URB. COLINAS DE LA CALIFORNIA. 1071', '02122570585','04142101068','2017-07-03','TDC', '0', 
	'Automóvil', 'Renault', 'SCENIC','2006','BEIGE','AF384OG','Sedán','5','-------', '93YJA1D326J626641','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','53');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('305','RICARDO AARON','NEGRON RIVAS', 'NEGRONRICARDO@HOTMAIL.COM', 'V-6322353','Soltero(a)',	'1969-02-02','Masculino' ,'V-063223537', 
	'Miranda',	'SAN ANTONIO DE LOS ALTOS', 'URB. LA ROSALEDA SUR, CALLE PRINCIPAL, EDIF. AROA, APT. 12-C, MUNICIPIO LOS SALIAS, SAN ANTONIO DE LOS ALTOS, ESTADO MIRANDA.', '02124356558','04241738040','2017-07-03','DEP', '0', 
	'Automóvil', 'Chevrolet', 'OPTRA','2007','ROJO','AGH93F','Sedán','5','------', 'KL1JM52B47K570898','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','54');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('306','MIGUEL ANGEL','TORTELLO', 'MIGUEL.TORTELLO@GMAIL.COM', 'V-8318405','Casado(a)',	'1962-11-04','Masculino' ,'V-083184058', 
	'Miranda',	'CARACAS', 'AV. RIO DE JANEIRO, EDIF EL PORTETE, PISO 2, APTO 2 A, URB. CHUAO', '02129912927','04248671223','2017-07-04','TDC', '0', 
	'Camioneta', 'Chevrolet', 'GRAN VITARA','2004','AZUL','TAK67L','Sport Wagon','5','-------', '8ZNCJ13C64V333497','ACT', 
	'35000.00', '35000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','55');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('307','FEDERICO JOSE','VELEIRO SENTIS', 'VELEIROFE@YAHOO.ES', 'V-5536268','Casado(a)',	'1958-02-08','Masculino' ,'V-5536268', 
	'Miranda',	'CARRIZAL', 'CARRETERA PANAMERICANA, KM 21, RESD. LAS MARGARITAS, TORRE B, APTO 12-A, SECTOR CORRALITO, MUNICIPIO CARRIZAL, ', '02127935073','04122158547','2017-07-05','DEP', '0', 
	'Rústico', 'Kia', 'SPORTAGE','2001','PLATA','AC142ZD','Sport Wagon','5','-------', '-------','ACT', 
	'28000.00', '28000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','56');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('308','MAYRA ALEJANDRA ','HERRERA PENALOZA', 'OKMAYRIS@GMAIL.COM', 'V-16071309','Soltero(a)',	'1983-08-08','Femenino' ,'V-160713093', 
	'Barinas',	'SOCOPO', 'BARRIO LAS FLORES  CARRETERA NACIONAL 0-664 ', '02739282174','04160322950','2017-07-06','TDC', '0', 
	'Automóvil', 'Chery', 'ARAUCA','2012','PLATA','AC379PD','Hatchback','5','', '','ENV', 
	'40932.90', '40932.90', 'N', '', '1', 'MAX 50 KM', 'ILIMITADO','0','57');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('309','MAYRA ALEJANDRA','HERRERA PENALOZA', 'OKMAYRIS@GMAIL.COM', 'V-16071309','Soltero(a)',	'1983-08-08','Femenino' ,'V-160713093', 
	'Barinas',	'SOCOPO', 'BARRIO LAS FLORES  CARRETERA NACIONAL 0-664', '02739282174','04160322950','2017-07-06','TDC', '0', 
	'Automóvil', 'Chery', 'ARAUCA','2012','PLATA','AC379PD','Hatchback','5','------------', '8X7F1B112CD006346','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','58');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('310','EDGAR ANTONIO','GONZALEZ CARRENO', 'EDGAR.GONZI@GMAIL.COM', 'V-4975541','Casado(a)',	'1961-01-16','Masculino' ,'V-49755410', 
	'Carabobo',	'VALENCIA', 'CALLE SAN DIEGO, NRO 85-140, EL TRIGAL CENTRO, PARROQIUIA SAN JOSÉ, MUNICIPIO VALENCIA', '02412410672','04166374674','2017-07-10','TDC', '0', 
	'Camioneta', 'Jeep', 'GRAND CHEROKEE','2006','BEIGE','OAL92B','Sport Wagon','5','-------', '8Y4G458N761104431','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','59');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('311','GUSTAVO HERVIS','MORALES LOIZ', 'GUSTAVOMORALESLOIZ@GMAIL.COM', 'V-12417462','Soltero(a)',	'1974-02-07','Masculino' ,'V-12417462', 
	'Miranda',	'CARACAS', 'URB. LOMAS DEL SOL, RES. VISTA AL PARQUE, TORRE A, APTO A31, LOS NARANJOS.', '02125168434','04127012410','2017-07-11','DEP', '0', 
	'Automóvil', 'Hyundai', 'ELANTRA','2009','PLATA','AA069JO','Sedán','5','-------', '-------','ACT', 
	'28000.00', '28000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','60');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('312','FIDES','MENDOZA CARRERO', 'FABY831@GMAIL.COM', 'V-1715274','Casado(a)',	'1935-10-07','Masculino' ,'V-1715274', 
	'Miranda',	'CARACAS', 'CALLE 8, QTA. ARICAGUA, #61, LOS SAMANES.', '02124358826','04122395996','2017-07-11','DEP', '0', 
	'Rústico', 'Daihatsu', 'TERIOS','2007','BEIGE','KBP76J','Sport Wagon','5','-------', '-------','ACT', 
	'28000.00', '28000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','61');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('313','TAHIRY SUSANGEL','LUQUES SILVEIRA', 'LUQUES.11S@GMAIL.COM', 'V-20911027','Soltero(a)',	'1991-04-10','Femenino' ,'V-20911027', 
	'Miranda',	'CARACAS', 'URBANIZACIÓN MACARACUAY, SECTOR EL ENCANTADO, CONJUNTO RESIDENCIAL EL ENCATADO, PRIMERA ETAPA, MUNICIPIO HATILLO', '02121170716','04241170716','2017-07-12','DEP', '0', 
	'Automóvil', 'Chevrolet', 'AVEO','2008','AZUL','AA257WV','Coupé','5','-----', '-------','ACT', 
	'28000.00', '28000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','62');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('314','MARLON RAMON','MARIN TOLEDO', 'MARLONMARIN19@HOTMAIL.COM', 'V-597473','Casado(a)',	'1962-07-27','Masculino' ,'V-597473', 
	'Anzoátegui',	'LECHERIAS', 'AV. R-8, EDIF 1, PISO 2, APTO 1-22, CONJUNTO RESIDENCIAL SIETE MARES.
', '02123815793','04143815793','2017-07-12','DEP', '0', 
	'Camioneta', 'Honda', 'CRV','2006','GRIS','AFT02J','Sport Wagon','5','--------', 'JHLRD78406C210673','ACT', 
	'5932.90', '5932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','63');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('315','CLODOMIRO DEL JESUS','ZACARIAS OCHEA', 'JZACK77@GMAIL.COM', 'V-13379760','Soltero(a)',	'1977-11-26','Masculino' ,'V-133797609', 
	'Distrito Capital',	'CARACAS', 'AV. SAN MARTIN URB LA QUEBRADITA 1 RES. LOS MOLINOS PISO 7 APTO 0701', '02124427461','04143159766','2017-07-13','DEP', '0', 
	'Automóvil', 'Chevrolet', 'OPTRA','2007','ROJO','AGR16T','Sedán','5','--------', 'KL1JM52BX7K694898','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','64');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('316','FERNANDO','SUAREZ GONZALEZ', 'TLOVENDOVZLA@GMAIL.COM', 'V-6974542','Soltero(a)',	'1966-10-14','Masculino' ,'V-6974542', 
	'Distrito Capital',	'CARACAS', 'AVENIDA PRINCIPAL DE MARIPEREZ, RESIDENCIAS MARIPEREZ, PISO 3, APARTAMENTO 31', '02127180753','04128232683','2017-07-13','DEP', '0', 
	'Automóvil', 'Renault', 'SCENIC','2008','VERDE','MFO37T','Sedán','5','------------', '---------------','ACT', 
	'28000.00', '28000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','65');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('317','PEDRO JOSE','LOUIS RODRIGUEZ', 'GRANPEDRO76@GMAIL.COM', 'V-12951584','Soltero(a)',	'1976-09-22','Masculino' ,'V-129515844', 
	'Distrito Capital',	'CARACAS', 'CARACAS, LA CANDELARIA, ESQ. VENUS, EDIF. INA.', '02125731947','04242527921','2017-07-14','TDC', '0', 
	'Automóvil', 'Chevrolet', 'CHEVY C2','2008','PLATA','AG111GM','Sedán','5','---------', '3G1SE51XX8S102857','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','66');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('318','CLAUDIO VICENTE','CAMEROTA ACOSTA', 'CLAUDIOCAMEROTA.93@GMAIL.COM', 'V-6558471','Casado(a)',	'1964-03-23','Masculino' ,'V-65584715', 
	'Miranda',	'CARACAS', 'CARACAS LA BOYERA URB EL CIGARRAL', '02129610554','04241232243','2017-07-14','TDC', '0', 
	'Camioneta', 'Jeep', 'GRAND CHEROKEE','2003','BEIGE','GCC53G','Cross Over','5','--------', '8Y4G248S531502989','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','67');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('319','THAIRIS YANINA','PEREZ MARQUEZ', 'SINAPIS2521@GMAIL.COM', 'V-16557400','Soltero(a)',	'1984-07-25','Femenino' ,'V-165574004', 
	'Distrito Capital',	'CARACAS', 'ESQUINA DE ALTAGRACIA A PUENTE MIRAFLORES, EDIF. AV. PISO 12, APTO 12E, LA PASTORA', '02128606349','04166213101','2017-07-17','DEP', '0', 
	'Camioneta', 'Jeep', 'GRAND CHEROKEE','1999','NEGRA','MBP41U','Sport Wagon','5','--------', '8Y4GW68FFX1904765','ACT', 
	'5932.90', '5932.90', 'S', '', '1', 'MAX 50 KM', 'TRES (03)','0','68');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('320','MARCOS','DE ANDRADE', 'DEANDRADEMARCOS@GMAIL.COM', 'V-18020594','Casado(a)',	'1986-03-24','Masculino' ,'V-18020594', 
	'Delta Amacuro',	'CARACAS', 'SFDFSDFSDF SFDFSDFSDFSDFSDFS', '02128601223','04268141850','2017-07-17','TDC', '0', 
	'Automóvil', 'Ford', 'KA','2006','BLANCO','AC137SK','Coupé','5','lfskjdflsjdfjsdfksjdlk', 'slfsfjlksdjfksdjflksjlfksjdlfjksldjfsd','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','69');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('321','MARCOS','DE ANDRADE', 'DEANDRADEMARCOS@GMAIL.COM', 'V-18020594','Divorciado(a)',	'2000-02-02','Masculino' ,'V-18020594', 
	'Distrito Capital',	'CARACAS', 'LDLFSDHFKJHSDKJFHSDKJFH SDFJHSJDFHKSJDHFKSDHFKSDHFS DFHSJDFHSJKDFHKSDFHKSJD', '02128601223','04268141850','2017-07-17','TDC', '0', 
	'Automóvil', 'Chevrolet', 'AVEO','2006','AZUL','AAABBB','Sedán','5','adas8d7a89d79a8s79d8a79s8d798a', 'asda9s87d8sa7d8s78d78s7ds54ds51s245fg45','ACT', 
	'5932.90', '5932.90', 'S', '', '1', '', '','0','70');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('449','ALESSANDRO','COSTANTINI TATASCIORE', 'ALEXCOSTANTINI18@GMAIL.COM', 'V-21411814','Soltero(a)',	'1991-09-18','Masculino' ,'V-214118145', 
	'Miranda',	'CARACAS', 'AV. PRINCIPAL DE LA URBINA, EDIF. EL JARDIN, PISO 11, APTO 114, MUNICIPIO SUCRE.', '02122411214','04264112673','2017-04-27','TDC', '0', 
	'Automóvil', 'Hyundai', 'ACCENT','2002','DORADO','MDF77P','Sedán','5','', '','ACT', 
	'30.00', '33.00', 'S', '', '1', '', '','0','1');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('450','GUILLERMO','RIOS', 'GUILEHR2008@GMAIL.COM', 'V-18010029','Soltero(a)',	'1987-02-24','Masculino' ,'V-180100292', 
	'Distrito Capital',	'GUARENAS', 'GUARENAS, CLORIS TERRAZAS DEL ESTE', '02124429883','04148183254','2017-05-03','TDC', '0', 
	'Automóvil', 'Nissan', 'SENTRA B13','2007','GRIS','NAV99E','Sedán','5','', '','ENV', 
	'30000.00', '33000.00', 'N', '', '1', '', '','0','2');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('451','ENRIQUE JOSE','RANGEL LOBO', 'ENJO1274@GMAIL.COM', 'V-12352502','Casado(a)',	'1974-12-11','Masculino' ,'V-12352502', 
	'Miranda',	'MIRANDA', 'URBANIZACIÓN LOMAS DEL AVILA, PALO VERDE TERCERA ETAPA, EDIFICIO AVILA PLAZA, APATAMENTO 11-A. MIRANDA. ', '02122517416','04168051940','2017-05-08','TDC', '0', 
	'Automóvil', 'Chevrolet', 'SPARK','2013','AZUL','AB929EP','Sedán','5','-----', '8Z1MD6A00DG317268','ACT', 
	'30000.00', '33000.00', 'S', '', '1', '', '','0','3');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('452','MORELBA JOSEFINA ','MONTILLA PEREZ', 'MORELBAMONTILLA11@GMAIL.COM', 'V-5978510','Soltero(a)',	'1961-01-14','Femenino' ,'V-059785105', 
	'Miranda',	'CARACAS', 'AV ANDRES BELLO C/C 5TA TRANSVERSAL QUINTA DELGO LOS PALOS GRANDES CHACAO EDO MIRANDA', '02122835512','04242030712','2017-05-11','TDC', '0', 
	'Automóvil', 'Chevrolet', 'CORSA','2002','BEIGE','AG541OK','Coupé','5','52V319270', '8Z1SC21Z52V319270','ACT', 
	'35932.90', '38932.90', 'S', '', '1', '', '','0','4');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('453','RAFAEL RAMON','RODRIGUEZ ARRIOJAS', 'RAFAEL1978@GMAIL.COM', 'V-13458880','Casado(a)',	'1978-03-08','Masculino' ,'V-134588809', 
	'Distrito Capital',	'CARACAS', 'AV. LAS AMERICAS RES SAN FRANCISCO PISO 3 APTO 11 LAS ACACIAS. SAN PEDRO CARACAS.', '02126333905','04142177424','2017-05-11','TDC', '0', 
	'Automóvil', 'Ford', 'FIESTA','2010','GRIS','AD783GM','Sedán','5','-', '8YPZF16N9A8A44043','ACT', 
	'35932.90', '38932.90', 'S', '', '1', '', '','0','5');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('454','LINDA YUBIRI','GUTIERREZ RIVAS', 'LYGUTIERREZ@GMAIL.COM', 'V-10109648','Casado(a)',	'1970-11-15','Femenino' ,'V-101096480', 
	'Miranda',	'CARACAS', 'CALLE PRINCIPAL COLINA DE LA TAHONA, EDIF. TORRE C, PISO 4, APTO 42, URB. COLINAS DE LA TAHONA.', '02129423282','04142134344','2017-05-13','DEP', '0', 
	'Automóvil', 'Chevrolet', 'SPARK','2007','VERDE','VCL39D','Sedán','5','47V327344', '8Z1MJ60047V327344','ACT', 
	'35932.90', '38932.90', 'S', '', '1', '', '','0','6');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('455','JULIO CESAR','NIEVES LOPEZ', 'JULIOCNIEVES70@GMAIL.COM', 'V-11410423','Divorciado(a)',	'1970-11-03','Masculino' ,'V-114104236', 
	'Miranda',	'GUARENAS', 'URB. TERRAZAS DEL ESTE ED. 17 PISO 3 - 3 ZONA INDUSTRIAL CLORIS,  ', '02123628360','04128161824','2017-05-15','DEP', '0', 
	'Automóvil', 'Ford', 'FIESTA','2001','VERDE','AB694PW','Sedán','5','-1 A26169-', '8YPBP01C918A26169','ACT', 
	'35932.90', '38932.90', 'S', '', '1', '', '','0','7');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('456','MAIRA JOSEFINA','MARTINEZ DE MUNOZ', 'RJMUNOZR@HOTMAIL.COM', 'V-6819051','Casado(a)',	'1994-06-14','Femenino' ,'V-068190513', 
	'Miranda',	'CARACAS', 'CALLE COMERCIO EDIF. LE MONT DORE PISO 3 APT 31 URB. SAN LUIS.', '02128377911','04129225429','2017-05-16','TDC', '0', 
	'Camioneta', 'Chevrolet', 'GRAND VITARA','2001','BLANCO','AA552IO','Sport Wagon','5','-', '8LDFTD62V10000931','ACT', 
	'35000.00', '35000.00', 'S', '', '1', '', '','0','8');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('457','NICOLE ANDREA ','TOBON HARMANS', 'PTOBONG@GMAIL.COM', 'V-20910736','Soltero(a)',	'1993-10-30','Femenino' ,'V-209107364', 
	'Miranda',	'CARACAS', 'CASA 746A AV.  PRINCIPAL , CUMBRES DE CURUMO, BARUTA,, CARACAS 1080', '02129784647','04142638554','2017-05-18','TDC', '0', 
	'Automóvil', 'Peugeot', '207 COMPACT','2012','GRIS','AA192DA','Sedán','5','10DBUY0030030', '-----','ACT', 
	'35000.00', '35000.00', 'S', '', '1', '', '','0','11');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('458','MEURYS ORANYELA','PERNIA ARAUJO', 'MEURYSPERNIA@GMAIL.COM', 'V-19598345','Soltero(a)',	'1988-02-01','Masculino' ,'V-195983450', 
	'Distrito Capital',	'CARACAS', 'CTRA VIEJA LOS TEQUES  CASA NRO  72 URB MAMERA CARACAS DISTRITO CAPITAL ZONA POSTAL 1100 ', '','04266751756','2017-05-24','TDC', '0', 
	'Automóvil', 'Ford', 'KA','2005','PLATA','GCI57F','Coupé','5','---------', '---------','ACT', 
	'35000.00', '35000.00', 'S', '', '1', '', '','0','12');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('459','ZOBEIDA AURISTELA','ALVARADO MOTA', 'ZOBEALVA@GMAIL.COM', 'V-11923602','Soltero(a)',	'1975-12-20','Femenino' ,'V-119236025', 
	'Distrito Capital',	'CARACAS', 'AVDA INTERCOMUNAL DE LOS JARDINES DEL VALLE,CALLE 17;  EDIF FENADE 13-03 EL VALLE CARACAS ', '02126824581','04142911041','2017-05-25','TDC', '0', 
	'Automóvil', 'Otra', 'TURPIAL ','2013','GRIS GRAFITO ','AJ771VA','Sedán','5','------', '8Y5420227DD001737','ACT', 
	'40932.90', '40932.90', 'S', '', '1', '', '','0','13');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('460','VICTOR MANUEL ','HERNANDEZ MACHISTE', '2017VICTORHERNANDEZ@GMAIL.COM', 'V-6890479','Soltero(a)',	'1963-04-18','Masculino' ,'V-68904796', 
	'Distrito Capital',	'CARACAS', 'AV ESTE 2 CON SUR 23. ESQUINA EL PATRONATO. EDF ESTE 2-152 PISO 3  OFICINA 31. LA CANDELARIA', '02125711649','04242572122','2017-05-25','DEP', '0', 
	'Automóvil', 'Chery', 'ARAUCA','2012','AZUL','AE665PG','Coupé','5','-----', '8X7F1B113CD005271','ACT', 
	'35000.00', '35000.00', 'S', '', '1', '', '','0','14');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('461','JUAN CARLOS','MARQUEZ RAMIREZ', 'MARQUEZ_JUANCARLO@YAHOO.COM', 'V-6910338','Soltero(a)',	'1963-06-04','Masculino' ,'V-105520922', 
	'Miranda',	'CARACAS', 'CALLE UNO EDIF RESID. LOS JARDINES TORRE A PISO 14 APTO 14-A URB. EL CIGARRAL', '02129632997','04164036371','2017-05-27','DEP', '0', 
	'Automóvil', 'Volkswagen', 'BORA COMFORTLIN','2008','BLANCO','BCI26V','Sedán','5','-------', '--------','ACT', 
	'40932.90', '40932.90', 'S', '', '1', '', '','0','15');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('462','JOHNNY RUFINO','DIAZ VIANA', 'JOHNNYZTE1948@GMAIL.COM', 'V-3364677','Casado(a)',	'1948-08-11','Masculino' ,'V-3364677', 
	'Distrito Capital',	'CARACAS', 'CALLE CHILE CON EUTEMIO RIVAS Nº56, LAS ACACIAS. MUNICIPIO LIBERTADOR CARACAS- VENEZUELA.', '02122508111','04142508111','2017-05-30','DEP', '0', 
	'Camioneta', 'Chevrolet', 'CAPTIVA ','2008','PLATA','AA335DO','Sport Wagon','5','-----', 'KL1DC63G18B195991','ACT', 
	'125932.90', '125932.90', 'S', '', '1', '', '','0','16');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('463','AMBAR ALEXANDRA DE JESUS','FAGUNDEZ POVEDA', 'AMBARFAGUN89@GMAIL.COM', 'V-21134647','Soltero(a)',	'1989-12-12','Femenino' ,'V-211346479', 
	'Miranda',	'CÚA', 'URB. JARDINES DE SANTA ROSA, CALLE 8, CASA 128', '02392122445','04120982244','2017-06-06','TDC', '0', 
	'Automóvil', 'Chery', 'ORINOCO','2014','PLATA','AH481PM','Sedán','5','----', '8X7T1C125ED008533','ACT', 
	'40932.90', '40932.90', 'S', '', '1', '', '','0','17');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('464','IVAN ELIECER','MOJICA SILVA', 'IVANMOJICA41@GMAIL.COM', 'V-14527009','Casado(a)',	'1981-08-08','Masculino' ,'V-145270096', 
	'Distrito Capital',	'CARACAS', 'MACARACUAY', '','04242126709','2017-06-07','TDC', '0', 
	'Automóvil', 'Kia', 'CERATO','2007','BEIGE','MEU39N','Sedán','5','----', 'KNAFE243275363988','ACT', 
	'40932.90', '40932.90', 'S', '', '1', '', '','0','18');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('465','CARLOS ALEXANDER DE JESUS','FAGUNDEZ POVEDA', 'CARL.FAG85@GMAIL.COM', 'V-17426036','Soltero(a)',	'1985-06-20','Masculino' ,'V-174260369', 
	'Miranda',	'CÚA ', 'URB. JARDINES DE SANTA ROSA, CALLE 8, CASA 128', '02392122445','04125678625','2017-06-08','TDC', '0', 
	'Automóvil', 'Chery', 'ORINOCO','2013','ROJO','AF390FG','Sedán','5','----', '8X7T1C125DD004447','ACT', 
	'40932.90', '40932.90', 'S', '', '1', '', '','0','19');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('466','GUILLERMO','RIOS', 'GUILEHR2008@GMAIL.COM', 'V-18010029','Soltero(a)',	'1987-02-24','Masculino' ,'V-18010029', 
	'Miranda',	'GUARENAS', 'URBANIZACIÓN TERRAZAS DEL ESTE', '02124429883','04148183254','2017-06-11','DEP', '0', 
	'Automóvil', 'Nissan', 'SENTRA B 13','2007','GRIS','NAV99E','Sedán','5','', '','ACT', 
	'35000.00', '35000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','26');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('467','MONICA DEL CARMEN','IBARRA ARRIA', 'MIBARRA@IMCP.GOB.VE', 'V-9483321','Soltero(a)',	'1969-06-23','Femenino' ,'V-9483321', 
	'Distrito Capital',	'CARACAS', 'SORDO A PELAEZ RED PUNTA DE PIEDAR TORRE B PS 3 APTO 39 SANTA ROSALIA', '02125456992','04166231264','2017-06-12','TDC', '0', 
	'Automóvil', 'Hyundai', 'ACCENT','2001','DORADO','MDM86A','Sedán','5','-------', '8X1VF21LP1YM03249','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','27');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('468','YORLENI EMILSE','CATALAN VALERA', 'LENIECV@HOTMAIL.COM', 'V-14017555','Soltero(a)',	'1979-12-20','Femenino' ,'V-14017555', 
	'Distrito Capital',	'CARACAS', 'CASA OLEANDER. URBANIZACIÓN ASOCODAZZI. MONTALBAN I.', '02124612850','04265169367','2017-06-13','DEP', '0', 
	'Automóvil', 'Chevrolet', 'SPARK','2007','GRIS','AE775AD','Sedán','5','----------------', '','ACT', 
	'28000.00', '28000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','28');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('469','CARLOS FERNANDO','BORGES VASQUEZ', 'SANDIEGOBORGES@HOTMAIL.COM', 'V-7057172','Casado(a)',	'1963-05-22','Masculino' ,'V-70571729', 
	'Carabobo',	'VALENCIA', 'VILLA VALENCIA TRANSVERSAL 7 #08-8 PARQUE VALENCIA', '02416353124','04143590995','2017-06-13','DEP', '0', 
	'Camioneta', 'Chevrolet', 'LUV D-MAX','2008','ALUMINIO','A31AB8A','Pick Up','5','-----', '8GGTFSJ798A164684','ACT', 
	'125932.90', '125932.90', 'S', '', '1', 'MAX 300 KM', 'ILIMITADO URBANO (*) Y UNO (01) EXTRAURBANO (*)','0','29');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('470','FIDEL ALEXANDER','CASTILLO MARQUEZ', 'FCBROADCAST@GMAIL.COM', 'V-12096264','Casado(a)',	'1974-10-02','Masculino' ,'V-12096264', 
	'Miranda',	'GUARENAS', 'AV SAN NICOLAS DE BARI, SEC EL ALAMBIQUE EDF 15 B APTO 13 URB NUEVA CASARAPA', '02123638592','04141395663','2017-06-14','DEP', '0', 
	'Automóvil', 'Toyota', 'COROLLA','2000','MARRON','AB215MA','Sedán','5','', '','ENV', 
	'35000.00', '35000.00', 'N', '', '1', 'MAX 50 KM', 'ILIMITADO','0','30');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('471','MARIA ALEJANDRA','CRUZ CASTILLO', 'MACDCT@GMAIL.COM', 'V-7226811','Soltero(a)',	'1965-02-17','Femenino' ,'V-072268110', 
	'Miranda',	'CARACAS', 'AV. PPAL. LOMAS DE CHUAO, QTA. ZELFA. URB. LOMAS DE CHUAO. BARUTA, MIRANDA', '02129936247','04241595236','2017-06-14','TDC', '0', 
	'Automóvil', 'Chery', 'ARAUCA','2012','GRIS','AE660PG','Hatchback','5','', '','ACT', 
	'35000.00', '35000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','31');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('472','FELIMAR DEL MILAGRO','IZAGUIRRE MONRROY', 'FELIMAR8220@GMAIL.COM', 'V-16264393','Soltero(a)',	'1982-09-20','Femenino' ,'V-16264393', 
	'Miranda',	'GUATIRE', 'EL INGENIO, MUNICIPIO ZAMORA, RES. LAS LOMAS APT. B6-34', '','04125847684','2017-06-14','DEP', '0', 
	'Automóvil', 'Chevrolet', 'SPARK','2012','BEIGE','AC425KD','Sedán','5','-------', '8Z1MD6A02CG313284','ACT', 
	'5932.90', '5932.90', 'S', '', '1', '', '','0','32');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('473','JOHANA DEL CARMEN','GUTIERREZ SANDOVAL', 'JOHANITA_BF@HOTMAIL.COM', 'V-21504301','Soltero(a)',	'1990-10-17','Femenino' ,'V-215043017', 
	'Lara',	'CABUDARE', 'URB LA MORA CONJUNTO 403 APTO C23 CABUDARE', '02512635225','04143505972','2017-06-15','TDC', '0', 
	'Automóvil', 'Ford', 'FIESTA','2007','AZUL','KBM52S','Hatchback','5','', '','ACT', 
	'35000.00', '35000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','33');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('474','AURA ARMINDA','TREJO MARIN', 'AURATREJO@GMAIL.COM', 'V-5017936','Soltero(a)',	'1956-10-22','Femenino' ,'V-5017936', 
	'Distrito Capital',	'CARACAS', 'AV. PAEZ, EDIF. PARAISO PLAZA, TORRE B, APTO 15-B4, EL PARAISO.', '02124628604','04146102876','2017-06-15','DEP', '0', 
	'Automóvil', 'Renault', 'LOGAN','2007','GRIS','MEX92J','Sedán','5','--------------', '9FBLSRAHB7M507271','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','34');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('475','ANAIS SOFIA','RIVAS FUENTES', 'ANAISRIVAS.26@GMAIL.COM', 'V-17514320','Soltero(a)',	'1986-08-26','Femenino' ,'V-175143200', 
	'Distrito Capital',	'CARACAS', 'AV. TEHERÁN C/CALLE 13, EDIF. RESIDENCIAS PARQUE 2, P-5, APTO 2B21, JUAN PABLO II, MONTALBAN. CCS', '02122092441','04141018888','2017-06-20','DEP', '0', 
	'Automóvil', 'Volkswagen', 'FOX','2008','GRIS','AF988IK','Sedán','5','', '','ACT', 
	'35000.00', '35000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','35');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('476','JAVIER MARIO','LORENZO PERSELLO', 'JAVLOR2000@YAHOO.COM', 'V-11567836','Soltero(a)',	'1975-09-03','Masculino' ,'V-11567836', 
	'Miranda',	'CARACAS', 'AV. SANZ, CALLE MOSENSOL CON PARIATA, EDIF. FRIULI, PISO 4 . APT. 12, EL MARQUES.', '02122385357','04269852937','2017-06-20','DEP', '0', 
	'Automóvil', 'Ford', 'KA','2006','BLANCO','TAL48J','Sedán','5','----------------', '8YPBGDAN668A11175','ACT', 
	'5932.90', '5932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','36');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('477','OMAR JESUS','SANCHEZ SANCHEZ', 'OJSS2612@GMAIL.COM', 'V-15606954','Soltero(a)',	'1981-12-26','Masculino' ,'V-156069546', 
	'Carabobo',	'VALENCIA', 'URB LOMAS DE LA HACIENDA PINAR 4 CASA 23 SAN DIEGO', '02418577988','04261332284','2017-06-21','TDC', '0', 
	'Automóvil', 'Dodge', 'BRISA','2005','AZUL','GCH59T','Sedán','5','-----', '8X1VF21LP5Y700489','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','37');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('478','VICTOR MANUEL FELIPE DE JESUS','HERRERA REQUENA', 'VMHERRER@SENIAT.GOB.VE', 'V-13686374','Soltero(a)',	'1978-05-07','Masculino' ,'V-13686374', 
	'Distrito Capital',	'CARACAS', 'AV. JOSE ANTONIO PAEZ, QTA. GRANADA, NRO 119, URB. EL PARAISO.', '','04166321101','2017-06-22','DEP', '0', 
	'Automóvil', 'Chevrolet', 'OPTRA','2008','PLATA','AA999VV','Sedán','5','', '','ACT', 
	'28000.00', '28000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','38');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('479','ALEXANDER','GARCIA', 'AGARCIA@ENAVAR.COM', 'V-12689892','Soltero(a)',	'1975-04-07','Masculino' ,'V-12689892', 
	'Miranda',	'CARACAS', 'CALLE LAS FLORES, EDIFICIO CAVALIER, PISO 7, APT 7-3 SABANA GRANDE.', '02127614097','04142059302','2017-06-22','DEP', '0', 
	'Automóvil', 'Chrysler', 'PT CRUISER','2004','ROJO','MDW51V','Sedán','5','', '','ACT', 
	'28000.00', '28000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','39');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('480','JUAN LUIS','FERNANDEZ MORENO', 'JFERNANDEZ.UCV@GMAIL.COM', 'V-17970565','Soltero(a)',	'1986-11-28','Masculino' ,'V-17970565', 
	'Distrito Capital',	'CARACAS', '......', '','04142288152','2017-06-22','DEP', '0', 
	'Automóvil', 'Ford', 'FIESTA','2004','AZUL','AI692RA','Sedán','5','', '','ACT', 
	'28000.00', '28000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','40');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('481','GUSTAVO ANTONIO','SARMIENTO VALERA GUTIERREZ', 'GSTVS7@GMAIL.COM', 'V-19205269','Soltero(a)',	'1986-10-20','Masculino' ,'V-19205269', 
	'Miranda',	'CARACAS', 'CALLE SORBONA, EDIFICIO SATURNO, PISO 2 APTO 2D, URBANIZACIÓN COLINAS DE BELLO MONTE', '02127513862','04168376486','2017-06-22','DEP', '0', 
	'Automóvil', 'Ford', 'FIESTA','2005','AZUL','SAZ76J','Sedán','5','', '','ACT', 
	'28000.00', '28000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','41');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('482','ADRIANA DEL CARMEN','CASARES CASTRO', 'ADRIANA_CASARES_CASTRO@HOTMAIL.COM', 'V-14203096','Soltero(a)',	'1980-06-18','Femenino' ,'V-142030965', 
	'Miranda',	'CARACAS', 'AV. NAIGUATA, RES. LA TINAJA, PISO 2, APTO. 21, MACARACUAY', '02122560458','04122560458','2017-06-26','DEP', '0', 
	'Automóvil', 'Chevrolet', 'OPTRA','2006','BLANCO DOS TONOS','AA984KW','Sedán','5','------', '9GAJM52316B055268','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','42');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('483','PEDRO VICENTE','PEREZ MARQUEZ', 'GENTEURBANA1@GMAIL.COM', 'V-6455924','Soltero(a)',	'1960-11-19','Masculino' ,'V-6455924', 
	'Miranda',	'LOS TEQUES', 'CALLE SUCRE, N° 19', '02123217770','04141571739','2017-06-26','DEP', '0', 
	'Camioneta', 'Ford', 'F-150','2005','GRIS','50NKAM','Pick Up','5','-------', '8YTRF172X58A46069','ACT', 
	'5932.90', '5932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','43');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('484','LILIANA DEL VALLE','GONZALEZ CARDOZO', 'LILIANA.GONZALEZ.CARDOZO@GMAIL.COM', 'V-18587602','Soltero(a)',	'1985-10-15','Femenino' ,'V-185876027', 
	'Miranda',	'CARACAS', 'AV. SUAPURE CON CALLE GUANIPA, RES. SIERRA DORADA, APTO 12-A, URB. COLINAS DE BELLO MONTE, MUNICIPIO BARUTA', '02127533688','04144051928','2017-06-29','TDC', '0', 
	'Automóvil', 'Chevrolet', 'AVEO LT','2011','BLANCO','AA813OK','Sedán','5','-----------', '8Z1TM5C67BV345245','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','44');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('485','BEBERLY TIBISAY','GARCIA CARRIZALES', 'BEVERLYGARCIA2003@HOTMAIL.COM', 'V-5279952','Soltero(a)',	'1961-07-15','Femenino' ,'V-5279952', 
	'Miranda',	'CARACAS', 'CALLE B, RESIDENCIAS EL BARON , PISO 1, APTO 11, SECTOR LOS PINOS, LA BOYERA', '02129632635','04164016016','2017-06-29','DEP', '0', 
	'Automóvil', 'Toyota', 'COROLLA','1997','ROJO','MAP46X','Sedán','5','----------', 'AE1019826708','ACT', 
	'5932.90', '5932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','45');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('486','DANIEL','SPADAFORA', 'DANIELSPA73@GMAIL.COM', 'V-17438135','Soltero(a)',	'1986-08-30','Masculino' ,'V-174381352', 
	'Distrito Capital',	'CARACAS', 'CALLE 1ERO  DE MAYO EDF SANTA ANA ALTAVISTA CATIA', '02128641565','04242727913','2017-06-30','TDC', '0', 
	'Automóvil', 'Renault', 'CLIO','2008','ROJO','AE606LA','Sedán','5','-----', '9FBBB1R0D8M004767','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','46');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('487','ENEYDA ISABEL','MARTINEZ LABARCA', 'DAVIDALFONZO940@HOTMAIL.COM', 'V-4938938','Soltero(a)',	'1957-09-28','Femenino' ,'V-049389380', 
	'Aragua',	'PALO NEGRO', 'RESIDENCIAS PALO NEGRO MANZANA H NUMERO 84 PRIMERA ETAPA SEGUNDA CALLE DETRAS DE LA PANADERIA PALO NEGRO', '02436351651','04126733338','2017-06-30','TDC', '0', 
	'Automóvil', 'Hyundai', 'GETZ','2008','GRIS','AA682RG','Sedán','5','', '','ENV', 
	'40932.90', '40932.90', 'N', '', '1', 'MAX 50 KM', 'ILIMITADO','0','47');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('488','ENEYDA ISABEL','MARTINEZ LABARCA', 'DAVIDALFONZO940@HOTMAIL.COM', 'V-4938938','Soltero(a)',	'1957-09-28','Femenino' ,'V-049389380', 
	'Aragua',	'PALO NEGRO', 'RESIDENCIAS PALO NEGRO MANZANA H NUMERO 84 PRIMERA ETAPA PALO NEGRO', '02436351651','04126733338','2017-06-30','TDC', '0', 
	'Automóvil', 'Hyundai', 'GETZ','2008','GRIS','AA692RG','Sedán','5','-----', '8X2BU51BP8B601747','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','48');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('489','GERMAN XAVIER','BRICENO RODRIGUEZ', 'BRICENOGERMAN@GMAIL.COM', 'V-2072757','Casado(a)',	'1944-10-17','Masculino' ,'V-2072757', 
	'Miranda',	'CARACAS', 'URB. VISTAEL VALLE, NRO 8, EL HATILLO-LA UNION', '02129638853','04142398378','2017-06-30','TDC', '0', 
	'Automóvil', 'Peugeot', '206','2008','GRIS','AHG71P','Sedán','5','10DBUG0011166', '8AD2AN6AD8G038098','ENV', 
	'5932.90', '5932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','49');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('490','GERMAN XAVIER','BRICENO RODRIGUEZ', 'BRICENOGERMAN@GMAIL.COM', 'V-2072757','Casado(a)',	'1944-10-17','Masculino' ,'V-2072757', 
	'Miranda',	'CARACAS', 'URB. VISTAEL VALLE, NRO 8, EL HATILLO-LA UNION', '02129638853','04142398378','2017-06-30','TDC', '0', 
	'Automóvil', 'Peugeot', '206','2008','GRIS','AHG71P','Sedán','5','10DBUG0011166', '8AD2AN6AD8G038098','ENV', 
	'5932.90', '5932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','50');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('491','ALEXANDER JOSE','DIOGO ', 'ALEXANDERDIOGO@HOTMAIL.COM', 'V-6479906','Casado(a)',	'1963-05-28','Masculino' ,'V-64799068', 
	'Miranda',	'CARACAS', 'URB. LAS ESMERALDAS EDIF. VISTA ESMERALDA', '02125761320','04140275738','2017-06-30','TDC', '0', 
	'Automóvil', 'Chery', 'ORINOCO','2013','ROJO','AH021NM','Sedán','5','', '','ENV', 
	'35000.00', '35000.00', 'N', '', '1', 'MAX 50 KM', 'ILIMITADO','0','51');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('492','ALEXANDER JOSE','DIOGO', 'ALEXANDERDIOGO@HOTMAIL.COM', 'V-6479906','Casado(a)',	'1963-05-28','Masculino' ,'V-64799068', 
	'Miranda',	'CARACAS', 'URB. LA ESMERALDA EDIF. VISTA ESMERALDA', '02125761320','04140275738','2017-06-30','DEP', '0', 
	'Automóvil', 'Chery', 'ORINOCO','2013','ROJO','AH021NM','Sedán','5','-------', '-------','ACT', 
	'35000.00', '35000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','52');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('493','ANTONIO ','MARTINEZ PREGO', 'AMARTINEZPREGO@GMAIL.COM', 'V-9967497','Casado(a)',	'1951-02-04','Masculino' ,'V-99674977', 
	'Miranda',	'CARACAS', 'CALLE SANTA LUISA, QUINTA RAY, NRO 125, URB. COLINAS DE LA CALIFORNIA. 1071', '02122570585','04142101068','2017-07-03','TDC', '0', 
	'Automóvil', 'Renault', 'SCENIC','2006','BEIGE','AF384OG','Sedán','5','-------', '93YJA1D326J626641','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','53');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('494','RICARDO AARON','NEGRON RIVAS', 'NEGRONRICARDO@HOTMAIL.COM', 'V-6322353','Soltero(a)',	'1969-02-02','Masculino' ,'V-063223537', 
	'Miranda',	'SAN ANTONIO DE LOS ALTOS', 'URB. LA ROSALEDA SUR, CALLE PRINCIPAL, EDIF. AROA, APT. 12-C, MUNICIPIO LOS SALIAS, SAN ANTONIO DE LOS ALTOS, ESTADO MIRANDA.', '02124356558','04241738040','2017-07-03','DEP', '0', 
	'Automóvil', 'Chevrolet', 'OPTRA','2007','ROJO','AGH93F','Sedán','5','------', 'KL1JM52B47K570898','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','54');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('495','MIGUEL ANGEL','TORTELLO', 'MIGUEL.TORTELLO@GMAIL.COM', 'V-8318405','Casado(a)',	'1962-11-04','Masculino' ,'V-083184058', 
	'Miranda',	'CARACAS', 'AV. RIO DE JANEIRO, EDIF EL PORTETE, PISO 2, APTO 2 A, URB. CHUAO', '02129912927','04248671223','2017-07-04','TDC', '0', 
	'Camioneta', 'Chevrolet', 'GRAN VITARA','2004','AZUL','TAK67L','Sport Wagon','5','-------', '8ZNCJ13C64V333497','ACT', 
	'35000.00', '35000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','55');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('496','FEDERICO JOSE','VELEIRO SENTIS', 'VELEIROFE@YAHOO.ES', 'V-5536268','Casado(a)',	'1958-02-08','Masculino' ,'V-5536268', 
	'Miranda',	'CARRIZAL', 'CARRETERA PANAMERICANA, KM 21, RESD. LAS MARGARITAS, TORRE B, APTO 12-A, SECTOR CORRALITO, MUNICIPIO CARRIZAL, ', '02127935073','04122158547','2017-07-05','DEP', '0', 
	'Rústico', 'Kia', 'SPORTAGE','2001','PLATA','AC142ZD','Sport Wagon','5','-------', '-------','ACT', 
	'28000.00', '28000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','56');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('497','MAYRA ALEJANDRA ','HERRERA PENALOZA', 'OKMAYRIS@GMAIL.COM', 'V-16071309','Soltero(a)',	'1983-08-08','Femenino' ,'V-160713093', 
	'Barinas',	'SOCOPO', 'BARRIO LAS FLORES  CARRETERA NACIONAL 0-664 ', '02739282174','04160322950','2017-07-06','TDC', '0', 
	'Automóvil', 'Chery', 'ARAUCA','2012','PLATA','AC379PD','Hatchback','5','', '','ENV', 
	'40932.90', '40932.90', 'N', '', '1', 'MAX 50 KM', 'ILIMITADO','0','57');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('498','MAYRA ALEJANDRA','HERRERA PENALOZA', 'OKMAYRIS@GMAIL.COM', 'V-16071309','Soltero(a)',	'1983-08-08','Femenino' ,'V-160713093', 
	'Barinas',	'SOCOPO', 'BARRIO LAS FLORES  CARRETERA NACIONAL 0-664', '02739282174','04160322950','2017-07-06','TDC', '0', 
	'Automóvil', 'Chery', 'ARAUCA','2012','PLATA','AC379PD','Hatchback','5','------------', '8X7F1B112CD006346','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','58');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('499','EDGAR ANTONIO','GONZALEZ CARRENO', 'EDGAR.GONZI@GMAIL.COM', 'V-4975541','Casado(a)',	'1961-01-16','Masculino' ,'V-49755410', 
	'Carabobo',	'VALENCIA', 'CALLE SAN DIEGO, NRO 85-140, EL TRIGAL CENTRO, PARROQIUIA SAN JOSÉ, MUNICIPIO VALENCIA', '02412410672','04166374674','2017-07-10','TDC', '0', 
	'Camioneta', 'Jeep', 'GRAND CHEROKEE','2006','BEIGE','OAL92B','Sport Wagon','5','-------', '8Y4G458N761104431','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','59');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('500','GUSTAVO HERVIS','MORALES LOIZ', 'GUSTAVOMORALESLOIZ@GMAIL.COM', 'V-12417462','Soltero(a)',	'1974-02-07','Masculino' ,'V-12417462', 
	'Miranda',	'CARACAS', 'URB. LOMAS DEL SOL, RES. VISTA AL PARQUE, TORRE A, APTO A31, LOS NARANJOS.', '02125168434','04127012410','2017-07-11','DEP', '0', 
	'Automóvil', 'Hyundai', 'ELANTRA','2009','PLATA','AA069JO','Sedán','5','-------', '-------','ACT', 
	'28000.00', '28000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','60');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('501','FIDES','MENDOZA CARRERO', 'FABY831@GMAIL.COM', 'V-1715274','Casado(a)',	'1935-10-07','Masculino' ,'V-1715274', 
	'Miranda',	'CARACAS', 'CALLE 8, QTA. ARICAGUA, #61, LOS SAMANES.', '02124358826','04122395996','2017-07-11','DEP', '0', 
	'Rústico', 'Daihatsu', 'TERIOS','2007','BEIGE','KBP76J','Sport Wagon','5','-------', '-------','ACT', 
	'28000.00', '28000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','61');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('502','TAHIRY SUSANGEL','LUQUES SILVEIRA', 'LUQUES.11S@GMAIL.COM', 'V-20911027','Soltero(a)',	'1991-04-10','Femenino' ,'V-20911027', 
	'Miranda',	'CARACAS', 'URBANIZACIÓN MACARACUAY, SECTOR EL ENCANTADO, CONJUNTO RESIDENCIAL EL ENCATADO, PRIMERA ETAPA, MUNICIPIO HATILLO', '02121170716','04241170716','2017-07-12','DEP', '0', 
	'Automóvil', 'Chevrolet', 'AVEO','2008','AZUL','AA257WV','Coupé','5','-----', '-------','ACT', 
	'28000.00', '28000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','62');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('503','MARLON RAMON','MARIN TOLEDO', 'MARLONMARIN19@HOTMAIL.COM', 'V-597473','Casado(a)',	'1962-07-27','Masculino' ,'V-597473', 
	'Anzoátegui',	'LECHERIAS', 'AV. R-8, EDIF 1, PISO 2, APTO 1-22, CONJUNTO RESIDENCIAL SIETE MARES.
', '02123815793','04143815793','2017-07-12','DEP', '0', 
	'Camioneta', 'Honda', 'CRV','2006','GRIS','AFT02J','Sport Wagon','5','--------', 'JHLRD78406C210673','ACT', 
	'5932.90', '5932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','63');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('504','CLODOMIRO DEL JESUS','ZACARIAS OCHEA', 'JZACK77@GMAIL.COM', 'V-13379760','Soltero(a)',	'1977-11-26','Masculino' ,'V-133797609', 
	'Distrito Capital',	'CARACAS', 'AV. SAN MARTIN URB LA QUEBRADITA 1 RES. LOS MOLINOS PISO 7 APTO 0701', '02124427461','04143159766','2017-07-13','DEP', '0', 
	'Automóvil', 'Chevrolet', 'OPTRA','2007','ROJO','AGR16T','Sedán','5','--------', 'KL1JM52BX7K694898','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','64');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('505','FERNANDO','SUAREZ GONZALEZ', 'TLOVENDOVZLA@GMAIL.COM', 'V-6974542','Soltero(a)',	'1966-10-14','Masculino' ,'V-6974542', 
	'Distrito Capital',	'CARACAS', 'AVENIDA PRINCIPAL DE MARIPEREZ, RESIDENCIAS MARIPEREZ, PISO 3, APARTAMENTO 31', '02127180753','04128232683','2017-07-13','DEP', '0', 
	'Automóvil', 'Renault', 'SCENIC','2008','VERDE','MFO37T','Sedán','5','------------', '---------------','ACT', 
	'28000.00', '28000.00', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','65');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('506','PEDRO JOSE','LOUIS RODRIGUEZ', 'GRANPEDRO76@GMAIL.COM', 'V-12951584','Soltero(a)',	'1976-09-22','Masculino' ,'V-129515844', 
	'Distrito Capital',	'CARACAS', 'CARACAS, LA CANDELARIA, ESQ. VENUS, EDIF. INA.', '02125731947','04242527921','2017-07-14','TDC', '0', 
	'Automóvil', 'Chevrolet', 'CHEVY C2','2008','PLATA','AG111GM','Sedán','5','---------', '3G1SE51XX8S102857','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','66');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('507','CLAUDIO VICENTE','CAMEROTA ACOSTA', 'CLAUDIOCAMEROTA.93@GMAIL.COM', 'V-6558471','Casado(a)',	'1964-03-23','Masculino' ,'V-65584715', 
	'Miranda',	'CARACAS', 'CARACAS LA BOYERA URB EL CIGARRAL', '02129610554','04241232243','2017-07-14','TDC', '0', 
	'Camioneta', 'Jeep', 'GRAND CHEROKEE','2003','BEIGE','GCC53G','Cross Over','5','--------', '8Y4G248S531502989','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','67');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('508','THAIRIS YANINA','PEREZ MARQUEZ', 'SINAPIS2521@GMAIL.COM', 'V-16557400','Soltero(a)',	'1984-07-25','Femenino' ,'V-165574004', 
	'Distrito Capital',	'CARACAS', 'ESQUINA DE ALTAGRACIA A PUENTE MIRAFLORES, EDIF. AV. PISO 12, APTO 12E, LA PASTORA', '02128606349','04166213101','2017-07-17','DEP', '0', 
	'Camioneta', 'Jeep', 'GRAND CHEROKEE','1999','NEGRA','MBP41U','Sport Wagon','5','--------', '8Y4GW68FFX1904765','ACT', 
	'5932.90', '5932.90', 'S', '', '1', 'MAX 50 KM', 'TRES (03)','0','68');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('509','MARCOS','DE ANDRADE', 'DEANDRADEMARCOS@GMAIL.COM', 'V-18020594','Casado(a)',	'1986-03-24','Masculino' ,'V-18020594', 
	'Delta Amacuro',	'CARACAS', 'SFDFSDFSDF SFDFSDFSDFSDFSDFS', '02128601223','04268141850','2017-07-17','TDC', '0', 
	'Automóvil', 'Ford', 'KA','2006','BLANCO','AC137SK','Coupé','5','lfskjdflsjdfjsdfksjdlk', 'slfsfjlksdjfksdjflksjlfksjdlfjksldjfsd','ACT', 
	'40932.90', '40932.90', 'S', '', '1', 'MAX 50 KM', 'ILIMITADO','0','69');
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('510','MARCOS','DE ANDRADE', 'DEANDRADEMARCOS@GMAIL.COM', 'V-18020594','Divorciado(a)',	'2000-02-02','Masculino' ,'V-18020594', 
	'Distrito Capital',	'CARACAS', 'LDLFSDHFKJHSDKJFHSDKJFH SDFJHSJDFHKSJDHFKSDHFKSDHFS DFHSJDFHSJKDFHKSDFHKSJD', '02128601223','04268141850','2017-07-17','TDC', '0', 
	'Automóvil', 'Chevrolet', 'AVEO','2006','AZUL','AAABBB','Sedán','5','adas8d7a89d79a8s79d8a79s8d798a', 'asda9s87d8sa7d8s78d78s7ds54ds51s245fg45','ACT', 
	'5932.90', '5932.90', 'S', '', '1', '', '','0','70');
#########SolicitudPagoDetalle############
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('1','2700668431','Afiliacion de plan TU/GRUERO WEB 1 ','approved','accredited', 'VEF','2017-04-26T23:27:03.000-04:00','2017-04-26T23:27:06.000-04:00', 
	'visa','credit_card','221065884', 'guest','', 'alexcostantini18@gmail.com','C.I.', 
	'21411814','Alessandro','Costantini','','33', 
	'30.69', '','', '21411814');
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('3','2717725936','Afiliacion de plan TU/GRUERO WEB 3 ','approved','accredited', 'VEF','2017-05-08T09:50:41.000-04:00','2017-05-08T09:50:47.000-04:00', 
	'master','credit_card','221065884', 'guest','', 'enjo1274@gmail.com','CI-V', 
	'12352502','','enjo1274','','33000', 
	'30693.3', '','', '12352502');
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('4','2725416843','Afiliacion de plan TU/GRUERO WEB 4 ','approved','accredited', 'VEF','2017-05-11T11:08:24.000-04:00','2017-05-11T11:08:28.000-04:00', 
	'visa','credit_card','221065884', 'guest','', 'morelbamontilla11@gmail.com','CI-V', 
	'5978510','','','','38932.9', 
	'36211.49', '','', '5978510');
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('5','2725746703','Afiliacion de plan TU/GRUERO WEB 5 ','approved','accredited', 'VEF','2017-05-11T14:23:38.000-04:00','2017-05-11T14:23:41.000-04:00', 
	'visa','credit_card','221065884', 'guest','', 'rafael1978@gmail.com','C.I.', 
	'13458880','Rafael','Rodriguez','','38932.9', 
	'36211.49', '','', '13458880');
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('8','2735325168','Afiliacion de plan TU/GRUERO WEB 8 ','approved','accredited', 'VEF','2017-05-16T10:53:10.000-04:00','2017-05-16T10:53:13.000-04:00', 
	'visa','credit_card','221065884', 'guest','', 'rjmunozr@hotmail.com','C.I.', 
	'5412276','Roberto','Mu\u00F1oz','','35000', 
	'32553.5', '','', '5412276');
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('11','2739269522','Afiliacion de plan TU/GRUERO WEB 11 ','approved','accredited', 'VEF','2017-05-17T22:50:25.000-04:00','2017-05-17T22:50:28.000-04:00', 
	'master','credit_card','221065884', 'guest','', 'ptobong@gmail.com','C.I.', 
	'5425784','Pablo','Tobon','','35000', 
	'32553.5', '','', '5425784');
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('12','2751365752','Afiliacion de plan TU/GRUERO WEB 12 ','approved','accredited', 'VEF','2017-05-24T11:24:57.000-04:00','2017-05-24T11:25:03.000-04:00', 
	'visa','credit_card','221065884', 'guest','', 'meuryspernia@gmail.com','C.I.', 
	'19598345','Meurys','Pernia','','35000', 
	'32553.5', '','', '17875958');
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('13','2753262502','Afiliacion de plan TU/GRUERO WEB 13 ','in_process','pending_review_manual', 'VEF','2017-05-25T14:21:54.000-04:00','', 
	'visa','credit_card','221065884', 'guest','', 'zobealva@gmail.com','CI-V', 
	'16411622','','','','40932.9', 
	'0', '','', '16411622');
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('17','2775618238','Afiliacion de plan TU/GRUERO WEB 17 ','approved','accredited', 'VEF','2017-06-06T08:31:36.000-04:00','2017-06-06T08:31:39.000-04:00', 
	'visa','credit_card','221065884', 'guest','', 'ambarfagun89@gmail.com','CI-V', 
	'21134647','','ambarfagun89','','40932.9', 
	'38071.69', '','', '21134647');
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('18','2778058101','Afiliacion de plan TU/GRUERO WEB 18 ','approved','accredited', 'VEF','2017-06-07T06:32:24.000-04:00','2017-06-07T06:32:27.000-04:00', 
	'visa','credit_card','221065884', 'guest','', 'ivanmojica41@gmail.com','R.I.F.', 
	'317318820','ASOCIACION COOPOERATIVA EMIS','R.L','','40932.9', 
	'38071.69', '','', '14527009');
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('19','2781367670','Afiliacion de plan TU/GRUERO WEB 19 ','in_process','pending_review_manual', 'VEF','2017-06-08T10:17:04.000-04:00','', 
	'visa','credit_card','221065884', 'guest','', 'carl.fag85@gmail.com','C.I.', 
	'17426036','Carlos','Fagundez','','40932.9', 
	'0', '','', '21134647');
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('27','2788454816','Afiliacion de plan TU/GRUERO WEB 27 ','approved','accredited', 'VEF','2017-06-12T11:19:59.000-04:00','2017-06-12T11:20:03.000-04:00', 
	'visa','credit_card','221065884', 'guest','', 'MIBARRA@IMCP.GOB.VE','CI-V', 
	'9483321','','mibarra','','40932.9', 
	'38071.69', '','', '9483321');
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('68','','Pago de plan mediante la herramienta administrativa','approved','', '','','2017-07-17 12:41:19', 
	'visa','credit_card','', '','guest', 'SINAPIS2521@GMAIL.COM','', 
	'','','','','40932.9', 
	'', '','', '');
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('31','2792943652','Afiliacion de plan TU/GRUERO WEB 31 ','approved','accredited', 'VEF','2017-06-14T10:41:18.000-04:00','2017-06-14T10:41:20.000-04:00', 
	'visa','credit_card','221065884', 'guest','', 'macdct@gmail.com','CI-V', 
	'6892198','','','','35000', 
	'32553.5', '','', '6892198');
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('33','2794845633','Afiliacion de plan TU/GRUERO WEB 33 ','approved','accredited', 'VEF','2017-06-15T09:25:04.000-04:00','2017-06-15T09:25:08.000-04:00', 
	'master','credit_card','221065884', 'guest','', 'gsptennis@yahoo.com','C.I.', 
	'15072255','Gustavo','Salazar','','35000', 
	'32553.5', '','', '15072255');
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('37','2805949484','Afiliacion de plan TU/GRUERO WEB 37 ','approved','accredited', 'VEF','2017-06-21T11:00:07.000-04:00','2017-06-21T11:00:09.000-04:00', 
	'master','credit_card','221065884', 'guest','', 'OJSS2612@GMAIL.COM','R.I.F.', 
	'156069546','Omar Jesus','Sanchez Sanchez','','40932.9', 
	'38071.69', '','', '15606954');
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('44','2821971534','Afiliacion de plan TU/GRUERO WEB 44 ','approved','accredited', 'VEF','2017-06-29T12:29:40.000-04:00','2017-06-29T12:29:43.000-04:00', 
	'master','credit_card','221065884', 'guest','', 'ivillamizar@gmail.com','C.I.', 
	'16462437','Ivan','Villamizar','','40932.9', 
	'38071.69', '','', '16462437');
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('46','2823255736','Afiliacion de plan TU/GRUERO WEB 46 ','approved','accredited', 'VEF','2017-06-29T20:48:36.000-04:00','2017-06-29T20:48:38.000-04:00', 
	'visa','credit_card','221065884', 'guest','', 'danielspa73@gmail.com','C.I.', 
	'14438135','Daniel','Spadafora','','40932.9', 
	'38071.69', '','', '17438135');
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('48','2823121004','Afiliacion de plan TU/GRUERO WEB 48 ','approved','accredited', 'VEF','2017-06-29T21:36:17.000-04:00','2017-06-29T21:36:20.000-04:00', 
	'visa','credit_card','221065884', 'guest','', 'DAVIDALFONZO940@HOTMAIL.COM','R.I.F.', 
	'19469126','david','alfonzo','','40932.9', 
	'38071.69', '','', '4938938');
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('50','5522925780564825','Pago de plan mediante la herramienta administrativa','approved','', '','','2017-06-30 02:41:07', 
	'mastercard','credit_card','', '','guest', 'bricenogerman@gmail.com','', 
	'V-2072757','','','','40932.9', 
	'', '','', '');
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('53','2828795650','Afiliacion de plan TU/GRUERO WEB 53 ','approved','accredited', 'VEF','2017-07-03T10:34:40.000-04:00','2017-07-03T10:34:43.000-04:00', 
	'master','credit_card','221065884', 'guest','', 'amartinezprego@gmail.com','C.I.', 
	'9967497','antonio','martinez','','40932.9', 
	'38071.69', '','', '9967497');
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('55','2830309666','Afiliacion de plan TU/GRUERO WEB 55 ','approved','accredited', 'VEF','2017-07-03T20:50:29.000-04:00','2017-07-03T20:50:32.000-04:00', 
	'visa','credit_card','221065884', 'guest','', 'miguel.tortello@gmail.com','CI-V', 
	'8318405','','','','35000', 
	'32553.5', '','', '8318405');
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('58','2835907691','Afiliacion de plan TU/GRUERO WEB 58 ','approved','accredited', 'VEF','2017-07-06T10:57:29.000-04:00','2017-07-06T10:57:31.000-04:00', 
	'master','credit_card','221065884', 'guest','', 'inesitanatural@gmail.com','CI-V', 
	'22689696','','','','40932.9', 
	'38071.69', '','', '22689696');
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('59','2844083020','Afiliacion de plan TU/GRUERO WEB 59 ','approved','accredited', 'VEF','2017-07-10T14:56:31.000-04:00','2017-07-10T14:56:37.000-04:00', 
	'visa','credit_card','221065884', 'guest','', 'edgar.gonzi@gmail.com','C.I.', 
	'975541','Edgar','Gonz\u00E1lez','','40932.9', 
	'38071.69', '','', '4975541');
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('66','2853473583','Afiliacion de plan TU/GRUERO WEB 66 ','approved','accredited', 'VEF','2017-07-14T10:38:33.000-04:00','2017-07-14T10:38:37.000-04:00', 
	'visa','credit_card','221065884', 'guest','', 'granpedro76@gmail.com','C.I.', 
	'12951584','Pedro','Louis','','40932.9', 
	'38071.69', '','', '12951584');
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('67','2854521067','Afiliacion de plan TU/GRUERO WEB 67 ','approved','accredited', 'VEF','2017-07-14T19:49:24.000-04:00','2017-07-14T19:49:27.000-04:00', 
	'visa','credit_card','221065884', 'guest','', 'claudiocamerota.93@gmail.com','C.I.', 
	'21015312','Claudio','camerota','','40932.9', 
	'38071.69', '','', '8533580');
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('69','555555','Pago de plan mediante la herramienta administrativa','approved','', '','','2017-07-17 12:37:08', 
	'visa','credit_card','', '','guest', 'deandrademarcos@gmail.com','', 
	'v-18020594','','','','40932.9', 
	'', '','', '');
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('70','8787878','Pago de plan mediante la herramienta administrativa','approved','', '','','2017-07-17 12:40:53', 
	'visa','credit_card','', '','guest', 'deandrademarcos@gmail.com','', 
	'v-18020594','','','','5932.9', 
	'', '','', '');
#########SolicitudPlanSeleccion############
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('1','1', '33.00','30.00', '2017-04-27');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('1','4', '6000.00','6600.00', '2017-04-27');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('2','1', '33000.00','30000.00', '2017-05-03');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('3','1', '33000.00','30000.00', '2017-05-08');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('4','1', '33000.00','30000.00', '2017-05-11');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('4','3', '5932.90','5932.90', '2017-05-11');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('5','1', '33000.00','30000.00', '2017-05-11');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('5','3', '5932.90','5932.90', '2017-05-11');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('6','1', '33000.00','30000.00', '2017-05-13');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('6','3', '5932.90','5932.90', '2017-05-13');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('7','1', '33000.00','30000.00', '2017-05-15');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('7','3', '5932.90','5932.90', '2017-05-15');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('8','1', '35000.00','35000.00', '2017-05-16');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('11','1', '35000.00','35000.00', '2017-05-18');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('12','1', '35000.00','35000.00', '2017-05-24');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('13','1', '35000.00','35000.00', '2017-05-25');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('13','3', '5932.90','5932.90', '2017-05-25');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('14','1', '35000.00','35000.00', '2017-05-25');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('15','1', '35000.00','35000.00', '2017-05-27');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('15','3', '5932.90','5932.90', '2017-05-27');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('16','2', '120000.00','120000.00', '2017-05-30');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('16','3', '5932.90','5932.90', '2017-05-30');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('17','1', '35000.00','35000.00', '2017-06-06');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('17','3', '5932.90','5932.90', '2017-06-06');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('18','1', '35000.00','35000.00', '2017-06-07');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('18','3', '5932.90','5932.90', '2017-06-07');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('19','1', '35000.00','35000.00', '2017-06-08');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('19','3', '5932.90','5932.90', '2017-06-08');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('26','1', '35000.00','35000.00', '2017-06-11');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('27','1', '35000.00','35000.00', '2017-06-12');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('27','3', '5932.90','5932.90', '2017-06-12');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('28','1', '28000.00','28000.00', '2017-06-13');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('29','2', '120000.00','120000.00', '2017-06-13');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('29','3', '5932.90','5932.90', '2017-06-13');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('30','1', '35000.00','35000.00', '2017-06-14');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('31','1', '35000.00','35000.00', '2017-06-14');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('32','3', '5932.90','5932.90', '2017-06-14');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('33','1', '35000.00','35000.00', '2017-06-15');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('34','1', '35000.00','35000.00', '2017-06-15');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('34','3', '5932.90','5932.90', '2017-06-15');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('35','1', '35000.00','35000.00', '2017-06-20');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('36','1', '35000.00','35000.00', '2017-06-20');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('36','3', '5932.90','5932.90', '2017-06-20');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('37','1', '35000.00','35000.00', '2017-06-21');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('37','3', '5932.90','5932.90', '2017-06-21');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('38','1', '28000.00','28000.00', '2017-06-22');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('39','1', '28000.00','28000.00', '2017-06-22');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('40','1', '28000.00','28000.00', '2017-06-22');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('41','1', '28000.00','28000.00', '2017-06-22');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('42','1', '35000.00','35000.00', '2017-06-26');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('42','3', '5932.90','5932.90', '2017-06-26');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('43','1', '35000.00','35000.00', '2017-06-26');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('43','3', '5932.90','5932.90', '2017-06-26');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('44','1', '35000.00','35000.00', '2017-06-29');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('44','3', '5932.90','5932.90', '2017-06-29');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('45','1', '35000.00','35000.00', '2017-06-29');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('45','3', '5932.90','5932.90', '2017-06-29');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('46','1', '35000.00','35000.00', '2017-06-30');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('46','3', '5932.90','5932.90', '2017-06-30');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('47','1', '35000.00','35000.00', '2017-06-30');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('47','3', '5932.90','5932.90', '2017-06-30');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('48','1', '35000.00','35000.00', '2017-06-30');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('48','3', '5932.90','5932.90', '2017-06-30');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('49','1', '35000.00','35000.00', '2017-06-30');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('49','3', '5932.90','5932.90', '2017-06-30');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('50','1', '35000.00','35000.00', '2017-06-30');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('50','3', '5932.90','5932.90', '2017-06-30');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('51','1', '35000.00','35000.00', '2017-06-30');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('52','1', '35000.00','35000.00', '2017-06-30');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('53','1', '35000.00','35000.00', '2017-07-03');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('53','3', '5932.90','5932.90', '2017-07-03');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('54','1', '35000.00','35000.00', '2017-07-03');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('54','3', '5932.90','5932.90', '2017-07-03');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('55','1', '35000.00','35000.00', '2017-07-04');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('56','1', '28000.00','28000.00', '2017-07-05');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('57','1', '35000.00','35000.00', '2017-07-06');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('57','3', '5932.90','5932.90', '2017-07-06');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('58','1', '35000.00','35000.00', '2017-07-06');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('58','3', '5932.90','5932.90', '2017-07-06');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('59','1', '35000.00','35000.00', '2017-07-10');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('59','3', '5932.90','5932.90', '2017-07-10');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('60','1', '28000.00','28000.00', '2017-07-11');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('61','1', '28000.00','28000.00', '2017-07-11');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('62','1', '28000.00','28000.00', '2017-07-12');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('63','1', '35000.00','35000.00', '2017-07-12');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('63','3', '5932.90','5932.90', '2017-07-12');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('64','1', '35000.00','35000.00', '2017-07-13');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('64','3', '5932.90','5932.90', '2017-07-13');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('65','1', '28000.00','28000.00', '2017-07-13');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('66','1', '35000.00','35000.00', '2017-07-14');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('66','3', '5932.90','5932.90', '2017-07-14');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('67','1', '35000.00','35000.00', '2017-07-14');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('67','3', '5932.90','5932.90', '2017-07-14');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('68','1', '35000.00','35000.00', '2017-07-17');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('68','3', '5932.90','5932.90', '2017-07-17');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('69','1', '35000.00','35000.00', '2017-07-17');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('69','3', '5932.90','5932.90', '2017-07-17');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('70','3', '5932.90','5932.90', '2017-07-17');
#########SolicitudDocumentos############
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('1','CarnetCirculacion','CarnetCirculacion_1.png','2017-04-27 03:25:38','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('1','Cedula','Cedula_1.png','2017-04-27 03:25:38','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('1','Licencia','Licencia_1.png','2017-04-27 03:25:38','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('1','Rif','Rif_1.png','2017-04-27 03:25:38','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('2','CarnetCirculacion','CarnetCirculacion_2.jpg','2017-05-03 01:37:19','ENV');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('2','Cedula','Cedula_2.jpg','2017-05-03 01:37:19','ENV');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('2','Licencia','Licencia_2.jpg','2017-05-03 01:37:19','ENV');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('2','Rif','Rif_2.jpg','2017-05-03 01:37:19','ENV');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('3','CarnetCirculacion','CarnetCirculacion_3.pdf','2017-05-08 01:48:25','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('3','Cedula','Cedula_3.pdf','2017-05-08 01:48:25','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('3','Licencia','Licencia_3.pdf','2017-05-08 01:48:25','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('3','Rif','Rif_3.pdf','2017-05-08 01:48:25','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('4','CarnetCirculacion','CarnetCirculacion_4.pdf','2017-05-11 03:06:10','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('4','Cedula','Cedula_4.pdf','2017-05-11 03:06:10','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('4','CertificadoMedico','CertificadoMedico_4.pdf','2017-05-11 03:06:10','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('4','CertificadoOrigen','CertificadoOrigen_4.pdf','2017-05-11 03:06:10','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('4','Licencia','Licencia_4.pdf','2017-05-11 03:06:10','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('4','Rif','Rif_4.pdf','2017-05-11 03:06:10','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('5','CarnetCirculacion','CarnetCirculacion_5.pdf','2017-05-11 06:21:00','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('5','Cedula','Cedula_5.pdf','2017-05-11 06:21:00','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('5','CertificadoMedico','CertificadoMedico_5.pdf','2017-05-11 06:21:00','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('5','CertificadoOrigen','CertificadoOrigen_5.pdf','2017-05-11 06:21:00','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('5','Licencia','Licencia_5.pdf','2017-05-11 06:21:00','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('5','Rif','Rif_5.pdf','2017-05-11 06:21:00','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('6','CarnetCirculacion','CarnetCirculacion_6.JPG','2017-05-13 02:45:16','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('6','Cedula','Cedula_6.jpeg','2017-05-13 02:45:16','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('6','CertificadoMedico','CertificadoMedico_6.jpeg','2017-05-13 02:45:16','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('6','CertificadoOrigen','CertificadoOrigen_6.JPG','2017-05-13 02:45:16','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('6','DEP1','DEP1_6.png','2017-05-13 02:45:16','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('6','Licencia','Licencia_6.jpeg','2017-05-13 02:45:16','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('6','Rif','Rif_6.png','2017-05-13 02:45:16','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('7','CarnetCirculacion','CarnetCirculacion_7.jpg','2017-05-15 10:01:43','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('7','Cedula','Cedula_7.jpg','2017-05-15 10:01:43','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('7','CertificadoMedico','CertificadoMedico_7.jpg','2017-05-15 10:01:43','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('7','CertificadoOrigen','CertificadoOrigen_7.jpg','2017-05-15 10:01:43','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('7','DEP1','DEP1_7.jpg','2017-05-15 10:01:43','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('7','Licencia','Licencia_7.jpg','2017-05-15 10:01:43','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('7','Rif','Rif_7.pdf','2017-05-15 10:01:43','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('8','CarnetCirculacion','CarnetCirculacion_8.pdf','2017-05-16 02:50:34','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('8','Cedula','Cedula_8.pdf','2017-05-16 02:50:34','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('8','Licencia','Licencia_8.pdf','2017-05-16 02:50:34','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('8','Rif','Rif_8.pdf','2017-05-16 02:50:34','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('11','CarnetCirculacion','CarnetCirculacion_11.JPG','2017-05-18 02:48:41','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('11','Cedula','Cedula_11.JPG','2017-05-18 02:48:41','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('12','CarnetCirculacion','CarnetCirculacion_12.jpg','2017-05-24 03:23:34','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('12','Cedula','Cedula_12.jpg','2017-05-24 03:23:34','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('13','CarnetCirculacion','CarnetCirculacion_13.pdf','2017-05-25 06:19:04','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('13','Cedula','Cedula_13.pdf','2017-05-25 06:19:04','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('14','CarnetCirculacion','CarnetCirculacion_14.jpg','2017-05-25 10:47:46','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('14','Cedula','Cedula_14.jpg','2017-05-25 10:47:46','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('14','DEP1','DEP1_14.jpg','2017-05-25 10:47:46','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('15','CarnetCirculacion','CarnetCirculacion_15.jpg','2017-05-27 12:25:57','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('15','Cedula','Cedula_15.jpg','2017-05-27 12:25:57','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('15','DEP1','DEP1_15.jpg','2017-05-27 12:25:57','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('15','DEP2','DEP2_15.jpg','2017-05-27 12:25:57','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('16','CarnetCirculacion','CarnetCirculacion_16.jpg','2017-05-30 07:27:43','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('16','Cedula','Cedula_16.jpg','2017-05-30 07:27:43','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('16','DEP1','DEP1_16.jpg','2017-05-30 07:27:43','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('16','DEP2','DEP2_16.jpg','2017-05-30 07:27:43','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('17','CarnetCirculacion','CarnetCirculacion_17.pdf','2017-06-06 12:30:05','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('17','Cedula','Cedula_17.pdf','2017-06-06 12:30:05','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('18','CarnetCirculacion','CarnetCirculacion_18.jpg','2017-06-07 10:28:09','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('18','Cedula','Cedula_18.jpg','2017-06-07 10:28:09','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('19','CarnetCirculacion','CarnetCirculacion_19.pdf','2017-06-08 02:15:55','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('19','Cedula','Cedula_19.pdf','2017-06-08 02:15:55','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('26','CarnetCirculacion','CarnetCirculacion_26.jpg','2017-06-11 03:39:17','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('26','Cedula','Cedula_26.jpg','2017-06-11 03:39:17','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('26','DEP1','DEP1_26.jpg','2017-06-11 03:39:17','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('27','CarnetCirculacion','CarnetCirculacion_27.jpg','2017-06-12 03:17:36','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('27','Cedula','Cedula_27.jpg','2017-06-12 03:17:36','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('28','CarnetCirculacion','CarnetCirculacion_28.pdf','2017-06-13 08:38:37','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('28','Cedula','Cedula_28.pdf','2017-06-13 08:38:37','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('28','DEP1','DEP1_28.pdf','2017-06-13 08:38:37','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('29','CarnetCirculacion','CarnetCirculacion_29.JPG','2017-06-13 09:47:51','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('29','Cedula','Cedula_29.JPG','2017-06-13 09:47:51','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('29','DEP1','DEP1_29.JPG','2017-06-13 09:47:51','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('30','CarnetCirculacion','CarnetCirculacion_30.pdf','2017-06-14 01:48:14','ENV');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('30','Cedula','Cedula_30.pdf','2017-06-14 01:48:14','ENV');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('30','DEP1','DEP1_30.pdf','2017-06-14 01:48:14','ENV');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('31','CarnetCirculacion','CarnetCirculacion_31.jpg','2017-06-14 02:38:55','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('31','Cedula','Cedula_31.jpg','2017-06-14 02:38:55','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('32','CarnetCirculacion','CarnetCirculacion_32.jpg','2017-06-14 08:10:13','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('32','Cedula','Cedula_32.jpg','2017-06-14 08:10:13','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('32','DEP1','DEP1_32.png','2017-06-14 08:10:13','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('33','CarnetCirculacion','CarnetCirculacion_33.jpg','2017-06-15 01:22:46','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('33','Cedula','Cedula_33.jpg','2017-06-15 01:22:46','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('34','CarnetCirculacion','CarnetCirculacion_34.pdf','2017-06-15 02:56:47','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('34','Cedula','Cedula_34.pdf','2017-06-15 02:56:47','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('34','DEP1','DEP1_34.pdf','2017-06-15 02:56:47','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('35','CarnetCirculacion','CarnetCirculacion_35.JPG','2017-06-20 06:48:07','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('35','Cedula','Cedula_35.JPG','2017-06-20 06:48:07','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('35','DEP1','DEP1_35.pdf','2017-06-20 06:48:07','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('36','CarnetCirculacion','CarnetCirculacion_36.jpeg','2017-06-20 09:07:49','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('36','Cedula','Cedula_36.jpeg','2017-06-20 09:07:49','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('36','DEP1','DEP1_36.pdf','2017-06-20 09:07:49','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('37','CarnetCirculacion','CarnetCirculacion_37.jpg','2017-06-21 02:58:19','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('37','Cedula','Cedula_37.jpg','2017-06-21 02:58:19','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('38','CarnetCirculacion','CarnetCirculacion_38.pdf','2017-06-22 01:15:00','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('38','Cedula','Cedula_38.pdf','2017-06-22 01:15:00','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('38','DEP1','DEP1_38.pdf','2017-06-22 01:15:00','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('39','CarnetCirculacion','CarnetCirculacion_39.pdf','2017-06-22 01:39:53','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('39','Cedula','Cedula_39.pdf','2017-06-22 01:39:53','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('39','DEP1','DEP1_39.pdf','2017-06-22 01:39:53','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('40','CarnetCirculacion','CarnetCirculacion_40.pdf','2017-06-22 02:14:53','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('40','Cedula','Cedula_40.pdf','2017-06-22 02:14:53','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('40','DEP1','DEP1_40.pdf','2017-06-22 02:14:53','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('41','CarnetCirculacion','CarnetCirculacion_41.pdf','2017-06-22 10:04:44','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('41','Cedula','Cedula_41.pdf','2017-06-22 10:04:44','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('41','DEP1','DEP1_41.pdf','2017-06-22 10:04:44','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('42','CarnetCirculacion','CarnetCirculacion_42.pdf','2017-06-26 12:52:53','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('42','Cedula','Cedula_42.pdf','2017-06-26 12:52:53','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('42','DEP1','DEP1_42.pdf','2017-06-26 12:52:53','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('42','DEP2','DEP2_42.pdf','2017-06-26 12:52:53','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('43','CarnetCirculacion','CarnetCirculacion_43.jpg','2017-06-26 07:43:01','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('43','Cedula','Cedula_43.jpg','2017-06-26 07:43:01','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('43','DEP1','DEP1_43.jpg','2017-06-26 07:43:01','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('44','CarnetCirculacion','CarnetCirculacion_44.jpg','2017-06-29 04:28:21','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('44','Cedula','Cedula_44.jpg','2017-06-29 04:28:21','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('45','CarnetCirculacion','CarnetCirculacion_45.pdf','2017-06-29 09:43:58','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('45','Cedula','Cedula_45.pdf','2017-06-29 09:43:58','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('45','DEP1','DEP1_45.pdf','2017-06-29 09:43:58','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('45','DEP2','DEP2_45.pdf','2017-06-29 09:43:58','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('46','CarnetCirculacion','CarnetCirculacion_46.pdf','2017-06-30 12:46:14','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('46','Cedula','Cedula_46.pdf','2017-06-30 12:46:14','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('47','CarnetCirculacion','CarnetCirculacion_47.jpg','2017-06-30 12:50:26','ENV');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('47','Cedula','Cedula_47.jpg','2017-06-30 12:50:26','ENV');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('48','CarnetCirculacion','CarnetCirculacion_48.jpg','2017-06-30 01:34:35','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('48','Cedula','Cedula_48.jpg','2017-06-30 01:34:35','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('49','CarnetCirculacion','CarnetCirculacion_49.jpg','2017-06-30 02:39:42','ENV');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('49','Cedula','Cedula_49.jpg','2017-06-30 02:39:42','ENV');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('50','CarnetCirculacion','CarnetCirculacion_50.jpg','2017-06-30 02:41:07','ENV');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('50','Cedula','Cedula_50.jpg','2017-06-30 02:41:07','ENV');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('51','CarnetCirculacion','CarnetCirculacion_51.jpg','2017-06-30 07:13:45','ENV');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('51','Cedula','Cedula_51.pdf','2017-06-30 07:13:45','ENV');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('52','CarnetCirculacion','CarnetCirculacion_52.jpg','2017-06-30 08:05:50','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('52','Cedula','Cedula_52.pdf','2017-06-30 08:05:50','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('52','DEP1','DEP1_52.png','2017-06-30 08:05:50','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('53','CarnetCirculacion','CarnetCirculacion_53.jpg','2017-07-03 02:33:19','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('53','Cedula','Cedula_53.pdf','2017-07-03 02:33:19','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('54','CarnetCirculacion','CarnetCirculacion_54.jpg','2017-07-03 10:30:32','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('54','Cedula','Cedula_54.jpg','2017-07-03 10:30:32','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('54','DEP1','DEP1_54.pdf','2017-07-03 10:30:32','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('55','CarnetCirculacion','CarnetCirculacion_55.pdf','2017-07-04 12:48:03','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('55','Cedula','Cedula_55.jpg','2017-07-04 12:48:03','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('56','CarnetCirculacion','CarnetCirculacion_56.pdf','2017-07-05 01:53:32','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('56','Cedula','Cedula_56.pdf','2017-07-05 01:53:32','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('56','DEP1','DEP1_56.png','2017-07-05 01:53:32','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('57','CarnetCirculacion','CarnetCirculacion_57.pdf','2017-07-06 02:29:37','ENV');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('57','Cedula','Cedula_57.pdf','2017-07-06 02:29:37','ENV');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('58','CarnetCirculacion','CarnetCirculacion_58.pdf','2017-07-06 02:55:17','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('58','Cedula','Cedula_58.pdf','2017-07-06 02:55:17','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('59','CarnetCirculacion','CarnetCirculacion_59.pdf','2017-07-10 06:54:02','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('59','Cedula','Cedula_59.pdf','2017-07-10 06:54:02','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('60','CarnetCirculacion','CarnetCirculacion_60.jpg','2017-07-11 02:01:02','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('60','Cedula','Cedula_60.jpg','2017-07-11 02:01:02','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('60','DEP1','DEP1_60.png','2017-07-11 02:01:02','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('61','CarnetCirculacion','CarnetCirculacion_61.pdf','2017-07-11 03:13:22','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('61','Cedula','Cedula_61.pdf','2017-07-11 03:13:22','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('61','DEP1','DEP1_61.PNG','2017-07-11 03:13:22','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('62','CarnetCirculacion','CarnetCirculacion_62.jpg','2017-07-12 02:46:31','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('62','Cedula','Cedula_62.jpg','2017-07-12 02:46:31','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('62','DEP1','DEP1_62.png','2017-07-12 02:46:31','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('63','CarnetCirculacion','CarnetCirculacion_63.jpeg','2017-07-12 07:45:59','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('63','Cedula','Cedula_63.jpeg','2017-07-12 07:45:59','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('63','DEP1','DEP1_63.jpeg','2017-07-12 07:45:59','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('64','CarnetCirculacion','CarnetCirculacion_64.jpg','2017-07-13 09:55:35','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('64','Cedula','Cedula_64.jpg','2017-07-13 09:55:35','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('64','DEP1','DEP1_64.jpg','2017-07-13 09:55:35','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('65','CarnetCirculacion','CarnetCirculacion_65.png','2017-07-13 10:05:58','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('65','Cedula','Cedula_65.png','2017-07-13 10:05:58','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('65','DEP1','DEP1_65.png','2017-07-13 10:05:58','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('66','CarnetCirculacion','CarnetCirculacion_66.pdf','2017-07-14 02:35:04','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('66','Cedula','Cedula_66.pdf','2017-07-14 02:35:04','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('67','CarnetCirculacion','CarnetCirculacion_67.pdf','2017-07-14 11:47:29','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('67','Cedula','Cedula_67.pdf','2017-07-14 11:47:29','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('68','CarnetCirculacion','CarnetCirculacion_68.pdf','2017-07-17 12:41:19','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('68','Cedula','Cedula_68.pdf','2017-07-17 12:41:19','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('68','DEP1','DEP1_68.pdf','2017-07-17 12:41:19','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('69','CarnetCirculacion','CarnetCirculacion_69.pdf','2017-07-17 12:37:08','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('69','Cedula','Cedula_69.pdf','2017-07-17 12:37:08','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('70','CarnetCirculacion','CarnetCirculacion_70.pdf','2017-07-17 12:40:53','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('70','Cedula','Cedula_70.pdf','2017-07-17 12:40:53','ACT');
#########SolicitudAprobada############
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('1','TGP-PAG-0001','','','02-50047','02-50047-1','');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('3','TGP-PAG-0002','2017-05-16','2018-05-16','','','2017-05-08');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('4','TGP-PAG-0003','2017-05-19','2018-05-19','02-50049','02-50049-1','2017-05-11');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('5','TGP-PAG-0004','2017-05-19','2018-05-19','02-50050','02-50050-1','2017-05-13');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('6','TGP-PAG-0005','2017-05-19','2018-05-19','02-50051','02-50051-1','2017-05-15');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('7','TGP-PAG-0007','2017-05-23','2018-05-23','02-50052','02-50052-1','2017-05-18');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('8','TGP-PAG-0006','2017-05-24','2018-05-24','','','2017-05-16');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('11','TGP-PAG-0008','2017-05-25','2018-05-25','','','2017-05-18');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('12','TGP-PAG-0009','2017-06-01','2018-06-01','','','2017-05-25');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('13','TGP-PAG-0010','2017-06-05','2018-06-05','02-50054','02-50054-1','2017-05-27');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('14','TGP-PAG-0012','2017-06-02','2018-06-02','','','2017-05-27');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('15','TGP-PAG-0011','2017-05-29','2018-05-29','02-50055','02-50055-1','2017-05-27');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('16','TGG-PAG-0001','2017-06-07','2018-06-07','02-50056','02-50056-1','2017-05-31');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('17','TGP-PAG-0014','2017-06-14','2018-06-14','02-50058','02-50058-1','2017-06-07');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('18','TGP-PAG-0013','2017-06-15','2018-06-15','02-50057','02-50057-1','2017-06-07');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('19','TGP-PAG-0015','2017-06-16','2018-06-16','02-50059','02-50059-1','2017-06-08');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('26','TGP-PAG-0016','2017-06-19','2018-06-19','','','2017-06-13');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('27','TGP-PAG-0017','2017-06-20','2018-06-20','02-50060','02-50060-1','2017-06-13');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('28','TGP-PAG-0018','2017-06-21','2018-06-21','','','2017-06-14');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('29','TGG-PAG-0002','2017-06-21','2018-06-21','02-50061','02-50061-1','2017-06-14');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('31','TGP-PAG-0019','2017-06-22','2018-06-22','','','2017-06-14');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('32','','2017-06-13','2018-06-13','02-50062','02-50062-1','2017-06-14');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('33','TGP-PAG-0021','2017-06-23','2018-06-23','','','2017-06-15');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('34','TGP-PAG-0020','2017-06-23','2018-06-23','02-50063','02-50063-1','2017-06-15');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('35','TGP-PAG-0023','2017-06-26','2018-06-26','','','2017-06-21');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('36','TGP-PAG-0022','2017-06-23','2018-06-23','02-50064','02-50064-1','2017-06-20');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('37','TGP-PAG-0024','2017-06-27','2018-06-27','02-50065','02-50065-1','2017-06-21');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('38','TGP-PAG-0025','2017-06-27','2018-06-27','','','2017-06-22');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('39','TGP-PAG-0026','2017-06-28','2018-06-28','','','2017-06-22');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('40','TGP-PAG-0028','2017-06-27','2018-06-27','','','2017-06-26');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('41','TGP-PAG-0027','2017-06-28','2018-06-28','','','2017-06-22');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('42','TGP-PAG-0030','2017-06-30','2018-06-30','02-50067','02-50067-1','2017-06-26');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('43','TGP-PAG-0029','2017-06-29','2018-06-29','02-50066','02-50066-1','2017-06-26');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('44','TGP-PAG-0032','2017-07-12','2018-07-12','02-50069','02-50069-1','2017-06-29');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('45','TGP-PAG-0031','2017-07-25','2018-07-25','02-50068','02-50068-1','2017-06-29');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('46','TGP-PAG-0033','2017-07-05','2018-07-05','02-50070','02-50070-1','2017-07-04');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('48','TGP-PAG-0034','2017-07-05','2018-07-05','02-50071','02-50071-1','2017-07-04');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('52','TGP-PAG-0035','2017-07-06','2018-07-06','','','2017-07-04');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('53','TGP-PAG-0036','2017-07-14','2018-07-14','02-50072','02-50072-1','2017-07-04');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('54','TGP-PAG-0037','2017-07-14','2018-07-14','02-50073','02-50073-1','2017-07-04');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('55','TGP-PAG-0038','2017-07-17','2018-07-17','','','2017-07-04');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('56','TGP-PAG-0039','2017-07-12','2018-07-12','','','2017-07-05');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('58','TGP-PAG-0040','2017-07-19','2018-07-19','02-50074','02-50074-1','2017-07-06');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('59','TGP-PAG-0042','2017-07-21','2018-07-21','02-50075','02-50075-1','2017-07-12');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('60','TGP-PAG-0041','2017-07-14','2018-07-14','','','2017-07-11');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('61','TGP-PAG-0044','2017-07-14','2018-07-14','','','2017-07-12');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('62','TGP-PAG-0043','2017-07-24','2018-07-24','','','2017-07-12');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('63','TGP-PAG-0045','2017-07-25','2018-07-25','02-50076','02-50076-1','2017-07-12');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('64','TGP-PAG-0047','2017-07-26','2018-07-26','02-50077','02-50077-1','2017-07-14');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('65','TGP-PAG-0046','2017-07-26','2018-07-26','','','2017-07-13');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('66','TGP-PAG-0048','2017-07-27','2018-07-27','02-50078','02-50078-1','2017-07-14');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('67','TGP-PAG-0050','2017-07-27','2018-07-27','02-50080','02-50080-1','2017-07-17');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('68','TGP-PAG-0049','2017-08-11','2018-08-11','02-50079','02-50079-1','2017-07-17');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('69','TGP-PAG-0051','2017-07-17','2017-07-17','02-50081','02-50081-1','2017-07-17');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('70','','2017-07-17','2017-07-17','02-50082','02-50082-1','2017-07-17');
