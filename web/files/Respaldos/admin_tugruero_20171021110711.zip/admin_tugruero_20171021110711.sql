#########Polizas############
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('HGHGJHG','V-18020594','MARCOS','DE ANDRADE','Acura','AAAA','Automóvil','N/A','JHJHJHJ','1980','N/A','TU GRUERO GOLD','TGG-CCCT-0001','Distrito Capital','DIRECCIPON DE DOMICI','',
	'2017-10-21','2017-10-21 16:57:01','2017-10-21 16:57:01','1','1','','','','2017-10-21 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK`
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`,
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('DFGDFGD','V-18020594','MARCOS','DE ANDRADE','Acura','DDFGDFG','Automóvil','N/A','DFGDFG','1980','N/A','TU GRUERO PLUS','TGP-CCCT-0001','Amazonas','LSDJALSKDJLKASDJKASJ','',
	'2017-10-21','2017-10-21 17:05:19','2017-10-21 17:05:19','1','1','','','','2017-10-21 00:00:00','Activo','0');
#########SolicitudPlan############
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK`
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`,
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`,
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`,
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('1','MARCOS','DE ANDRADE', 'DEANDRADEMARCOS@GMAIL.COM', 'V-18020594','Casado(a)',	'2017-10-21','Masculino' ,'V-18020594',
	'Distrito Capital',	'CARACAS', 'DIRECCIPON DE DOMICI', '02128601223','04268141850','2017-10-21','TDC', '0',
	'Camioneta', 'Acura', 'AAAA','1980','JHJHJHJ','HGHGJHG','Coupé','5','kjhkjhkhj', 'kjhkjhkjh','ACT',
	'267532.90', '267532.90', 'S', '', '3', '', '','0',null);
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK`
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`,
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`,
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`,
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('2','MARCOS','DE ANDRADE', 'DESARROLLO@TUGRUERO.COM', 'V-18020594','Casado(a)',	'2017-10-21','Masculino' ,'V-18020594',
	'Amazonas',	'CARAAS', 'LSDJALSKDJLKASDJKASJ', '02128601223','04141212121','2017-10-21','DEP', '0',
	'Automóvil', 'Acura', 'DDFGDFG','1980','DFGDFG','DFGDFGD','Coupé','5','dfgdfgdfg', 'dfgdfgdfgdf','ACT',
	'136732.90', '136732.90', 'S', '', '3', '', '','0',null);
#########SolicitudPagoDetalle############
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK`
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`,
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`,
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`,
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`,
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('1','iujkjhlkjh','Pago de plan mediante la herramienta administrativa','approved','', '','','2017-10-21 10:47:44',
	'débito','credit_card','', '','guest', 'deandrademarcos@gmail.com','',
	'v-18020594','','','','267532.9',
	'', '','', '');
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK`
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`,
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`,
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`,
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`,
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('2','','Pago de plan mediante la herramienta administrativa','approved','', '','','2017-10-21 11:05:11',
	'débito','credit_card','', '','guest', 'desarrollo@tugruero.com','',
	'','','','','136732.9',
	'', '','', '');
#########SolicitudPlanSeleccion############
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('1','2', '261600.00','261600.00', '2017-10-21');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('1','3', '5932.90','5932.90', '2017-10-21');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('2','1', '130800.00','130800.00', '2017-10-21');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('2','3', '5932.90','5932.90', '2017-10-21');
#########SolicitudDocumentos############
#########SolicitudAprobada############
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK`
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('1','TGG-CCCT-0001','2017-10-21','2017-10-21','02-5-CCCT-0001','02-5-CCCT-0001-1','2017-10-21');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK`
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('2','TGP-CCCT-0001','2017-10-21','2017-10-21','02-5-CCCT-0002','02-5-CCCT-0002-1','2017-10-21');
