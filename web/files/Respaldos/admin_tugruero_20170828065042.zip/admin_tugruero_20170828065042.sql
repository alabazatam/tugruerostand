#########Polizas############
INSERT INTO `admin_tugruero`.`PolizasBCK` 
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`, 
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('AAAAAAA','V-18020594','MARCOS','DE ANDRADE','Daihatsu','A','Automóvil','N/A','AAA','2014','N/A','TU GRUERO PLUS','TGP-CCCT-0002','Nueva Esparta','LASJASHKJDAHSDJAHSKDHA SDJKAHSKJDHAKJSDHKAJSDJA','', 
	'2017-08-28','2017-08-28 18:50:29','2017-08-28 18:50:29','1','1','','','','2017-08-28 00:00:00','Activo','0');
#########SolicitudPlan############
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('2','MARCOS','DE ANDRADE', 'AHKSJHDKJAS@G.COM', 'V-18020594','Divorciado(a)',	'2017-08-26','Masculino' ,'V-18020594', 
	'Nueva Esparta',	'CARACAS', 'LASJASHKJDAHSDJAHSKDHA SDJKAHSKJDHAKJSDHKAJSDJA', '02128601223','04241212121','2017-08-26','TDC', '0', 
	'Automóvil', 'Daihatsu', 'A','2014','AAA','AAAAAAA','Coupé','5','sdfsdfs', 'dfsdfsdfsd','ACT', 
	'0.00', '0.00', 'S', '', '3', 'MAX 50 KM', '50 URBANO (*) y 01 extra','0',null);
#########SolicitudPagoDetalle############
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('2','sfsdfsd','Pago de plan mediante la herramienta administrativa','approved','', '','','2017-08-28 06:50:16', 
	'débito','credit_card','', '','guest', 'AHKSJHDKJAS@G.COM','', 
	'fsdfsdfsdf','','','','25932.9', 
	'', '','', '');
#########SolicitudPlanSeleccion############
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('2','1', '20000.00','20000.00', '2017-08-26');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('2','3', '5932.90','5932.90', '2017-08-26');
#########SolicitudDocumentos############
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('2','Cedula','Cedula_CCCT_2.pdf','2017-08-26 05:05:40','ACT');
#########SolicitudAprobada############
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('2','TGP-CCCT-0002','2017-08-28','2017-08-28','02-5-CCCT-0006','02-5-CCCT-0006-1','2017-08-28');
