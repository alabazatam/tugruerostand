#########Polizas############
INSERT INTO `admin_tugruero`.`PolizasBCK` 
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`, 
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('DASDASD','V-18020594','MARCOS','DE ANDRADE','Aston Martin','ASDASDASD','Automóvil','N/A','ASDASDASDASDAS','1991','N/A','TU GRUERO GOLD','TGG-CCCT-0005','Apure','ASDASDASDASDASDASDASDASDSA','', 
	'2017-08-28','2017-08-28 18:48:50','2017-08-28 18:48:50','1','1','','','','2017-08-28 00:00:00','Activo','0');
#########SolicitudPlan############
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('5','MARCOS','DE ANDRADE', 'DEANDRADEMARCOS@GMAIL.COM', 'V-18020594','Casado(a)',	'2017-08-26','Masculino' ,'V-18020594', 
	'Apure',	'SDASDASDASDAS', 'ASDASDASDASDASDASDASDASDSA', '02128601223','04143232323','2017-08-26','TDC', '0', 
	'Automóvil', 'Aston Martin', 'ASDASDASD','1991','ASDASDASDASDAS','DASDASD','Coupé','5','asdasdasdasdas', 'asdasdasdasdasdsa','ACT', 
	'126532.90', '126532.90', 'S', '', '3', 'MAX 300 KM', 'ILIMITADO URBANO (*) Y UNO (01) EXTRAURBANO (*)','0',null);
#########SolicitudPagoDetalle############
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('5','dfgdfg','Pago de plan mediante la herramienta administrativa','approved','', '','','2017-08-26 05:30:45', 
	'débito','credit_card','', '','guest', 'DEANDRADEMARCOS@GMAIL.COM','', 
	'dfgdfgdfg','','','','125932.9', 
	'', '','', '');
#########SolicitudPlanSeleccion############
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('5','2', '120000.00','120000.00', '2017-08-26');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('5','3', '5932.90','5932.90', '2017-08-26');
#########SolicitudDocumentos############
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('5','Cedula','Cedula_CCCT_5.pdf','2017-08-26 05:30:35','ACT');
#########SolicitudAprobada############
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('5','TGG-CCCT-0005','2017-08-28','2017-08-28','02-5-CCCT-0005','02-5-CCCT-0005-1','2017-08-28');
