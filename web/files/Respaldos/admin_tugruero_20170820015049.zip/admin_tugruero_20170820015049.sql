#########Polizas############
INSERT INTO `admin_tugruero`.`PolizasBCK` 
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`, 
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('SSSSSSS','V-18020594','ALLAKSDJLJL','JLJALDJALSDJLK','Daihatsu','ASDASD','Automóvil','N/A','ASDASD','2013','N/A','TU GRUERO GOLD','TGG-CCCT-0001','Apure','HKJAHDKAHSKDHA SDKJAHSDKJHASKDHAKSHDAKJSHDKAJSHDKAJ','', 
	'2017-08-20','2017-08-20 13:45:57','2017-08-20 13:45:57','1','1','','','','2017-08-20 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK` 
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`, 
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('ASDASDS','V-18020594','SDFJSLDJFLQ','JSLJASLDJALSJ','Dodge','ASDASD','Automóvil','N/A','ASDASD','2016','N/A','TU GRUERO GOLD','TGG-CCCT-0002','Apure','KHDSHDKJASD','', 
	'2017-08-20','2017-08-20 13:46:22','2017-08-20 13:46:22','1','1','','','','2017-08-20 00:00:00','Activo','0');
#########SolicitudPlan############
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('1','SDFJSLDJFLQ','JSLJASLDJALSJ', 'ASKJDKAJSD@GMAIL.COM', 'V-18020594','Divorciado(a)',	'2017-08-20','Masculino' ,'V-18020594', 
	'Apure',	'ALSHDASHDKJH', 'KHDSHDKJASD', '02128601223','04142323232','2017-08-20','DEP', '0', 
	'Automóvil', 'Dodge', 'ASDASD','2016','ASDASD','ASDASDS','Coupé','5','asdasd', 'asdasdasds','ACT', 
	'125932.90', '125932.90', 'S', '', '3', 'MAX 300 KM', 'ILIMITADO URBANO (*) Y UNO (01) EXTRAURBANO (*)','0',null);
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('2','ALLAKSDJLJL','JLJALDJALSDJLK', 'ASHDLJASD@GMAIL.COM', 'V-18020594','Soltero(a)',	'2017-08-20','Masculino' ,'V-787878787', 
	'Apure',	'LKAHSKASHKDH', 'HKJAHDKAHSKDHA SDKJAHSDKJHASKDHAKSHDAKJSHDKAJSHDKAJ', '02128601212','04145454544','2017-08-20','TDC', '0', 
	'Automóvil', 'Daihatsu', 'ASDASD','2013','ASDASD','SSSSSSS','Hatchback','5','dfsdf', 'sdfsdfsdfsd','ACT', 
	'120000.00', '120000.00', 'S', '', '3', 'MAX 300 KM', 'ILIMITADO URBANO (*) Y UNO (01) EXTRAURBANO (*)','0',null);
#########SolicitudPagoDetalle############
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('1','','','approved','', '','','', 
	'','','', '','', '','', 
	'','','','','', 
	'', '','', '');
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('2','','','approved','', '','','', 
	'','','', '','', '','', 
	'','','','','', 
	'', '','', '');
#########SolicitudPlanSeleccion############
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('1','2', '120000.00','120000.00', '2017-08-20');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('1','3', '5932.90','5932.90', '2017-08-20');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('2','2', '120000.00','120000.00', '2017-08-20');
#########SolicitudDocumentos############
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('1','Cedula','Cedula_CCCT_1.pdf','2017-08-20 01:46:16','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('2','Cedula','Cedula_CCCT_2.pdf','2017-08-20 01:45:51','ACT');
#########SolicitudAprobada############
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('1','TGG-CCCT-0002','2017-08-20','2017-08-20','02-5-CCCT-0001','02-5-CCCT-0001-1','2017-08-20');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('2','TGG-CCCT-0001','2017-08-20','2017-08-20','','','2017-08-20');
