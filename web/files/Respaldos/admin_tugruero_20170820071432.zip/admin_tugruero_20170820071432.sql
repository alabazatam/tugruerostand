#########Polizas############
INSERT INTO `admin_tugruero`.`PolizasBCK` 
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`, 
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('DASDASD','V-18020594','ASDASDASD','SRFSDFSDFSDFSDF','Daihatsu','ASDASDAS','Automóvil','N/A','ASDSADAS','2014','N/A','TU GRUERO PLUS','TGP-CCCT-0002','Anzoátegui','LAKSJDLKASJDAS','', 
	'2017-08-20','2017-08-20 19:13:50','2017-08-20 19:13:50','1','1','','','','2017-08-20 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK` 
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`, 
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('AAAAAAA','V-18020594','ASDASDASDA','ASDASDASDASD','Dodge','ASDASD','Automóvil','N/A','ASDSADSA','2014','N/A','TU GRUERO GOLD','TGG-CCCT-0002','Anzoátegui','LKASDLKASJDLKASJDASDASDAS','', 
	'2017-08-20','2017-08-20 19:14:19','2017-08-20 19:14:19','1','1','','','','2017-08-20 00:00:00','Activo','0');
#########SolicitudPlan############
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('3','ASDASDASD','SRFSDFSDFSDFSDF', 'DEANDRADEMA@H.COM', 'V-18020594','Casado(a)',	'2017-08-20','Masculino' ,'V-545454545', 
	'Anzoátegui',	'SLKSAJDLKASJLKD', 'LAKSJDLKASJDAS', '02127860545','04145454545','2017-08-20','TDC', '0', 
	'Automóvil', 'Daihatsu', 'ASDASDAS','2014','ASDSADAS','DASDASD','Coupé','5','aaaaaaaaaaa', 'aaaaaaaaaaaaaaaaaaaaa','ACT', 
	'40000.00', '40000.00', 'S', '', '3', 'MAX 50 KM', 'ILIMITADO','0',null);
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('4','ASDASDASDA','ASDASDASDASD', 'DEANDRADEMA@H.COM', 'V-18020594','Casado(a)',	'2017-08-20','Masculino' ,'V-18020594', 
	'Anzoátegui',	'ASDSAJDLKSAJ', 'LKASDLKASJDLKASJDASDASDAS', '02128602121','04145454545','2017-08-20','DEP', '0', 
	'Automóvil', 'Dodge', 'ASDASD','2014','ASDSADSA','AAAAAAA','Coupé','5','sssssssssss', 'ssssssssssssssssssss','ACT', 
	'125932.90', '125932.90', 'S', '', '3', 'MAX 300 KM', 'ILIMITADO URBANO (*) Y UNO (01) EXTRAURBANO (*)','0',null);
#########SolicitudPagoDetalle############
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('3','','','approved','', '','','', 
	'','','', '','', '','', 
	'','','','','', 
	'', '','', '');
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('4','','','approved','', '','','', 
	'','','', '','', '','', 
	'','','','','', 
	'', '','', '');
#########SolicitudPlanSeleccion############
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('3','1', '40000.00','40000.00', '2017-08-20');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('4','2', '120000.00','120000.00', '2017-08-20');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('4','3', '5932.90','5932.90', '2017-08-20');
#########SolicitudDocumentos############
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('3','Cedula','Cedula_CCCT_3.pdf','2017-08-20 07:13:42','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('4','Cedula','Cedula_CCCT_4.pdf','2017-08-20 07:14:10','ACT');
#########SolicitudAprobada############
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('3','TGP-CCCT-0002','2017-08-20','2017-08-20','','','2017-08-20');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('4','TGG-CCCT-0002','2017-08-20','2017-08-20','02-5-CCCT-0003','02-5-CCCT-0003-1','2017-08-20');
