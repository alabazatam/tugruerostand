#########Polizas############
INSERT INTO `admin_tugruero`.`PolizasBCK` 
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`, 
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('AAASDAS','V-18020594','MARCOS','DE ANDRADE','Acura','AVEO','Automóvil','N/A','BLANCO','2015','N/A','TU GRUERO GOLD','TGG-CCCT-0001','Distrito Capital','DIRECCION DE DOMICILIO','', 
	'2017-08-28','2017-08-28 14:13:17','2017-08-28 14:13:17','1','1','','','','2017-08-28 00:00:00','Activo','0');
#########SolicitudPlan############
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('1','MARCOS','DE ANDRADE', 'DEANDRADEMARCOS@GMAIL.COM', 'V-18020594','Casado(a)',	'2017-08-28','Masculino' ,'V-18020594', 
	'Distrito Capital',	'CARACAS', 'DIRECCION DE DOMICILIO', '02128601223','04141234567','2017-08-28','DEP', '0', 
	'Automóvil', 'Acura', 'AVEO','2015','BLANCO','AAASDAS','Sport Wagon','7','sdasdasdasdasdasdasdasdasdasd', 'asdasdasdsa','ACT', 
	'126532.90', '126532.90', 'S', '', '3', 'MAX 300 KM', 'ILIMITADO URBANO (*) Y UNO (01) EXTRAURBANO (*)','0',null);
#########SolicitudPagoDetalle############
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('1','','Pago de plan mediante la herramienta administrativa','approved','', '','','2017-08-28 01:54:08', 
	'débito','credit_card','', '','guest', 'deandrademarcos@gmail.com','', 
	'','','','','126532.9', 
	'', '','', '');
#########SolicitudPlanSeleccion############
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('1','2', '120000.00','120000.00', '2017-08-28');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('1','5', '6532.90','6532.90', '2017-08-28');
#########SolicitudDocumentos############
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('1','Cedula','Cedula_CCCT_1.pdf','2017-08-28 01:54:08','ACT');
#########SolicitudAprobada############
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('1','TGG-CCCT-0001','2017-08-28','2017-08-28','02-5-CCCT-0001','02-5-CCCT-0001-1','2017-08-28');
