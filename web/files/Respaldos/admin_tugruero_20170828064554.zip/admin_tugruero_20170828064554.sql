#########Polizas############
INSERT INTO `admin_tugruero`.`PolizasBCK` 
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`, 
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('SSSSSSS','V-18020594','KJDHASHDA','HKAHSKDHAS','Acura','SSSSSSSSSSS','Automóvil','N/A','SSSSSSSSSS','1990','N/A','TU GRUERO GOLD','TGG-CCCT-0003','Anzoátegui','DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD','', 
	'2017-08-26','2017-08-26 17:43:44','2017-08-26 17:43:44','1','1','','','','2017-08-26 00:00:00','Activo','0');
INSERT INTO `admin_tugruero`.`PolizasBCK` 
	(`Placa`,`Cedula`,`Nombre`,`Apellido`,`Marca`,`Modelo`,`Clase`,`Tipo`,`Color`,`Año`,`Serial`,`Seguro`,`NumPoliza`,`DireccionEDO`,`Domicilio`,`DireccionFiscal`, 
	`Vencimiento`,`date_created`,`date_updated`,`created_by`,`updated_by`,`Nacionalidad`,`Celular`,`Email`,`DesdeVigencia`,`EstatusPoliza`,`Respaldo`
	)
	VALUES
	('SDFSDFS','V-18020589','SDLSJDLKA','SDFSDFSDFDFSDD','Acura','SDFSDFD','Automóvil','N/A','SDFDFSF','1992','N/A','TU GRUERO GOLD','TGG-CCCT-0004','Apure','ASDASDASD ASDASDASDASDS','', 
	'2017-08-26','2017-08-26 18:04:48','2017-08-26 18:04:48','1','1','','','','2017-08-26 00:00:00','Activo','0');
#########SolicitudPlan############
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('7','KJDHASHDA','HKAHSKDHAS', 'DDDDD@GMAIL.COM', 'V-18020594','Casado(a)',	'2017-08-26','Masculino' ,'V-18020594', 
	'Anzoátegui',	'ZSDASDASDAS', 'DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD', '02128602122','04141111111','2017-08-26','TDC', '0', 
	'Automóvil', 'Acura', 'SSSSSSSSSSS','1990','SSSSSSSSSS','SSSSSSS','Coupé','5','', '','ACT', 
	'125932.90', '125932.90', 'S', '', '3', 'MAX 300 KM', 'ILIMITADO URBANO (*) Y UNO (01) EXTRAURBANO (*)','0',null);
	INSERT INTO `admin_tugruero`.`SolicitudPlanBCK` 
	(`idSolicitudPlan`,`Nombres`,`Apellidos`,`Correo`, `Cedula`, `EstadoCivil`,	`FechaNacimiento`,`Sexo`,`Rif`, 
	`Estado`,`Ciudad`,`Domicilio`, `Telefono`,`Celular`,`FechaSolicitud`, `TipoPago`,`NumeroTransaccion`,`Clase`, 
	`Marca`, `Modelo`,`Anio`, `Color`, `Placa`, `Tipo`, `Puestos`, `SerialMotor`, `SerialCarroceria`, `Estatus`, 
	`TotalSinIva`, `TotalConIva`, `PagoRealizado`, `Observacion`, `IdV`, `Kilometraje`, `CantidadServicios`,`Respaldo`,`IdRespaldo`
	)
	VALUES
	('8','SDLSJDLKA','SDFSDFSDFDFSDD', 'SADAS@GMAIL.COM', 'V-18020589','Casado(a)',	'2017-08-26','Masculino' ,'V-18020594', 
	'Apure',	'CARACAS', 'ASDASDASD ASDASDASDASDS', '02128601223','04241212112','2017-08-26','DEP', '0', 
	'Automóvil', 'Acura', 'SDFSDFD','1992','SDFDFSF','SDFSDFS','Cross Over','5','', '','ACT', 
	'120000.00', '120000.00', 'S', '', '3', 'MAX 300 KM', 'ILIMITADO URBANO (*) Y UNO (01) EXTRAURBANO (*)','0',null);
#########SolicitudPagoDetalle############
	INSERT INTO `admin_tugruero`.`SolicitudPagoDetalleBCK` 
	(`idSolicitudPlan`,	`id`, `description`,`status`,`status_detail`,`currency_id`,`date_created`, 
	`date_approved`, `payment_method_id`,`payment_type_id`, `collector_id`, `payer_type`, `payer_id`, 
	`payer_email`, `payer_identification_type`, `payer_identification_number`,`payer_first_name`, 
	`payer_last_name`,	`payer_entity_type`, `transaction_amount`, `net_received_amount`, `carholder_name`, 
	`carholder_identification_type`, `cardholder_identification_number`	)
	VALUES
	('8','','Pago de plan mediante la herramienta administrativa','approved','', '','','2017-08-26 06:04:34', 
	'débito','credit_card','', '','guest', 'SADAS@GMAIL.COM','', 
	'','','','','120000', 
	'', '','', '');
#########SolicitudPlanSeleccion############
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('7','2', '120000.00','120000.00', '2017-08-26');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('7','3', '5932.90','5932.90', '2017-08-26');
	INSERT INTO `admin_tugruero`.`SolicitudPlanSeleccionBCK` (`idSolicitudPlan`,`idPlan`, `PrecioConIva`, `PrecioSinIva`,`FechaSolicitud`)
		VALUES
		('8','2', '120000.00','120000.00', '2017-08-26');
#########SolicitudDocumentos############
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('7','Cedula','Cedula_CCCT_7.pdf','2017-08-26 05:50:47','ACT');
	INSERT INTO `admin_tugruero`.`SolicitudDocumentosBCK` (`idSolicitudPlan`,`TipoDocumento`, `NombreDocumento`,`FechaSubida`,`Estatus`)
	VALUES
	('8','Cedula','Cedula_CCCT_8.png','2017-08-26 06:06:15','ACT');
#########SolicitudAprobada############
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('7','TGG-CCCT-0003','2017-08-26','2017-08-26','02-5-CCCT-0004','02-5-CCCT-0004-1','2017-08-26');
	INSERT INTO `admin_tugruero`.`SolicitudAprobadaBCK` 
	(`idSolicitudPlan`,`NumProducto`,`VigenciaDesde`,`VigenciaHasta`,`PolizaAsistir`,`ReciboAsistir`,`FechaAprobacion`)
	VALUES
	('8','TGG-CCCT-0004','2017-08-26','2017-08-26','','','2017-08-26');
